#include "xenos_renderer.h"

namespace XENOS {

void Renderer::Draw() {
    // 🚨 PRIMEIRO TESTE: TRIÂNGULO FORÇADO 🚨
    // Ignora buffers reais por enquanto

    // Exemplo conceitual:
    /*
    Vertex tri[3] = {
        { -0.5f, -0.5f, 0.0f },
        {  0.5f, -0.5f, 0.0f },
        {  0.0f,  0.5f, 0.0f }
    };

    XGSetVertexShader(simple_shader);
    XGSetVertexBuffer(tri);
    XGDrawPrimitive(XG_TRIANGLE_LIST, 1);
    */

    // ⚠️ Se esse triângulo aparecer, o Xenos está OK.
}
}