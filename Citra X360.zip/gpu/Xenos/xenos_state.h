#pragma once
#include <cstdint>

namespace XENOS {

struct GPUState {
    bool depth_test = false;
    bool blending   = false;

    uint32_t vertex_buffer = 0;
    uint32_t index_buffer  = 0;

    uint32_t texture0 = 0;
};

}