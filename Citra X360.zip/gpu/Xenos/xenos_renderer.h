#pragma once
#include "../pica/pica_state.h"
#include "xenos_state.h"

namespace XENOS {

class Renderer {
public:
    void Init();
    void BeginFrame();
    void EndFrame();

    void DrawFromPica(const PICA::State& pica_state);

private:
    GPUState state;

    void ApplyState();
    void Draw();
};

}