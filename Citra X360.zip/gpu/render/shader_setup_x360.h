#pragma once

#include <array>
#include <optional>
#include <cstddef>
#include "common/vector_math.h"
#include "video_core/pica/packed_attribute.h"
#include "video_core/pica_types.h"

namespace Pica {

constexpr u32 MAX_PROGRAM_CODE_LENGTH = 4096;
constexpr u32 MAX_SWIZZLE_DATA_LENGTH = 4096;

using ProgramCode = std::array<u32, MAX_PROGRAM_CODE_LENGTH>;
using SwizzleData = std::array<u32, MAX_SWIZZLE_DATA_LENGTH>;

struct Uniforms {
    alignas(16) std::array<Common::Vec4<f24>, 96> f;
    std::array<bool, 16> b;
    std::array<Common::Vec4<u8>, 4> i;
};

struct ShaderRegs;

/**
 * Estado puro do shader PICA200.
 * Não compila, não traduz, apenas armazena e executa semanticamente.
 */
struct ShaderSetupX360 {
    ShaderSetupX360();

    // Escrita de uniformes
    void WriteUniformBool(u32 value);
    void WriteUniformInt(u32 index, const Common::Vec4<u8>& values);
    std::optional<u32> WriteUniformFloat(ShaderRegs& regs, u32 value);

    // Hash apenas para cache futuro (não obrigatório agora)
    u64 ProgramHash();
    u64 SwizzleHash();

    // Estado público
    Uniforms uniforms{};
    PackedAttribute uniform_queue{};
    ProgramCode program_code{};
    SwizzleData swizzle_data{};
    u32 entry_point{0};

private:
    bool program_dirty{true};
    bool swizzle_dirty{true};
    u64 program_hash{0};
    u64 swizzle_hash{0};
};

} // namespace Pica