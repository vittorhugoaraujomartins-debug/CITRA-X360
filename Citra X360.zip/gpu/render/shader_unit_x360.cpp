#include "shader_unit_x360.h"
#include "common/bit_set.h"
#include "video_core/pica/regs_shader.h"

namespace Pica {

ShaderUnitX360::ShaderUnitX360() {
    Common::Vec4<f24> init{f24::Zero(), f24::Zero(), f24::Zero(), f24::One()};
    temp_regs.fill(init);
}

void ShaderUnitX360::LoadInput(const ShaderRegs& regs,
                              const AttributeBuffer& buffer) {
    for (u32 i = 0; i <= regs.max_input_attribute_index; i++) {
        u32 reg = regs.GetRegisterForAttribute(i);
        input_regs[reg] = buffer[i];
    }
}

void ShaderUnitX360::WriteOutput(const ShaderRegs& regs,
                                AttributeBuffer& buffer) {
    u32 out = 0;
    for (u32 reg : Common::BitSet<u32>(regs.output_mask)) {
        buffer[out++] = output_regs[reg];
    }
}

} // namespace Pica