#include "geometry_pipeline.h"
#include "geometry_pipeline_backend.h"
#include "regs_internal.h"

namespace Pica {

GeometryPipeline::GeometryPipeline(RegsInternal& r,
                                   GeometryShaderUnit& gsu,
                                   ShaderSetup& setup)
    : regs(r), gs_unit(gsu), gs(setup) {}

GeometryPipeline::~GeometryPipeline() = default;

void GeometryPipeline::SetVertexHandler(VertexHandler handler) {
    vertex_handler = handler;
}

void GeometryPipeline::Setup(ShaderEngine* engine) {
    shader_engine = engine;

    if (regs.gs_enable) {
        gs_unit.Setup(shader_engine, gs);
    }
}

void GeometryPipeline::Reconfigure() {
    // Escolha simples de backend
    // (no X360 evitamos polimorfismo excessivo)
    backend = CreateGeometryBackend(regs, gs_unit, vertex_handler);
}

bool GeometryPipeline::NeedIndexInput() const {
    return backend && backend->UsesIndexBuffer();
}

void GeometryPipeline::SubmitIndex(u32 index) {
    backend->SubmitIndex(index);
}

void GeometryPipeline::SubmitVertex(const AttributeBuffer& input) {
    backend->SubmitVertex(input);
}

} // namespace Pica
