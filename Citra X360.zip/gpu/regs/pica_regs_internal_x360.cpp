#include "pica_regs_internal_x360.h"

namespace Pica::X360 {
// Tudo inline por enquanto.
// Mantido separado para expansão futura (debug, tracing, savestate).
}