#pragma once


namespace Pica::X360 {

struct PipelineRegs {
    struct VertexAttrib {
        BitField<1, 28, u32> base;

        BitField<16, 12, u32> mask;
        BitField<28, 4, u32> max_attr;
    } vertex;

    struct Index {
        BitField<0, 28, u32> offset;
        BitField<31, 1, u32> format;
    } index;

    u32 vertex_count;
    u32 flags;
    u32 vertex_offset;

    u32 pad0[3];

    u32 draw;
    u32 draw_indexed;

    u32 pad1[0x40];
};

static_assert(sizeof(PipelineRegs) == 0x80 * sizeof(u32),
              "PipelineRegs X360 size mismatch");

} // namespace Pica::X360