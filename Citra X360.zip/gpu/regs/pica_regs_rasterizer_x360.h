#pragma once


namespace Pica::X360 {

struct RasterizerRegs {
    BitField<0, 2, u32> cull;

    BitField<0, 24, u32> vp_w;
    u32 pad0;
    BitField<0, 24, u32> vp_h;

    u32 pad1[3];

    BitField<0, 1, u32> clip_enable;
    BitField<0, 24, u32> clip[4];

    BitField<0, 24, u32> depth_range;
    BitField<0, 24, u32> depth_near;

    BitField<0, 3, u32> vs_out_total;

    u32 vs_semantic[7];

    u32 pad2[0x20];
};

static_assert(sizeof(RasterizerRegs) == 0x40 * sizeof(u32),
              "RasterizerRegs X360 size mismatch");

} // namespace Pica::X360