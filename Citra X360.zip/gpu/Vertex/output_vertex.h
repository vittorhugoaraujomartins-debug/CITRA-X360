#pragma once

#include <array>
#include <type_traits>
#include <cstring>

#include "common/common_funcs.h"
#include "common/vector_math.h"
#include "video_core/pica_types.h"

namespace Pica {

struct RasterizerRegs;

using AttributeBuffer = std::array<Common::Vec4<f24>, 16>;

// Xbox 360 gosta de alinhamento previsível
struct alignas(16) OutputVertex {
    OutputVertex() = default;
    explicit OutputVertex(const RasterizerRegs& regs, const AttributeBuffer& output);

    Common::Vec4<f24> pos;     // clip-space
    Common::Vec4<f24> quat;    // quaternion / normal
    Common::Vec4<f24> color;   // RGBA
    Common::Vec2<f24> tc0;
    Common::Vec2<f24> tc1;
    f24 tc0_w;
    u32 _pad0;
    Common::Vec3<f24> view;
    u32 _pad1;
    Common::Vec2<f24> tc2;
};

static_assert(std::is_trivial_v<OutputVertex>, "OutputVertex must be POD");
static_assert(sizeof(OutputVertex) == 96, "Unexpected OutputVertex size");

} // namespace Pica
