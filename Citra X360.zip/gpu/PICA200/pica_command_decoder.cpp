#include "pica_command_decoder.h"
#include "pica_regs.h"

namespace PICA {

void CommandDecoder::Reset() {
    state = State{};
}

const State& CommandDecoder::GetState() const {
    return state;
}

void CommandDecoder::Decode(uint32_t command, uint32_t param) {
    uint16_t cmd = static_cast<uint16_t>(command & 0xFFFF);

    switch (cmd) {

    case CMD_SET_VERTEX_BUF:
        state.vb.address = param;
        break;

    case CMD_SET_INDEX_BUF:
        state.ib.address = param;
        break;

    case CMD_SET_TEXTURE0:
        state.tex0.address = param;
        break;

    case CMD_SET_DEPTH_TEST:
        state.depth_test = (param & 1);
        break;

    case CMD_SET_BLEND:
        state.blending = (param & 1);
        break;

    case CMD_DRAW:
        state.draw_pending = true;
        break;

    default:
        // comando ignorado por enquanto
        break;
    }
}

}