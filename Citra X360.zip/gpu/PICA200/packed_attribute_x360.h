#pragma once

#include <array>
#include <bit>

#include "common/vector_math.h"
#include "common/common_types.h"
#include "common/endian.h"
#include "video_core/pica_x360/pica_types_x360.h"

namespace Pica::X360 {

/**
 * Handles packed uniform / attribute uploads from PICA200.
 * Endian-safe for Xbox 360 (PPC).
 */
struct PackedAttribute {
    std::array<u32, 4> buffer{};
    u32 index = 0;

    constexpr bool Push(u32 word, bool is_float32 = false) {
        buffer[index++] = word;
        return (index >= 4 && is_float32) || (index >= 3 && !is_float32);
    }

    constexpr void Reset() {
        index = 0;
    }

    constexpr Common::Vec4<f24> Get(bool is_float32 = false) {
        index = 0;
        return is_float32 ? AsFloat32() : AsFloat24();
    }

private:
    constexpr Common::Vec4<f24> AsFloat24() const {
        // buffer[] is assumed LE-normalized at MMIO boundary
        const u32 x = buffer[2] & 0x00FFFFFF;
        const u32 y = ((buffer[1] & 0x0000FFFF) << 8) |
                      ((buffer[2] >> 24) & 0xFF);
        const u32 z = ((buffer[0] & 0x000000FF) << 16) |
                      ((buffer[1] >> 16) & 0xFFFF);
        const u32 w = buffer[0] >> 8;

        return {
            f24::FromRaw(x),
            f24::FromRaw(y),
            f24::FromRaw(z),
            f24::FromRaw(w)
        };
    }

    constexpr Common::Vec4<f24> AsFloat32() const {
        Common::Vec4<f24> out{};

        for (u32 i = 0; i < 4; i++) {
            // buffer[i] MUST be LE before this point
            const f32 value = std::bit_cast<f32>(buffer[i]);
            out[3 - i] = f24::FromFloat32(value);
        }
        return out;
    }
};

} // namespace Pica::X360