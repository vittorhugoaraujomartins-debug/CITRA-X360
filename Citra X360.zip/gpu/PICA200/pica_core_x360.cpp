#include "pica_core_x360.h"

#include <cstring>
#include <cassert>

namespace PICA200 {

// ================================
// Construtor / Reset
// ================================

PicaCoreX360::PicaCoreX360() {
    Reset();
}

void PicaCoreX360::Reset() {
    std::memset(registers, 0, sizeof(registers));
    std::memset(uniforms, 0, sizeof(uniforms));

    fifo_head = 0;
    fifo_tail = 0;
    fifo_count = 0;

    pipeline_dirty = true;
    current_primitive = PrimitiveType::None;
}

// ================================
// FIFO de comandos da GPU
// ================================

bool PicaCoreX360::PushCommand(u32 cmd) {
    if (fifo_count >= FIFO_SIZE)
        return false;

    command_fifo[fifo_tail] = cmd;
    fifo_tail = (fifo_tail + 1) % FIFO_SIZE;
    fifo_count++;
    return true;
}

bool PicaCoreX360::PopCommand(u32& out_cmd) {
    if (fifo_count == 0)
        return false;

    out_cmd = command_fifo[fifo_head];
    fifo_head = (fifo_head + 1) % FIFO_SIZE;
    fifo_count--;
    return true;
}

// ================================
// Execução principal da GPU
// ================================

void PicaCoreX360::Step() {
    u32 cmd;
    while (PopCommand(cmd)) {
        ExecuteCommand(cmd);
    }
}

// ================================
// Decodificador de comandos PICA
// ================================

void PicaCoreX360::ExecuteCommand(u32 cmd) {
    u32 reg = (cmd >> 16) & 0xFFFF;
    u32 value = cmd & 0xFFFF;

    WriteRegister(reg, value);
}

// ================================
// Escrita em registradores
// ================================

void PicaCoreX360::WriteRegister(u32 reg, u32 value) {
    if (reg >= REGISTER_COUNT)
        return;

    registers[reg] = value;

    switch (reg) {
        case REG_PRIMITIVE_CONFIG:
            DecodePrimitive(value);
            break;

        case REG_VERTEX_SHADER_CONTROL:
        case REG_GEOMETRY_SHADER_CONTROL:
        case REG_FRAGMENT_SHADER_CONTROL:
            pipeline_dirty = true;
            break;

        case REG_UNIFORM_DATA:
            WriteUniform(value);
            break;

        default:
            // Registrador válido mas ainda não tratado
            break;
    }
}

// ================================
// Uniforms / Shaders
// ================================

void PicaCoreX360::WriteUniform(u32 value) {
    if (uniform_index < UNIFORM_COUNT) {
        uniforms[uniform_index++] = value;
    }
}

// ================================
// Pipeline
// ================================

void PicaCoreX360::DecodePrimitive(u32 value) {
    switch (value & 0x7) {
        case 0:
            current_primitive = PrimitiveType::Points;
            break;
        case 1:
            current_primitive = PrimitiveType::Lines;
            break;
        case 2:
            current_primitive = PrimitiveType::Triangles;
            break;
        default:
            current_primitive = PrimitiveType::None;
            break;
    }
}

void PicaCoreX360::RebuildPipelineIfNeeded() {
    if (!pipeline_dirty)
        return;

    // Aqui futuramente:
    // - Decodificar shaders PICA
    // - Preparar estados fixos
    // - Cache de pipeline

    pipeline_dirty = false;
}

// ================================
// Debug
// ================================

void PicaCoreX360::DumpState() const {
    // Função de debug simples
    // Pode ser ligada depois a log serial
}

} // namespace PICA200