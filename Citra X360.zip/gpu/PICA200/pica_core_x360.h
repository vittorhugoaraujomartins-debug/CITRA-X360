#pragma once

#include "memory.h"
#include "regs_internal.h"
#include "primitive_assembly.h"
#include "geometry_pipeline.h"
#include "shader_setup_x360.h"
#include "shader_unit_x360.h"

namespace Pica {

class PicaCoreX360 {
public:
    explicit PicaCoreX360(Memory::MemorySystem& memory);

    void ProcessCommandList(PAddr addr, u32 size);

private:
    void WriteInternalReg(u32 id, u32 value, u32 mask);
    void DrawArrays(bool indexed);
    void DrawImmediate();

private:
    Memory::MemorySystem& memory;

    // Registradores
    RegsInternal regs{};

    // Shader state
    ShaderSetupX360 vs_setup;
    ShaderSetupX360 gs_setup;

    // Execução
    ShaderUnitX360 vs_unit;
    ShaderUnitX360 gs_unit;

    // Pipeline
    GeometryPipeline geometry_pipeline;
    PrimitiveAssembler primitive_assembler;

    // Estado imediato
    AttributeBuffer default_attributes{};
};

void PicaCoreX360::DrawImmediate() {
    AttributeBuffer output{};

    vs_unit.LoadInput(regs.vs, default_attributes);

    // EXECUÇÃO INTERPRETADA (ainda não existe, mas esse é o lugar)
    ExecutePicaShader(vs_setup, vs_unit);

    vs_unit.WriteOutput(regs.vs, output);

    geometry_pipeline.SubmitVertex(output);
}



} // namespace Pica