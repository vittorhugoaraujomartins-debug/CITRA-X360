#include "gpu_x360.h"

namespace VideoCoreX360 {

GPU_X360::GPU_X360() {
    renderer.Initialize();
}

void GPU_X360::ExecuteCmdList(uint32_t addr, uint32_t size) {
    pica.ProcessCmdList(addr, size);
}

void GPU_X360::UploadTexture(const Pica::Texture::TextureInfo& info) {
    renderer.UploadTexture(
        info.physical_address,
        info.width,
        info.height,
        (uint32_t)info.format
    );
}

void GPU_X360::DrawCall() {
    renderer.DrawIndexed();
}

void GPU_X360::SwapBuffers() {
    renderer.Present();
}

}