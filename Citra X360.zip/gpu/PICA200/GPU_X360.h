#pragma once
#include "pica_core_x360.h"
#include "renderer_x360.h"

namespace VideoCoreX360 {

class GPU_X360 {
public:
    GPU_X360();

    void ExecuteCmdList(uint32_t addr, uint32_t size);

    void UploadTexture(const Pica::Texture::TextureInfo& info);

    void DrawCall();

    void SwapBuffers();

private:
    PicaX360::PicaCoreX360 pica;
    RendererX360 renderer;
};

}