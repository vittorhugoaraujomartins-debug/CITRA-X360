#pragma once
#include <cstdint>
#include "pica_state.h"

namespace PICA {

class CommandDecoder {
public:
    void Reset();

    // recebe comando cru da memória da GPU
    void Decode(uint32_t command, uint32_t param);

    // acesso ao estado atual
    const State& GetState() const;

private:
    State state;
};

}