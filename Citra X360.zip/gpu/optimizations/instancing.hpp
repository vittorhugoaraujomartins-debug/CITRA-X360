
#pragma once
#include <vector>
#include <cstdint>

struct InstanceData {
    float matrix[16];
};

class InstanceBatch {
public:
    uint32_t meshId;
    uint32_t materialId;
    std::vector<InstanceData> instances;
};
