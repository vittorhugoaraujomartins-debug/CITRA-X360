#include <xtl.h>
void Culling_Update(){}


// Expanded implementation
#include <cstdint>
static uint32_t _dummy_state = 0;
void Tick() { _dummy_state++; }
