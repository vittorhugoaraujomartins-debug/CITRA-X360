#include "shader_interpreter_x360.h"
#include <cmath>

namespace PicaX360 {

void ShaderInterpreterX360::Reset() {
    regs = {};
}

static inline float dot3(const float* a, const float* b) {
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}

void ShaderInterpreterX360::Exec(uint32_t inst) {
    const uint32_t op = inst >> 26;
    const uint32_t dst = (inst >> 21) & 0x1F;
    const uint32_t s1  = (inst >> 16) & 0x1F;
    const uint32_t s2  = (inst >> 11) & 0x1F;

    switch (op) {

    case 0x00: // MOV
        regs.r[dst] = regs.r[s1];
        break;

    case 0x01: // ADD
        for (int i=0;i<4;i++)
            regs.r[dst][i] = regs.r[s1][i] + regs.r[s2][i];
        break;

    case 0x02: // MUL
        for (int i=0;i<4;i++)
            regs.r[dst][i] = regs.r[s1][i] * regs.r[s2][i];
        break;

    case 0x03: { // DP3
        float d = dot3(regs.r[s1].data(), regs.r[s2].data());
        regs.r[dst] = {d,d,d,d};
        break;
    }

    case 0x04: // RSQ
        for (int i=0;i<4;i++)
            regs.r[dst][i] = 1.0f / std::sqrt(regs.r[s1][i] + 1e-8f);
        break;

    case 0x05: // OUT → ponte pro X360
        regs.o[dst] = regs.r[s1];
        break;

    default:
        break;
    }
}

void ShaderInterpreterX360::Run(const uint32_t* program, size_t count) {
    for (size_t i = 0; i < count; i++) {
        Exec(program[i]);
    }
}

}