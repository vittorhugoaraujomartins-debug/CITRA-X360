#include "texture_decoder_x360.h"

namespace PicaX360 {

static inline uint32_t pack(uint8_t r,uint8_t g,uint8_t b,uint8_t a) {
    return (a<<24)|(b<<16)|(g<<8)|r;
}

void TextureDecoderX360::DecodeRGBA8(const uint8_t* src, uint32_t* dst, int pixels) {
    for (int i=0;i<pixels;i++) {
        uint8_t r = src[i*4+0];
        uint8_t g = src[i*4+1];
        uint8_t b = src[i*4+2];
        uint8_t a = src[i*4+3];
        dst[i] = pack(r,g,b,a);
    }
}

void TextureDecoderX360::DecodeRGB565(const uint8_t* src, uint32_t* dst, int pixels) {
    for (int i=0;i<pixels;i++) {
        uint16_t v = *(uint16_t*)(src + i*2);
        uint8_t r = ((v>>11)&31)<<3;
        uint8_t g = ((v>>5)&63)<<2;
        uint8_t b = (v&31)<<3;
        dst[i] = pack(r,g,b,255);
    }
}

std::vector<uint32_t> TextureDecoderX360::Decode(
    const uint8_t* data,
    int width,
    int height,
    TextureFormatX360 fmt) {

    int pixels = width * height;
    std::vector<uint32_t> out(pixels);

    switch (fmt) {

    case TextureFormatX360::RGBA8:
        DecodeRGBA8(data, out.data(), pixels);
        break;

    case TextureFormatX360::RGB565:
        DecodeRGB565(data, out.data(), pixels);
        break;

    default:
        // fallback simples
        for (int i=0;i<pixels;i++)
            out[i] = 0xFF00FFFF;
        break;
    }

    return out;
}

}