#include "mutex_x360.h"
#include "kernel_thread_x360.h"

bool MutexX360::ShouldWait(
    KernelThreadX360* t)
{
    return owner != nullptr && owner != t;
}

void MutexX360::Acquire(
    KernelThreadX360* t)
{
    if (owner == nullptr) {
        owner = t;
        lockCount = 1;
    } else if (owner == t) {
        lockCount++;
    }
}

void MutexX360::Release(
    KernelThreadX360* t)
{
    if (owner != t)
        return;

    lockCount--;

    if (lockCount == 0) {
        owner = nullptr;
        WakeAll();
    }
}