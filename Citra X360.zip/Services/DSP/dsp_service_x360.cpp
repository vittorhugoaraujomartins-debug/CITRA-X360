#include "dsp_service_x360.h"
#include "memory_system_x360.h"

DSPServiceX360::DSPServiceX360(MemorySystemX360& mem)
    : memory(mem) {}

void DSPServiceX360::HandleRequest(uint32_t msgPtr)
{
    uint32_t cmd = memory.Read32(msgPtr);

    switch (cmd) {
    case 0x01:
        CmdLoadComponent(msgPtr);
        break;

    case 0x02:
        CmdUnload(msgPtr);
        break;

    case 0x03:
        CmdGetStatus(msgPtr);
        break;

    default:
        memory.Write32(msgPtr, 0xDEAD0001);
        break;
    }
}

void DSPServiceX360::CmdLoadComponent(uint32_t msgPtr)
{
    uint32_t size = memory.Read32(msgPtr + 4);
    uint32_t src  = memory.Read32(msgPtr + 8);

    firmware.resize(size);

    for (uint32_t i = 0; i < size; i++)
        firmware[i] = memory.Read8(src + i);

    memory.Write32(msgPtr, 0);
}

void DSPServiceX360::CmdUnload(uint32_t msgPtr)
{
    firmware.clear();
    memory.Write32(msgPtr, 0);
}

void DSPServiceX360::CmdGetStatus(uint32_t msgPtr)
{
    memory.Write32(msgPtr, firmware.empty() ? 0 : 1);
}