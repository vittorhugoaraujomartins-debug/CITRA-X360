#pragma once
#include <vector>
#include <cstdint>

class MemorySystemX360;

class DSPServiceX360 {
public:
    DSPServiceX360(MemorySystemX360& mem);

    void HandleRequest(uint32_t msgPtr);

private:
    MemorySystemX360& memory;

    std::vector<uint8_t> firmware;

    void CmdLoadComponent(uint32_t msgPtr);
    void CmdUnload(uint32_t msgPtr);
    void CmdGetStatus(uint32_t msgPtr);
};

void DSPServiceX360::HandleRequest(uint32_t msgPtr)
{
    IPCReaderX360 ipc(memory, msgPtr);

    uint32_t size = ipc.Param(0);
    uint32_t addr = ipc.Param(1);

    // processa…

    ipc.WriteResult(0);
}