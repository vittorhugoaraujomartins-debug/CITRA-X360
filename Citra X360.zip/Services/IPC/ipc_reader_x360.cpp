#include "ipc_reader_x360.h"
#include "memory_system_x360.h"

IPCReaderX360::IPCReaderX360(
    MemorySystemX360& mem,
    uint32_t base)
    : memory(mem), ptr(base) {}

uint32_t IPCReaderX360::Param(int index)
{
    return memory.Read32(ptr + 4 + index * 4);
}

void IPCReaderX360::WriteResult(uint32_t value)
{
    memory.Write32(ptr + 0x14, value);
}