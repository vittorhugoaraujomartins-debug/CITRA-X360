#pragma once
#include <cstdint>

class ARMStateX360;
class IPCX360;
class KernelThreadX360;

class SVCX360 {
public:
    SVCX360(IPCX360& ipc);

    void Call(uint32_t svcId,
              ARMStateX360& cpu,
              KernelThreadX360& thread);

private:
    IPCX360& ipc;

    void SVC_SendSyncRequest(
        ARMStateX360& cpu);

    void SVC_Yield(
        KernelThreadX360& thread);
};