#pragma once
#include <cstdint>

class MemorySystemX360;

class IPCReaderX360 {
public:
    IPCReaderX360(MemorySystemX360& mem,
                  uint32_t base);

    uint32_t Param(int index);
    void WriteResult(uint32_t value);

private:
    MemorySystemX360& memory;
    uint32_t ptr;
};