#include "ipc_x360.h"
#include "memory_system_x360.h"
#include "service_manager_x360.h"

IPCX360::IPCX360(
    MemorySystemX360& mem,
    ServiceManagerX360& sm)
    : memory(mem), serviceManager(sm) {}

void IPCX360::SendSyncRequest(
    uint32_t messagePtr,
    uint32_t handle)
{
    serviceManager.HandleSyncRequest(
        messagePtr,
        handle);
}