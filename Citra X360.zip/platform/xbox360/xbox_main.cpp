#include "../../core/system.h"
#include <xtl.h>
#include <chrono>

int main(){
    System_Init();

    const double targetMs = 16.6667;
    using clk = std::chrono::high_resolution_clock;

    for(;;){
        auto start = clk::now();

        System_RunFrame();   // CPU + JIT
        System_SyncGPU();    // explicit GPU sync point

        auto end = clk::now();
        double frameMs = std::chrono::duration<double,std::milli>(end-start).count();

        if(frameMs < targetMs){
            DWORD sleepMs = (DWORD)(targetMs - frameMs);
            if(sleepMs > 0) XSleep(sleepMs);
        }
    }

    System_Shutdown();
    return 0;
}
