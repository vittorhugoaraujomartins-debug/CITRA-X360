#pragma once
#include <cstddef>
typedef void(*job_fn_t)(void*);
void Jobs_Init(size_t maxJobs);
int Jobs_Push(job_fn_t fn, void* arg, int affinityHint);
void Jobs_RunAll();
