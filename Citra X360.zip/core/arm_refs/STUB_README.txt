Citra X360 – ARM Core (Filtered)

Este pacote contém APENAS partes úteis do core ARM do Citra
para reaproveitamento conceitual no Xbox 360 (ARM → PPC).

Arquivos mantidos e o que fazer com eles:

- armstate.h / armstate.cpp
  Definem o estado completo da CPU ARM11 (registradores, CPSR, modos).
  -> Usar como base do contexto da CPU no emulador.

- arm_regformat.h
  Layout e descrição de registradores.
  -> Referência direta para JIT ARM → PPC.

- arm_interface.h
  Interface genérica da CPU ARM no Citra.
  -> Adaptar para interface do scheduler do Xbox 360.

- armsupp.h / armsupp.cpp
  Funções auxiliares e semântica de instruções ARM.
  -> Usar como documentação viva para tradução de instruções.

- exclusive_monitor.*
  Implementação de LDREX/STREX e sincronização.
  -> Essencial para multithreading correto.

- vfp/
  Implementação semântica do VFPv2 (ponto flutuante ARM).
  -> Traduzir para PPC FP ou interpretar inicialmente.

Pastas removidas (intencionalmente):
- dynarmic/ : JIT ARM→x86/ARM64 (não portável)
- dyncom/   : JIT legado / interpretador lento

Objetivo final:
Implementar um JIT ARM → PPC simples e previsível,
adequado à CPU in-order do Xbox 360.

Este pacote NÃO é um emulador pronto.
É uma base semântica limpa.