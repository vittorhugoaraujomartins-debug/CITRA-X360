#include <vector>
#include <string>
#include <iostream>
#include <filesystem>
#include <fstream>

namespace fs = std::filesystem;

bool LoadROM(const char* path, std::vector<uint8_t>& out);

bool AutoLoadROM(std::vector<uint8_t>& out) {
    std::string romPath = "ROMs";
    if (!fs::exists(romPath)) {
        std::cout << "ROMs folder not found.\n";
        return false;
    }

    for (auto& entry : fs::directory_iterator(romPath)) {
        if (!entry.is_regular_file()) continue;

        auto ext = entry.path().extension().string();
        if (ext == ".3ds" || ext == ".cxi" || ext == ".cci") {
            std::cout << "Found ROM: " << entry.path().string() << "\n";
            return LoadROM(entry.path().string().c_str(), out);
        }
    }

    std::cout << "No compatible 3DS ROM found.\n";
    return false;
}
