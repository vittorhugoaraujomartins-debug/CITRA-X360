
#pragma once
#include <cstdint>
#include <string>
#include "../cpu/arm11/arm_state.hpp"
#include "../memory/mmu.hpp"

class ELFLoader {
public:
    bool Load(const std::string& path, MMU& mmu, ARMState& state);
};
