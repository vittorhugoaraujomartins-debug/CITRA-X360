#include <fstream>
#include <vector>
#include <cstdint>
#include <iostream>

bool LoadROM(const char* path, std::vector<uint8_t>& out) {
    std::ifstream f(path, std::ios::binary);
    if (!f.good()) return false;
    f.seekg(0, std::ios::end);
    size_t size = f.tellg();
    f.seekg(0, std::ios::beg);
    out.resize(size);
    f.read((char*)out.data(), size);
    std::cout << "ROM loaded: " << size << " bytes\n";
    return true;
}
