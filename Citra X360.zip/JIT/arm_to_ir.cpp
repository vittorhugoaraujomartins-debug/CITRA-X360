#include "arm_to_ir.h"

void ARM_TranslateToIR(u32 opcode, IRBlock* block)
{
    IRInst& ir = block->inst[block->count++];
    ir.op = IR_NOP;
    ir.rd = ir.rn = ir.imm = 0;

    // MOV Rd, #imm
    if ((opcode & 0x0FE00000) == 0x03A00000)
    {
        ir.op  = IR_MOV;
        ir.rd  = (opcode >> 12) & 0xF;
        ir.imm = opcode & 0xFF;
        return;
    }

    // ADD Rd, Rn, #imm
    if ((opcode & 0x0FE00000) == 0x02800000)
    {
        ir.op  = IR_ADD;
        ir.rd  = (opcode >> 12) & 0xF;
        ir.rn  = (opcode >> 16) & 0xF;
        ir.imm = opcode & 0xFF;
        return;
    }

    // SUB Rd, Rn, #imm
    if ((opcode & 0x0FE00000) == 0x02400000)
    {
        ir.op  = IR_SUB;
        ir.rd  = (opcode >> 12) & 0xF;
        ir.rn  = (opcode >> 16) & 0xF;
        ir.imm = opcode & 0xFF;
        return;
    }

    // B
    if ((opcode & 0x0E000000) == 0x0A000000)
    {
        ir.op  = IR_BRANCH;
        ir.imm = opcode & 0x00FFFFFF;
        return;
    }
}

void ARM_TranslateToIR(u32 opcode, IRBlock* block)
{
    IRInst& ir = block->inst[block->count++];
    ZeroMemory(&ir, sizeof(IRInst));

    u32 op = (opcode >> 21) & 0xF;

    // MOV Rd, #imm
    if ((opcode & 0x0FE00000) == 0x03A00000)
    {
        ir.op = IR_MOV;
        ir.rd = (opcode >> 12) & 0xF;
        ir.imm = opcode & 0xFF;
        return;
    }

    // MOV Rd, Rm
    if ((opcode & 0x0FE00010) == 0x01A00000)
    {
        ir.op = IR_MOV;
        ir.rd = (opcode >> 12) & 0xF;
        ir.rm = opcode & 0xF;
        return;
    }

    // ADD
    if ((opcode & 0x0FE00000) == 0x02800000)
    {
        ir.op = IR_ADD;
        ir.rd = (opcode >> 12) & 0xF;
        ir.rn = (opcode >> 16) & 0xF;
        ir.imm = opcode & 0xFF;
        return;
    }

    // SUB
    if ((opcode & 0x0FE00000) == 0x02400000)
    {
        ir.op = IR_SUB;
        ir.rd = (opcode >> 12) & 0xF;
        ir.rn = (opcode >> 16) & 0xF;
        ir.imm = opcode & 0xFF;
        return;
    }

    // CMP Rn, #imm
    if ((opcode & 0x0FE00000) == 0x03500000)
    {
        ir.op = IR_CMP;
        ir.rn = (opcode >> 16) & 0xF;
        ir.imm = opcode & 0xFF;
        return;
    }

    // LDR
    if ((opcode & 0x0C500000) == 0x04100000)
    {
        ir.op = IR_LDR;
        ir.rd = (opcode >> 12) & 0xF;
        ir.rn = (opcode >> 16) & 0xF;
        ir.imm = opcode & 0xFFF;
        return;
    }

    // STR
    if ((opcode & 0x0C500000) == 0x04000000)
    {
        ir.op = IR_STR;
        ir.rd = (opcode >> 12) & 0xF;
        ir.rn = (opcode >> 16) & 0xF;
        ir.imm = opcode & 0xFFF;
        return;
    }

    // BX LR
    if ((opcode & 0x0FFFFFF0) == 0x012FFF10)
    {
        ir.op = IR_RETURN;
        return;
    }

    // B
    if ((opcode & 0x0E000000) == 0x0A000000)
    {
        ir.op = IR_BRANCH;
        ir.imm = opcode & 0x00FFFFFF;
        return;
    }
}