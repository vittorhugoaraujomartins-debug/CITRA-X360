#pragma once
#include <xtl.h>

typedef unsigned int u32;

enum IROp
{
    IR_NOP,
    IR_MOV,
    IR_ADD,
    IR_SUB,
    IR_BRANCH
};

struct IRInst
{
    IROp op;
    u32 rd;
    u32 rn;
    u32 imm;
};

struct IRBlock
{
    u32 count;
    IRInst inst[64];
};

enum IROp
{
    IR_NOP,

    IR_MOV,
    IR_ADD,
    IR_SUB,
    IR_CMP,

    IR_LDR,
    IR_STR,

    IR_BRANCH,
    IR_BRANCH_EQ,
    IR_BRANCH_NE,

    IR_RETURN
};

struct IRInst
{
    IROp op;
    u32 rd;
    u32 rn;
    u32 rm;
    u32 imm;
};

void ARM_TranslateToIR(u32 opcode, IRBlock* block);