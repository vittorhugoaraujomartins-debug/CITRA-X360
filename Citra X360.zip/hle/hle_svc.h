#pragma once
bool HLE_HandleSVC_Core(unsigned int svc_id);
