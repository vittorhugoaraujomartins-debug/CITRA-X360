
#pragma once
#include <cstdint>
void svcOutputDebugString(const char* str);


// Expanded declarations
void Tick();
