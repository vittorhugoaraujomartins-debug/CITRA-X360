#include "hle_svc.h"
extern unsigned int g_arm_pc;
bool HLE_HandleSVC_Core(unsigned int svc_id){ if(svc_id==0x03){ g_arm_pc=0; } return true; }
