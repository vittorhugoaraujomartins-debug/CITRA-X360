#include "hle_dispatch.h"
#include "hle_svc.h"
bool HLE_HandleSVC(unsigned int svc_id){ return HLE_HandleSVC_Core(svc_id); }
