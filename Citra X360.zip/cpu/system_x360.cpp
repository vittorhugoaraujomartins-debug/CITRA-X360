#include "system_x360.h"
#include "arm/arm_dyncom.h"

namespace Core {

static SystemX360 g_system;

SystemX360& SystemX360::GetInstance() {
    return g_system;
}

SystemX360::SystemX360() {}

bool SystemX360::Init(u32 num_cores) {

    memory = std::make_unique<MemorySystem>();
    timing = std::make_unique<TimingSystem>(num_cores);
    gpu = std::make_unique<GPU_X360>();

    cpu_cores.reserve(num_cores);

    for (u32 i = 0; i < num_cores; i++) {
        cpu_cores.push_back(
            std::make_shared<ARM_DynCom>(*memory, i)
        );
    }

    running_core = cpu_cores[0].get();
    powered_on = true;

    return true;
}

void SystemX360::RunLoop() {

    if (!powered_on)
        return;

    for (auto& core : cpu_cores) {

        running_core = core.get();

        core->Run();

        timing->Advance(core->GetID());
    }

    gpu->ProcessCommands();
}

void SystemX360::Shutdown() {
    powered_on = false;
}

ARM_Interface& SystemX360::GetRunningCore() {
    return *running_core;
}

MemorySystem& SystemX360::Memory() {
    return *memory;
}

TimingSystem& SystemX360::Timing() {
    return *timing;
}

GPU_X360& SystemX360::GPU() {
    return *gpu;
}

}