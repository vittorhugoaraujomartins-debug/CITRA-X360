#pragma once

#include "common/common_types.h"
#include "core/arm/skyeye_common/arm_regformat.h"

namespace Core {

struct ARMState {
    // Registros ARM
    u32 r[16]{};
    u32 cpsr{};

    // VFP
    u32 vfp_regs[64]{};
    u32 fpscr{};
    u32 fpexc{};

    // CP15
    u32 cp15[CP15_REGISTER_COUNT]{};

    // Exclusive monitor (LDREX/STREX)
    bool exclusive_valid{false};
    u32 exclusive_addr{0};
    u32 exclusive_value{0};

    bool halted{false};
};

} // namespace Core