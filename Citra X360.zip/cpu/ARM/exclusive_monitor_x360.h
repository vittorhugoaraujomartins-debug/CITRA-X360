#pragma once

#include <vector>
#include <cstdint>

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef u32 VAddr;

namespace Memory {
class MemorySystem;
}

namespace CoreX360 {

class ExclusiveMonitorX360
{
public:
    ExclusiveMonitorX360(Memory::MemorySystem& mem, size_t cores);

    u8 Read8(size_t core, VAddr addr);
    u16 Read16(size_t core, VAddr addr);
    u32 Read32(size_t core, VAddr addr);
    u64 Read64(size_t core, VAddr addr);

    bool Write8(size_t core, VAddr addr, u8 value);
    bool Write16(size_t core, VAddr addr, u16 value);
    bool Write32(size_t core, VAddr addr, u32 value);
    bool Write64(size_t core, VAddr addr, u64 value);

    void Clear(size_t core);

private:
    struct ExclusiveState
    {
        VAddr addr = 0;
        bool valid = false;
    };

    std::vector<ExclusiveState> states;
    Memory::MemorySystem& memory;
};

}