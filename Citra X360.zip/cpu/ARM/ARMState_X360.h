#pragma once

#include <cstdint>
#include <array>

// ============================
// Configurações ARM
// ============================

enum class ARMMode : uint8_t
{
    User        = 0x10,
    FIQ         = 0x11,
    IRQ         = 0x12,
    Supervisor  = 0x13,
    Abort       = 0x17,
    Undefined   = 0x1B,
    System      = 0x1F
};

// ============================
// CPSR Flags
// ============================

struct CPSR
{
    uint32_t value = 0;

    bool N() const { return (value >> 31) & 1; }
    bool Z() const { return (value >> 30) & 1; }
    bool C() const { return (value >> 29) & 1; }
    bool V() const { return (value >> 28) & 1; }

    bool Thumb() const { return (value >> 5) & 1; }

    ARMMode Mode() const
    {
        return static_cast<ARMMode>(value & 0x1F);
    }

    void SetMode(ARMMode mode)
    {
        value = (value & ~0x1F) | static_cast<uint32_t>(mode);
    }
};

// ============================
// ARM State X360
// ============================

class ARMState_X360
{
public:

    ARMState_X360();

    // ========= Registradores =========

    std::array<uint32_t, 16> Reg;   // R0-R15

    uint32_t& PC() { return Reg[15]; }
    uint32_t& LR() { return Reg[14]; }
    uint32_t& SP() { return Reg[13]; }

    // ========= Bancos por modo =========

    std::array<uint32_t, 7> Reg_FIQ;
    std::array<uint32_t, 2> Reg_IRQ;
    std::array<uint32_t, 2> Reg_SVC;
    std::array<uint32_t, 2> Reg_ABORT;
    std::array<uint32_t, 2> Reg_UNDEF;

    // ========= Status =========

    CPSR Cpsr;
    uint32_t Spsr[5];

    // ========= Exclusividade =========

    uint32_t exclusive_address = 0;
    bool exclusive_state = false;

    // ========= Floating Point (stub inicial) =========

    std::array<uint64_t, 32> VFP_Registers;

    // ========= Interface memória =========

    uint32_t Read32(uint32_t address);
    void Write32(uint32_t address, uint32_t value);

    // ========= Controle =========

    void Reset();
    void ChangeMode(ARMMode new_mode);

private:

    ARMMode current_mode;

    void SaveBankedRegisters();
    void LoadBankedRegisters();
};