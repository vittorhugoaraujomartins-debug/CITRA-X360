#include "arm_tick_counts_x360.h"

namespace CoreX360 {

// =====================================================
// POPCOUNT (substitui std::popcount)
// =====================================================

static inline u32 PopCount(u32 v)
{
    v = v - ((v >> 1) & 0x55555555);
    v = (v & 0x33333333) + ((v >> 2) & 0x33333333);
    return (((v + (v >> 4)) & 0x0F0F0F0F) * 0x01010101) >> 24;
}

// =====================================================
// BIT MATCH UTIL
// =====================================================

static u32 DepositBits(u32 val, u32 mask)
{
    u32 res = 0;
    for (u32 bb = 1; mask; bb <<= 1)
    {
        u32 neg_mask = 0 - mask;
        if (val & bb)
            res |= mask & neg_mask;

        mask &= mask - 1;
    }
    return res;
}

// =====================================================
// MATCHER ARG (versão simples sem templates)
// =====================================================

struct MatcherArg
{
    u32 instruction;

    inline u32 GetMask(u32 mask)
    {
        return DepositBits(instruction, mask);
    }
};

// =====================================================
// FUNÇÃO POINTER TYPE
// =====================================================

typedef u64 (*TickFn)(u32 instruction);

// =====================================================
// TICK FUNCTIONS
// =====================================================

static u64 DataProcessing_imm(u32 instruction)
{
    u32 rd = (instruction >> 12) & 0xF;
    return (rd == 15) ? 7 : 1;
}

static u64 DataProcessing_reg(u32 instruction)
{
    u32 rd = (instruction >> 12) & 0xF;
    return (rd == 15) ? 7 : 1;
}

static u64 DataProcessing_rsr(u32 instruction)
{
    u32 rd = (instruction >> 12) & 0xF;
    return (rd == 15) ? 8 : 2;
}

static u64 LoadStoreSingle_imm(u32)
{
    return 2;
}

static u64 LoadStoreSingle_reg(u32 instruction)
{
    // simplificação segura
    return 4;
}

static u64 LoadStoreMultiple(u32 instruction)
{
    u32 reglist = instruction & 0xFFFF;
    return 1 + PopCount(reglist) / 2;
}

// =====================================================
// MATCHER STRUCT
// =====================================================

struct Matcher
{
    u32 mask;
    u32 expect;
    TickFn fn;
};

// =====================================================
// MATCH TABLE (exemplo inicial)
// =====================================================

static const Matcher arm_matchers[] =
{
    { 0x0E000000, 0x0A000000, DataProcessing_imm },
    { 0x0E000000, 0x00000000, DataProcessing_reg },
    { 0x0E000000, 0x02000000, DataProcessing_rsr }
};

// =====================================================
// MAIN DISPATCH
// =====================================================

u64 GetTicksForInstruction(u32 instruction)
{
    for (size_t i = 0; i < sizeof(arm_matchers)/sizeof(Matcher); i++)
    {
        const Matcher& m = arm_matchers[i];

        if ((instruction & m.mask) == m.expect)
            return m.fn(instruction);
    }

    return 1;
}

}