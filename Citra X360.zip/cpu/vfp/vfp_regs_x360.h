#pragma once

// FPSCR bits essenciais
#define VFP_FPSCR_N  (1u << 31)
#define VFP_FPSCR_Z  (1u << 30)
#define VFP_FPSCR_C  (1u << 29)
#define VFP_FPSCR_V  (1u << 28)

#define VFP_FPSCR_RMODE_MASK (3u << 22)

// rounding modes (simplificado)
enum VFP_RoundingMode {
    ROUND_NEAREST = 0,
    ROUND_PLUSINF = 1,
    ROUND_MINUSINF = 2,
    ROUND_ZERO = 3
};