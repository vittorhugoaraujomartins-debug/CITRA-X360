#pragma once
#include <cstdint>

enum class VFP_OpX360 {
    NONE,
    VADD,
    VSUB,
    VMUL,
    VDIV,
    VMLA,
    VMLS,
    VABS,
    VNEG,
    VSQRT,
    VMOV_REG,
    VMOV_IMM
};

struct VFPDecodedX360 {
    VFP_OpX360 op;
    int Sd;
    int Sn;
    int Sm;
    uint32_t imm;
};