#include "memory_system_x360.h"
#include <cstring>

namespace CoreX360 {

// =========================
// Endian swap (Xbox360 BE)
// =========================

template<> u16 MemorySystemX360::ByteSwapIfNeeded(u16 v) {
    return (v >> 8) | (v << 8);
}

template<> u32 MemorySystemX360::ByteSwapIfNeeded(u32 v) {
    return __builtin_bswap32(v);
}

template<> u64 MemorySystemX360::ByteSwapIfNeeded(u64 v) {
    return __builtin_bswap64(v);
}

template<> u8 MemorySystemX360::ByteSwapIfNeeded(u8 v) {
    return v;
}

// =========================
// PageTable
// =========================

void PageTableX360::Map(VAddr vaddr, u8* host, bool r, bool w) {
    size_t index = vaddr >> PAGE_SHIFT;
    entries[index] = {host, r, w};
}

PageEntry* PageTableX360::Get(VAddr addr) {
    return &entries[addr >> PAGE_SHIFT];
}

// =========================
// MemorySystemX360
// =========================

MemorySystemX360::MemorySystemX360() = default;
MemorySystemX360::~MemorySystemX360() = default;

void MemorySystemX360::Initialize() {
    fcram.resize(FCRAM_SIZE);
    vram.resize(VRAM_SIZE);
    dsp.resize(DSP_SIZE);

    // Map FCRAM base 0x20000000 (3DS padrão)
    for (size_t off = 0; off < FCRAM_SIZE; off += PAGE_SIZE) {
        page_table.Map(0x20000000 + off, fcram.data() + off, true, true);
    }

    // Map VRAM
    for (size_t off = 0; off < VRAM_SIZE; off += PAGE_SIZE) {
        page_table.Map(0x18000000 + off, vram.data() + off, true, true);
    }

    // Map DSP
    for (size_t off = 0; off < DSP_SIZE; off += PAGE_SIZE) {
        page_table.Map(0x1FF00000 + off, dsp.data() + off, true, true);
    }
}

// =========================
// Read Impl
// =========================

template<typename T>
T MemorySystemX360::ReadImpl(VAddr addr) {
    auto* entry = page_table.Get(addr);
    if (!entry->readable || !entry->host_ptr)
        return 0;

    T value;
    std::memcpy(&value, entry->host_ptr + (addr & PAGE_MASK), sizeof(T));
    return ByteSwapIfNeeded(value);
}

u8  MemorySystemX360::Read8(VAddr a){ return ReadImpl<u8>(a); }
u16 MemorySystemX360::Read16(VAddr a){ return ReadImpl<u16>(a); }
u32 MemorySystemX360::Read32(VAddr a){ return ReadImpl<u32>(a); }
u64 MemorySystemX360::Read64(VAddr a){ return ReadImpl<u64>(a); }

// =========================
// Write Impl
// =========================

template<typename T>
void MemorySystemX360::WriteImpl(VAddr addr, T value) {
    auto* entry = page_table.Get(addr);
    if (!entry->writable || !entry->host_ptr)
        return;

    value = ByteSwapIfNeeded(value);
    std::memcpy(entry->host_ptr + (addr & PAGE_MASK), &value, sizeof(T));
}

void MemorySystemX360::Write8 (VAddr a,u8  v){ WriteImpl(a,v); }
void MemorySystemX360::Write16(VAddr a,u16 v){ WriteImpl(a,v); }
void MemorySystemX360::Write32(VAddr a,u32 v){ WriteImpl(a,v); }
void MemorySystemX360::Write64(VAddr a,u64 v){ WriteImpl(a,v); }

// =========================
// Exclusive Writes (ARM)
// =========================

bool MemorySystemX360::WriteExclusive8(VAddr a,u8 v,u8 e){
    if(Read8(a)!=e) return false;
    Write8(a,v); return true;
}

bool MemorySystemX360::WriteExclusive16(VAddr a,u16 v,u16 e){
    if(Read16(a)!=e) return false;
    Write16(a,v); return true;
}

bool MemorySystemX360::WriteExclusive32(VAddr a,u32 v,u32 e){
    if(Read32(a)!=e) return false;
    Write32(a,v); return true;
}

bool MemorySystemX360::WriteExclusive64(VAddr a,u64 v,u64 e){
    if(Read64(a)!=e) return false;
    Write64(a,v); return true;
}

} // namespace CoreX360