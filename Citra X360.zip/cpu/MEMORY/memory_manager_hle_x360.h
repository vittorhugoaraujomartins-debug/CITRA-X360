#pragma once
#include <cstdint>
#include <vector>

struct MemoryRegion {
    uint32_t base;
    uint32_t size;
    uint32_t perm;
    bool used;
};

class MemoryManagerHLEX360 {
public:
    void Init(uint32_t base, uint32_t size);

    int ControlMemory(uint32_t addr, uint32_t size, uint32_t perm);
    int QueryMemory(uint32_t addr, MemoryRegion& out);

private:
    std::vector<MemoryRegion> regions;
};