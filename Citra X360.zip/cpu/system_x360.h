#pragma once

#include <memory>
#include <vector>

#include "arm/arm_interface.h"
#include "memory/memory_system.h"
#include "timing/timing_system.h"
#include "gpu/gpu_x360.h"

namespace Core {

class SystemX360 {
public:

    static SystemX360& GetInstance();

    bool Init(u32 num_cores);

    void RunLoop();

    void Shutdown();

    ARM_Interface& GetRunningCore();
    MemorySystem& Memory();
    TimingSystem& Timing();
    GPU_X360& GPU();

private:

    SystemX360();

    std::vector<std::shared_ptr<ARM_Interface>> cpu_cores;
    ARM_Interface* running_core = nullptr;

    std::unique_ptr<MemorySystem> memory;
    std::unique_ptr<TimingSystem> timing;
    std::unique_ptr<GPU_X360> gpu;

    bool powered_on = false;
};

}