#include "ipc_x360.h"
#include "memory_system_x360.h"
#include "service_manager_x360.h"

IPCX360::IPCX360(MemorySystemX360& mem,
                 ServiceManagerX360& sm)
    : memory(mem), services(sm) {}

void IPCX360::SendSyncRequest(uint32_t messagePtr,
                              uint32_t serviceHandle)
{
    uint32_t header = memory.Read32(messagePtr);

    uint16_t cmd   = GetCmd(header);
    uint16_t count = GetParamCount(header);

    // debug opcional
    // printf("IPC cmd=%u params=%u handle=%X\n",
    //        cmd, count, serviceHandle);

    services.HandleSyncRequest(messagePtr, serviceHandle);
}

uint32_t IPCX360::BuildHeader(uint16_t cmd,
                              uint16_t paramCount)
{
    return (paramCount << 16) | cmd;
}

uint16_t IPCX360::GetCmd(uint32_t header)
{
    return header & 0xFFFF;
}

uint16_t IPCX360::GetParamCount(uint32_t header)
{
    return header >> 16;
}