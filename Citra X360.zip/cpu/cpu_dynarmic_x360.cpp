#include "cpu_dynarmic_x360.h"
#include "memory_system_x360.h"
#include "timing_scheduler.h"

namespace CoreX360 {

CPU_Dynarmic::CPU_Dynarmic(MemorySystem& mem, Scheduler& sched)
    : memory(mem), scheduler(sched)
{
#ifdef CPU_DYNARMIC
    Dynarmic::A32::UserConfig config{};

    config.arch_version = Dynarmic::A32::ArchVersion::v6K;
    config.define_unpredictable_behaviour = true;
    config.processor_id = 0;

    config.callbacks = &env;
    config.global_monitor = &exclusiveMonitor;

    if (memory.HasFastmem()) {
        config.fastmem_pointer = memory.GetFastmemBase();
    }

    jit = std::make_unique<Dynarmic::A32::Jit>(config);
#endif
}

void CPU_Dynarmic::Reset()
{
#ifdef CPU_DYNARMIC
    jit->Reset();
    jit->ClearCache();
    jit->Regs().fill(0);
    jit->ExtRegs().fill(0);
#endif
}

void CPU_Dynarmic::RunSlice(u64 cycles)
{
#ifdef CPU_DYNARMIC
    env.ticksLeft = cycles;

    auto reason = jit->Run();

    if (reason != Dynarmic::HaltReason::None) {
        // cache invalidation → continua
        if (Dynarmic::Has(reason, Dynarmic::HaltReason::CacheInvalidation))
            return;
    }

    scheduler.Tick(cycles);
#endif
}

}