#pragma once

#include <cstdint>
#include <functional>
#include <vector>
#include <algorithm>

namespace CitraX360
{

constexpr uint64_t ARM11_CLOCK = 268111856;

using SchedulerCallback = std::function<void(uintptr_t, int)>;

struct ScheduledEvent
{
    int64_t time;
    uint64_t order;
    uintptr_t userData;
    SchedulerCallback callback;

    bool operator>(const ScheduledEvent& other) const
    {
        if(time == other.time)
            return order > other.order;

        return time > other.time;
    }
};

class Scheduler
{
public:

    Scheduler();

    void Schedule(int64_t cyclesAhead,
                  SchedulerCallback cb,
                  uintptr_t userData = 0);

    void Tick(uint64_t cycles);

    uint64_t GetTicks() const;

private:

    std::vector<ScheduledEvent> events;

    uint64_t currentTicks = 0;
    uint64_t fifoCounter = 0;
};

}

struct ScheduledEvent
{
    u64 time;
    u64 order;
    uintptr_t userData;
    SchedulerCallback callback;

    bool operator>(const ScheduledEvent& other) const
    {
        if (time != other.time)
            return time > other.time;
        return order > other.order;
    }
};