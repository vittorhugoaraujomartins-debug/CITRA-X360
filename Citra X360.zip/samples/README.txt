
Compile with ARM GCC:
arm-none-eabi-as hello_world_arm.s -o hello.o
arm-none-eabi-ld hello.o -o hello.elf
Load hello.elf using ELFLoader.
