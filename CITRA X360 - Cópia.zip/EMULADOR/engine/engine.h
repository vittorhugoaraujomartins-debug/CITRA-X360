#pragma once

// Inicializa todos os subsistemas
void Engine_Init();

// Executa 1 frame completo do emulador
void Engine_RunFrame();

// Finaliza tudo corretamente
void Engine_Shutdown();