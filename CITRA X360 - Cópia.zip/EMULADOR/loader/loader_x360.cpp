#include "loader_x360.h"
#include "memory_system_x360.h"
#include "kernel_x360.h"
#include "ncch_x360.h"
#include "elf_loader_x360.h"
#include <fstream>

LoaderX360::LoaderX360(MemorySystemX360& mem, KernelX360& k)
    : memory(mem), kernel(k) {}

std::vector<uint8_t> LoaderX360::ReadFile(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    return std::vector<uint8_t>(
        std::istreambuf_iterator<char>(f),
        std::istreambuf_iterator<char>());
}

bool LoaderX360::LoadFile(const std::string& path) {

    auto data = ReadFile(path);
    if (data.size() < 0x100)
        return false;

    // ELF magic
    if (data[0]==0x7F && data[1]=='E' && data[2]=='L' && data[3]=='F')
        return LoadELF(data);

    // NCCH magic
    if (*(uint32_t*)&data[0x100] == 0x4843434E)
        return LoadNCCH(data);

    return false;
}

bool LoaderX360::LoadELF(const std::vector<uint8_t>& data) {
    ELFLoaderX360 elf(memory);
    if (!elf.Load(data))
        return false;

    entrypoint = elf.GetEntry();
    kernel.CreateMainThread(entrypoint);
    return true;
}

bool LoaderX360::LoadNCCH(const std::vector<uint8_t>& data) {
    NCCHX360 ncch(memory);
    if (!ncch.Load(data))
        return false;

    entrypoint = ncch.GetEntryPoint();
    kernel.CreateMainThread(entrypoint);
    return true;
}