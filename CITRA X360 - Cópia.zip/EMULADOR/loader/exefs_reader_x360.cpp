#include "exefs_reader_x360.h"
#include <cstring>

bool ExeFSReaderX360::Parse(uint8_t* data, uint32_t size)
{
    base = data;
    totalSize = size;
    entries.clear();

    // ExeFS header = 10 entries * 0x10 bytes
    for (int i = 0; i < 10; i++) {
        ExeFSEntryX360 e{};
        std::memcpy(&e, data + i * 0x10, sizeof(e));

        if (e.name[0] == 0)
            continue;

        entries.push_back(e);
    }

    return true;
}

std::vector<uint8_t> ExeFSReaderX360::GetFile(
    const std::string& name)
{
    for (auto& e : entries) {
        std::string n(e.name, e.name + 8);
        n = n.c_str();

        if (n == name) {
            std::vector<uint8_t> out(e.size);
            std::memcpy(out.data(),
                        base + 0x200 + e.offset,
                        e.size);
            return out;
        }
    }

    return {};
}