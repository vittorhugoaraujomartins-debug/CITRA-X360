#include "romfs_reader_x360.h"
#include <cstring>

struct RomFSHeaderX360 {
    uint32_t magic;
    uint32_t masterHashSize;
    uint32_t level1Offset;
    uint32_t level1Size;
    uint32_t level2Offset;
    uint32_t level2Size;
    uint32_t level3Offset;
    uint32_t level3Size;
};

bool RomFSReaderX360::Mount(uint8_t* data, uint32_t size)
{
    if (size < sizeof(RomFSHeaderX360))
        return false;

    base = data;
    total = size;

    RomFSHeaderX360 h{};
    std::memcpy(&h, data, sizeof(h));

    // nível 3 = file data region
    fileDataOffset = h.level3Offset;

    return true;
}

bool RomFSReaderX360::ReadFileRaw(
    uint32_t offset,
    uint32_t size,
    std::vector<uint8_t>& out)
{
    if (!base) return false;
    if (fileDataOffset + offset + size > total)
        return false;

    out.resize(size);
    std::memcpy(out.data(),
                base + fileDataOffset + offset,
                size);
    return true;
}