#pragma once
#include <cstdint>
#include <vector>
#include <string>

struct ExeFSEntryX360 {
    char name[8];
    uint32_t offset;
    uint32_t size;
};

class ExeFSReaderX360 {
public:
    bool Parse(uint8_t* data, uint32_t size);

    std::vector<uint8_t> GetFile(const std::string& name);

private:
    uint8_t* base = nullptr;
    uint32_t totalSize = 0;
    std::vector<ExeFSEntryX360> entries;
};