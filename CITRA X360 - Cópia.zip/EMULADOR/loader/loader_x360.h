#pragma once
#include <string>
#include <vector>
#include <cstdint>

class MemorySystemX360;
class KernelX360;

class LoaderX360 {
public:
    LoaderX360(MemorySystemX360& mem, KernelX360& kernel);

    bool LoadFile(const std::string& path);

    uint32_t GetEntryPoint() const { return entrypoint; }

private:
    bool LoadNCCH(const std::vector<uint8_t>& data);
    bool LoadELF(const std::vector<uint8_t>& data);

    std::vector<uint8_t> ReadFile(const std::string& path);

    MemorySystemX360& memory;
    KernelX360& kernel;

    uint32_t entrypoint = 0;
};