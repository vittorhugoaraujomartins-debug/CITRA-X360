#pragma once
#include <vector>
#include <cstdint>

class MemorySystemX360;

class NCCHX360 {
public:
    NCCHX360(MemorySystemX360& mem);

    bool Load(const std::vector<uint8_t>& file);
    uint32_t GetEntryPoint() const { return entry; }

private:
    MemorySystemX360& memory;
    uint32_t entry = 0;
};