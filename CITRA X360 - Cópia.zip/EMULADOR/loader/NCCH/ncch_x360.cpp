#include "ncch_x360.h"
#include "memory_system_x360.h"
#include <cstring>

NCCHX360::NCCHX360(MemorySystemX360& mem)
    : memory(mem) {}

bool NCCHX360::Load(const std::vector<uint8_t>& file) {

    const uint8_t* hdr = &file[0x100];

    uint32_t exefs_off  = *(uint32_t*)(hdr + 0x1A0) * 0x200;
    uint32_t exefs_size = *(uint32_t*)(hdr + 0x1A4) * 0x200;

    if (exefs_off + exefs_size > file.size())
        return false;

    const uint8_t* exefs = &file[exefs_off];

    // procurar "code.bin"
    for (int i=0;i<10;i++) {
        const uint8_t* e = exefs + i*0x10;

        if (!memcmp(e, "code", 4)) {
            uint32_t off = *(uint32_t*)(e+8);
            uint32_t size = *(uint32_t*)(e+12);

            const uint8_t* code = exefs + off;

            uint32_t load_addr = 0x00100000;

            memory.Map(load_addr, size);
            memory.WriteBlock(load_addr, code, size);

            entry = load_addr;
            return true;
        }
    }

    return false;
}