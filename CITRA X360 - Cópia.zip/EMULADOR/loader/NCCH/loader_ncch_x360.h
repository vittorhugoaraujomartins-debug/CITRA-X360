#pragma once
#include <cstdint>
#include <string>
#include <vector>

class MemorySystemX360;

struct NCCHHeaderX360 {
    char magic[4];          // "NCCH"
    uint32_t contentSize;
    uint64_t programId;

    uint32_t exefsOffset;
    uint32_t exefsSize;

    uint32_t romfsOffset;
    uint32_t romfsSize;
};

class NCCHLoaderX360 {
public:
    NCCHLoaderX360(MemorySystemX360& mem);

    bool LoadFromFile(const std::string& path);

private:
    MemorySystemX360& memory;

    bool ReadHeader(std::vector<uint8_t>& file, NCCHHeaderX360& h);
    bool LoadExeFS(std::vector<uint8_t>& file,
                   const NCCHHeaderX360& h);
};