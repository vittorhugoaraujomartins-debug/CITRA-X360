#include "loader_ncch_x360.h"
#include "memory_system_x360.h"
#include "exefs_reader_x360.h"
#include <fstream>
#include <cstring>

static const uint32_t NCCH_MEDIA_UNIT = 0x200;

NCCHLoaderX360::NCCHLoaderX360(MemorySystemX360& mem)
    : memory(mem) {}

bool NCCHLoaderX360::LoadFromFile(const std::string& path)
{
    std::ifstream f(path, std::ios::binary);
    if (!f.good())
        return false;

    f.seekg(0, std::ios::end);
    size_t size = f.tellg();
    f.seekg(0);

    std::vector<uint8_t> file(size);
    f.read((char*)file.data(), size);

    NCCHHeaderX360 h{};
    if (!ReadHeader(file, h))
        return false;

    return LoadExeFS(file, h);
}

bool NCCHLoaderX360::ReadHeader(
    std::vector<uint8_t>& file,
    NCCHHeaderX360& h)
{
    if (file.size() < 0x200)
        return false;

    std::memcpy(h.magic, &file[0x100], 4);

    if (std::memcmp(h.magic, "NCCH", 4) != 0)
        return false;

    h.contentSize = *(uint32_t*)&file[0x104];
    h.programId   = *(uint64_t*)&file[0x118];

    h.exefsOffset = *(uint32_t*)&file[0x1A0];
    h.exefsSize   = *(uint32_t*)&file[0x1A4];

    h.romfsOffset = *(uint32_t*)&file[0x1B0];
    h.romfsSize   = *(uint32_t*)&file[0x1B4];

    // converter media units → bytes
    h.exefsOffset *= NCCH_MEDIA_UNIT;
    h.exefsSize   *= NCCH_MEDIA_UNIT;
    h.romfsOffset *= NCCH_MEDIA_UNIT;
    h.romfsSize   *= NCCH_MEDIA_UNIT;

    return true;
}

bool NCCHLoaderX360::LoadExeFS(
    std::vector<uint8_t>& file,
    const NCCHHeaderX360& h)
{
    if (h.exefsSize == 0)
        return false;

    ExeFSReaderX360 exefs;
    if (!exefs.Parse(&file[h.exefsOffset], h.exefsSize))
        return false;

    auto code = exefs.GetFile(".code");
    if (code.empty())
        return false;

    // endereço típico ARM11 text
    const uint32_t codeBase = 0x00100000;

    for (size_t i = 0; i < code.size(); i += 4) {
        uint32_t v = *(uint32_t*)&code[i];
        memory.Write32(codeBase + i, v);
    }

    return true;
}


bool NCCHLoaderX360::LoadRomFS(
    std::vector<uint8_t>& file,
    const NCCHHeaderX360& h)
{
    if (!h.romfsSize) return true;

    romfsReader.Mount(
        &file[h.romfsOffset],
        h.romfsSize);

    return true;
}