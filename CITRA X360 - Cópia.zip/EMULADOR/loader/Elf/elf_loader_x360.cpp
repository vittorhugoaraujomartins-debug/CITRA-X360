#include "elf_loader_x360.h"
#include "memory_system_x360.h"

struct ELFHeader {
    uint32_t entry;
    uint32_t phoff;
    uint16_t phnum;
};

struct ProgHeader {
    uint32_t type;
    uint32_t offset;
    uint32_t vaddr;
    uint32_t filesz;
    uint32_t memsz;
};

ELFLoaderX360::ELFLoaderX360(MemorySystemX360& mem)
    : memory(mem) {}

bool ELFLoaderX360::Load(const std::vector<uint8_t>& file) {

    const ELFHeader* h = (const ELFHeader*)&file[0x18];
    entry = h->entry;

    const ProgHeader* ph =
        (const ProgHeader*)&file[h->phoff];

    for (int i=0;i<h->phnum;i++) {

        if (ph[i].type != 1)
            continue;

        memory.Map(ph[i].vaddr, ph[i].memsz);
        memory.WriteBlock(
            ph[i].vaddr,
            &file[ph[i].offset],
            ph[i].filesz);
    }

    return true;
}