#pragma once
#include <cstdint>
#include <vector>
#include <string>

class RomFSReaderX360 {
public:
    bool Mount(uint8_t* data, uint32_t size);

    bool ReadFileRaw(uint32_t offset,
                     uint32_t size,
                     std::vector<uint8_t>& out);

private:
    uint8_t* base = nullptr;
    uint32_t total = 0;

    uint32_t fileDataOffset = 0;
};