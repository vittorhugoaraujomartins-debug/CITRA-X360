#include "x360_thread_pool.hpp"

X360ThreadPool::X360ThreadPool() {
    for (int i=0;i<6;i++)
        workers.emplace_back(&X360ThreadPool::worker, this);
}

X360ThreadPool::~X360ThreadPool() {
    {
        std::lock_guard lock(m);
        stop = true;
    }
    cv.notify_all();
    for (auto& t : workers) t.join();
}

void X360ThreadPool::submit(std::function<void()> job) {
    {
        std::lock_guard lock(m);
        jobs.push(job);
    }
    cv.notify_one();
}

void X360ThreadPool::worker() {
    while (true) {
        std::function<void()> job;

        {
            std::unique_lock lock(m);
            cv.wait(lock, [&]{ return stop || !jobs.empty(); });

            if (stop && jobs.empty()) return;

            job = jobs.front();
            jobs.pop();
        }

        job();
    }
}