#include "cpu_executor_x360.h"

CPUExecutorX360::CPUExecutorX360(
    ARMInterpreterX360& i,
    MemoryManagerX360& m)
    : interp(i), mem(m)
{
}

void CPUExecutorX360::StepBlock()
{
    uint32_t pc = interp.GetPC();

    ArmBlockX360* b = cache.Find(pc);

    if (!b)
        b = &cache.Build(pc, mem);

    dynarec.ExecuteBlock(*b, interp);
}