#pragma once
#include "arm_block_cache_x360.h"
#include "arm_dynarec_x360.h"

class CPUExecutorX360 {
public:

    CPUExecutorX360(
        ARMInterpreterX360& i,
        MemoryManagerX360& m);

    void StepBlock();

private:

    ARMInterpreterX360& interp;
    MemoryManagerX360& mem;

    ArmBlockCacheX360 cache;
    ARMDynarecX360 dynarec;
};