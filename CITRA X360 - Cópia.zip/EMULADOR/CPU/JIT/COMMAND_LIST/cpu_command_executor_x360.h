#pragma once
#include <cstdint>

class MemoryX360;
class ARMInterpreterX360;

class CPUCommandExecutorX360 {
public:

    CPUCommandExecutorX360(
        MemoryX360* mem,
        ARMInterpreterX360* cpu);

    void ExecuteBlock(
        uint32_t addr,
        uint32_t count);

private:

    MemoryX360* memory;
    ARMInterpreterX360* cpuCore;
};