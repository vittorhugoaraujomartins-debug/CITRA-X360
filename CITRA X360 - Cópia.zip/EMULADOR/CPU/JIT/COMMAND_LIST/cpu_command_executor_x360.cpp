#include "cpu_command_executor_x360.h"
#include "memory_x360.h"
#include "arm_interpreter_x360.h"

CPUCommandExecutorX360::CPUCommandExecutorX360(
    MemoryX360* mem,
    ARMInterpreterX360* cpu)
    : memory(mem), cpuCore(cpu)
{
}

void CPUCommandExecutorX360::ExecuteBlock(
    uint32_t addr,
    uint32_t count)
{
    if (!memory || !cpuCore)
        return;

    uint32_t pc = addr;

    for (uint32_t i = 0; i < count; i++)
    {
        uint32_t inst = memory->Read32(pc);

        cpuCore->Execute(inst);

        pc += 4;
    }
}