#include "jit_block_cache_x360.h"

void JitBlockCacheX360::Add(uint32_t pa, uint32_t size)
{
    blocks[pa] = { pa, size };
}

JitBlockX360* JitBlockCacheX360::Find(uint32_t pa)
{
    auto it = blocks.find(pa);
    if (it == blocks.end())
        return nullptr;
    return &it->second;
}

void JitBlockCacheX360::InvalidatePA(uint32_t pa)
{
    blocks.erase(pa);
}

void JitBlockCacheX360::InvalidateRange(uint32_t pa, uint32_t size)
{
    for (auto it = blocks.begin(); it != blocks.end(); )
    {
        uint32_t b = it->second.startPA;

        if (b >= pa && b < pa + size)
            it = blocks.erase(it);
        else
            ++it;
    }
}