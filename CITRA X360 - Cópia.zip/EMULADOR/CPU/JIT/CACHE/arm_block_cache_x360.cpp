#include "arm_block_cache_x360.h"
#include "memory_manager_x360.h"

ArmBlockX360* ArmBlockCacheX360::Find(uint32_t pc)
{
    auto it = cache.find(pc);
    if (it == cache.end())
        return nullptr;

    return &it->second;
}

ArmBlockX360& ArmBlockCacheX360::Build(
    uint32_t pc,
    MemoryManagerX360& mem)
{
    ArmBlockX360 block{};
    block.startPC = pc;

    uint32_t cur = pc;

    // limite simples de bloco
    for (int i = 0; i < 32; i++)
    {
        uint32_t op = mem.Read32(cur);
        ArmDecoded d = decodeARM(op);

        block.decoded.push_back(d);

        cur += 4;

        // parar em branch
        if (d.type == ArmInstrType::Branch ||
            d.type == ArmInstrType::BranchLink ||
            d.type == ArmInstrType::SVC)
            break;
    }

    block.endPC = cur;

    cache[pc] = block;
    return cache[pc];
}