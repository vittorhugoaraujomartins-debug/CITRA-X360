#pragma once
#include <cstdint>
#include <vector>
#include <unordered_map>
#include "arm_decoder.hpp"

struct ArmBlockX360 {
    uint32_t startPC;
    uint32_t endPC;

    std::vector<ArmDecoded> decoded;
};

class ArmBlockCacheX360 {
public:

    ArmBlockX360* Find(uint32_t pc);

    ArmBlockX360& Build(
        uint32_t pc,
        class MemoryManagerX360& mem);

private:

    std::unordered_map<uint32_t, ArmBlockX360> cache;
};