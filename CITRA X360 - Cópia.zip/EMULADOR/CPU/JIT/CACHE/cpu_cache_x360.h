#pragma once
#include <cstdint>
#include <unordered_map>

struct CacheLineX360 {
    uint32_t tag;
    bool valid;
};

class CPUCacheX360 {
public:
    uint32_t ReadPenalty(uint32_t addr);
    uint32_t WritePenalty(uint32_t addr);

    void Invalidate(uint32_t addr);

private:
    static const int LINE_SIZE = 32;

    std::unordered_map<uint32_t, CacheLineX360> lines;
};