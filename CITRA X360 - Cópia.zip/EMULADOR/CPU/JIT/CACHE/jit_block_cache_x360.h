#pragma once
#include <cstdint>
#include <unordered_map>

struct JitBlockX360 {
    uint32_t startPA;
    uint32_t size;
};

class JitBlockCacheX360 {
public:
    void Add(uint32_t pa, uint32_t size);
    JitBlockX360* Find(uint32_t pa);

    void InvalidatePA(uint32_t pa);
    void InvalidateRange(uint32_t pa, uint32_t size);

private:
    std::unordered_map<uint32_t, JitBlockX360> blocks;
};