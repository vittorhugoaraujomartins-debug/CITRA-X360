#include "cpu_cache_x360.h"

uint32_t CPUCacheX360::ReadPenalty(uint32_t addr)
{
    uint32_t line = addr / LINE_SIZE;

    auto it = lines.find(line);

    if (it != lines.end() && it->second.valid)
        return 1; // hit

    lines[line] = { line, true };
    return 10; // miss penalty
}

uint32_t CPUCacheX360::WritePenalty(uint32_t addr)
{
    uint32_t line = addr / LINE_SIZE;

    lines[line] = { line, true };
    return 6;
}

void CPUCacheX360::Invalidate(uint32_t addr)
{
    uint32_t line = addr / LINE_SIZE;
    lines.erase(line);
}