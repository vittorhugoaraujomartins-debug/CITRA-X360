#pragma once
#include <cstdint>
#include <unordered_map>

struct TLBEntryX360 {
    uint32_t vpage;
    uint32_t ppage;
    bool valid;
};

class TLBX360 {
public:
    bool Lookup(uint32_t vaddr, uint32_t& outPA);
    void Insert(uint32_t vaddr, uint32_t paddr);

    void InvalidateVA(uint32_t vaddr);
    void InvalidateAll();

private:
    static const uint32_t PAGE_SHIFT = 12;

    std::unordered_map<uint32_t, TLBEntryX360> table;
};