#pragma once
#include <cstdint>

class ARMRegisterFileX360 {
public:

    uint32_t R[16];   // r0–r15
    uint32_t CPSR;

    void Reset()
    {
        for (int i = 0; i < 16; i++)
            R[i] = 0;

        CPSR = 0;
    }

    uint32_t& PC() { return R[15]; }
    uint32_t& LR() { return R[14]; }
    uint32_t& SP() { return R[13]; }

    // flags helpers
    bool FlagZ() const { return CPSR & (1<<30); }
    bool FlagN() const { return CPSR & (1<<31); }

    void SetZ(bool v)
    {
        if (v) CPSR |= (1<<30);
        else   CPSR &= ~(1<<30);
    }

    void SetN(bool v)
    {
        if (v) CPSR |= (1<<31);
        else   CPSR &= ~(1<<31);
    }
};