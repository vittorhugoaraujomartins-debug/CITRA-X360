#pragma once
#include <cstdint>

struct ARMCPUX360 {

    uint32_t R[16];
    uint32_t CPSR;

    // ===== MMU / CACHE CONTROL =====
    bool mmuEnabled = false;
    bool icacheEnabled = false;
    bool dcacheEnabled = false;

    uint32_t ttbr0 = 0;   // translation table base
    uint32_t domain = 0;

    // ===== stats =====
    uint64_t cycles = 0;
};