#include "tlb_x360.h"

bool TLBX360::Lookup(uint32_t vaddr, uint32_t& outPA)
{
    uint32_t vp = vaddr >> PAGE_SHIFT;

    auto it = table.find(vp);
    if (it == table.end() || !it->second.valid)
        return false;

    outPA = (it->second.ppage << PAGE_SHIFT) | (vaddr & 0xFFF);
    return true;
}

void TLBX360::Insert(uint32_t vaddr, uint32_t paddr)
{
    uint32_t vp = vaddr >> PAGE_SHIFT;
    uint32_t pp = paddr >> PAGE_SHIFT;

    table[vp] = { vp, pp, true };
}

void TLBX360::InvalidateVA(uint32_t vaddr)
{
    table.erase(vaddr >> PAGE_SHIFT);
}

void TLBX360::InvalidateAll()
{
    table.clear();
}