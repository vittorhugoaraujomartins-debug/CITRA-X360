#pragma once
#include <cstdint>

class JitRegisterMapX360 {
public:

    // ARM reg → PPC reg (fixo por enquanto)
    int MapARM(int armReg) const
    {
        // r0–r12 → r3–r15 PPC
        if (armReg <= 12)
            return 3 + armReg;

        // SP LR PC fallback
        return -1;
    }
};