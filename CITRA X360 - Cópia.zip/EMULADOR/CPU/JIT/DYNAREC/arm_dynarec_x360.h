#pragma once
#include <vector>
#include <string>
#include "arm_block_cache_x360.h"

class ARMDynarecX360 {
public:

    void ExecuteBlock(
        ArmBlockX360& block,
        class ARMInterpreterX360& interp);

private:

    std::vector<std::string> Compile(
        ArmBlockX360& block);
};