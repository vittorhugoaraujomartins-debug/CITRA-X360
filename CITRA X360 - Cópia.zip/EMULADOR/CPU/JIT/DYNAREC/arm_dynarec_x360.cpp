#include "arm_dynarec_x360.h"
#include "arm_to_ppc.hpp"
#include "arm_interpreter_x360.h"

std::vector<std::string>
ARMDynarecX360::Compile(ArmBlockX360& block)
{
    std::vector<std::string> out;

    for (auto& d : block.decoded)
    {
        ArmInstr simple = decodeARM(d.raw);
        out.push_back(armToPPC(simple));
    }

    return out;
}

void ARMDynarecX360::ExecuteBlock(
    ArmBlockX360& block,
    ARMInterpreterX360& interp)
{
    auto code = Compile(block);

    // Skeleton: executa via interpreter ainda
    // (JIT real entra depois aqui)

    for (auto& d : block.decoded)
        interp.exec(d);
}