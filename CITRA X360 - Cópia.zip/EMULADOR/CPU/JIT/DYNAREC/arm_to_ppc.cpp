#include "arm_to_ppc.hpp"
#include <sstream>

static std::string r(int n) {
    return "r" + std::to_string(n);
}

std::string armToPPC(const ArmInstr& a) {

    std::ostringstream o;

    switch(a.op) {

    case ArmOp::ADD:
        o << "add " << r(a.rd) << "," << r(a.rn) << "," << r(a.rm);
        break;

    case ArmOp::SUB:
        o << "subf " << r(a.rd) << "," << r(a.rm) << "," << r(a.rn);
        break;

    case ArmOp::MOV:
        o << "mr " << r(a.rd) << "," << r(a.rm);
        break;

    case ArmOp::CMP:
        o << "cmpw " << r(a.rn) << "," << r(a.rm);
        break;

    case ArmOp::LDR:
        o << "lwz " << r(a.rd) << "," << a.imm << "(" << r(a.rn) << ")";
        break;

    case ArmOp::STR:
        o << "stw " << r(a.rd) << "," << a.imm << "(" << r(a.rn) << ")";
        break;

    case ArmOp::B:
        o << "b target_" << a.imm;
        break;

    case ArmOp::BL:
        o << "bl target_" << a.imm;
        break;

    case ArmOp::SVC:
        o << "sc"; // syscall PPC
        break;

    default:
        o << "nop";
    }

    return o.str();
}