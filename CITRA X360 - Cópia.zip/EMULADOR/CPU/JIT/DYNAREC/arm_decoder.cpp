#include "arm_decoder.hpp"

static inline uint32_t bits(uint32_t v, int hi, int lo) {
    return (v >> lo) & ((1u << (hi - lo + 1)) - 1);
}

ArmDecoded decodeARM(uint32_t op) {
    ArmDecoded d{};
    d.raw = op;
    d.cond = bits(op,31,28);
    d.type = ArmInstrType::Unknown;

    uint32_t classBits = bits(op,27,25);

    // -------------------------
    // Branch
    // -------------------------
    if (classBits == 0b101) {
        bool link = bits(op,24,24);
        d.type = link ? ArmInstrType::BranchLink : ArmInstrType::Branch;

        int32_t imm24 = bits(op,23,0);
        if (imm24 & 0x800000) imm24 |= 0xFF000000;
        d.imm = imm24 << 2;
        return d;
    }

    // -------------------------
    // SVC
    // -------------------------
    if ((op & 0x0F000000) == 0x0F000000) {
        d.type = ArmInstrType::SVC;
        d.imm = bits(op,23,0);
        return d;
    }

    // -------------------------
    // Load / Store
    // -------------------------
    if (classBits == 0b010 || classBits == 0b011) {
        d.type = ArmInstrType::LoadStore;
        d.rn = bits(op,19,16);
        d.rd = bits(op,15,12);
        d.immediate = !bits(op,25,25);
        d.imm = bits(op,11,0);
        return d;
    }

    // -------------------------
    // Load/Store Multiple
    // -------------------------
    if (classBits == 0b100) {
        d.type = ArmInstrType::LoadStoreMultiple;
        d.rn = bits(op,19,16);
        return d;
    }

    // -------------------------
    // Data Processing
    // -------------------------
    if ((op & 0x0C000000) == 0x00000000) {
        d.type = ArmInstrType::DataProcessing;

        d.opcode = bits(op,24,21);
        d.setFlags = bits(op,20,20);
        d.rn = bits(op,19,16);
        d.rd = bits(op,15,12);
        d.immediate = bits(op,25,25);
        d.rm = bits(op,3,0);

        if (d.immediate)
            d.imm = bits(op,7,0);

        return d;
    }

    return d;
}


#include "arm_decoder.hpp"

ArmInstr decodeARM(uint32_t op) {

    ArmInstr d{};
    d.op = ArmOp::UNKNOWN;

    uint32_t top = (op >> 25) & 0x7;

    // ======================
    // DATA PROCESSING
    // ======================
    if (top == 0b001 || top == 0b000) {
        uint8_t opcode = (op >> 21) & 0xF;

        d.rd = (op >> 12) & 0xF;
        d.rn = (op >> 16) & 0xF;
        d.rm = op & 0xF;
        d.imm = op & 0xFF;

        switch(opcode) {
            case 4: d.op = ArmOp::ADD; break;
            case 2: d.op = ArmOp::SUB; break;
            case 13: d.op = ArmOp::MOV; break;
            case 10: d.op = ArmOp::CMP; break;
        }
        return d;
    }

    // ======================
    // LOAD / STORE
    // ======================
    if (top == 0b010) {
        bool L = (op >> 20) & 1;

        d.rd = (op >> 12) & 0xF;
        d.rn = (op >> 16) & 0xF;
        d.imm = op & 0xFFF;

        d.op = L ? ArmOp::LDR : ArmOp::STR;
        return d;
    }

    // ======================
    // BRANCH
    // ======================
    if ((op >> 25) == 0b101) {
        bool link = (op >> 24) & 1;
        int32_t off = (op & 0xFFFFFF) << 2;

        d.op = link ? ArmOp::BL : ArmOp::B;
        d.imm = off;
        return d;
    }

    // ======================
    // SVC
    // ======================
    if ((op & 0x0F000000) == 0x0F000000) {
        d.op = ArmOp::SVC;
        d.imm = op & 0xFFFFFF;
        return d;
    }

    return d;
}