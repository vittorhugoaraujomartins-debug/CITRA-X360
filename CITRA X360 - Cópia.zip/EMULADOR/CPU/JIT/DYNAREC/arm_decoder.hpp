#pragma once
#include <cstdint>

enum class ArmInstrType {
    Unknown,

    DataProcessing,
    Multiply,
    LoadStore,
    LoadStoreMultiple,
    Branch,
    BranchLink,
    SVC,
};

struct ArmDecoded {
    ArmInstrType type;

    uint32_t raw;

    uint8_t cond;

    // campos comuns
    uint8_t opcode;
    uint8_t rn;
    uint8_t rd;
    uint8_t rm;

    bool setFlags;
    bool immediate;

    int32_t imm;
};


enum class ArmOp {
    ADD, SUB, MOV, CMP,
    LDR, STR,
    B, BL,
    SVC,
    UNKNOWN
};

struct ArmInstr {
    ArmOp op;
    uint8_t rd, rn, rm;
    uint32_t imm;
};