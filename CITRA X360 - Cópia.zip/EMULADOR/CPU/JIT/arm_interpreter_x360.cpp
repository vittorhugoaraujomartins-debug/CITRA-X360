#include "arm_interpreter.hpp"
#include "memory.hpp"
#include "kernel.hpp"

ARMInterpreter::ARMInterpreter(Memory& m, Kernel& k)
    : mem(m), kernel(k) {}


// =========================
// FLAGS
// =========================

void ARMInterpreter::setZN(uint32_t v) {
    // Z
    if (v == 0) cpsr |= (1<<30);
    else cpsr &= ~(1<<30);

    // N
    if (v & 0x80000000) cpsr |= (1<<31);
    else cpsr &= ~(1<<31);
}


// =========================
// COND CHECK
// =========================

bool ARMInterpreter::condPassed(uint8_t cond) {
    bool Z = cpsr & (1<<30);
    bool N = cpsr & (1<<31);

    switch(cond) {
        case 0x0: return Z;        // EQ
        case 0x1: return !Z;       // NE
        case 0xA: return N == 0;   // PL
        case 0xB: return N != 0;   // MI
        case 0xE: return true;     // AL
        default: return true;      // simplificado
    }
}


// =========================
// STEP
// =========================

void ARMInterpreter::step() {
    uint32_t pc = regs[15];
    uint32_t op = mem.read32(pc);

    regs[15] += 4;

    ArmDecoded d = decodeARM(op);

    if (!condPassed(d.cond))
        return;

    exec(d);
}


// =========================
// EXECUTOR CENTRAL
// =========================

void ARMInterpreter::exec(const ArmDecoded& d) {

    switch (d.type) {

    // =====================
    // DATA PROCESSING
    // =====================
    case ArmInstrType::DataProcessing: {
        uint32_t op2 = d.immediate ? d.imm : regs[d.rm];
        uint32_t rn  = regs[d.rn];
        uint32_t out = 0;

        switch (d.opcode) {

        case 0: out = rn & op2; break;      // AND
        case 1: out = rn ^ op2; break;      // EOR
        case 2: out = rn - op2; break;      // SUB
        case 4: out = rn + op2; break;      // ADD
        case 12: out = rn | op2; break;     // ORR
        case 13: out = op2; break;          // MOV

        case 10: {                          // CMP
            uint32_t r = rn - op2;
            setZN(r);
            return;
        }

        default:
            return; // raso: ignora não suportado
        }

        regs[d.rd] = out;
        if (d.setFlags) setZN(out);
        return;
    }

    // =====================
    // LOAD / STORE
    // =====================
    case ArmInstrType::LoadStore: {
        uint32_t addr = regs[d.rn] + d.imm;

        bool load = (d.raw >> 20) & 1;

        if (load)
            regs[d.rd] = mem.read32(addr);
        else
            mem.write32(addr, regs[d.rd]);

        return;
    }

    // =====================
    // LOAD/STORE MULTIPLE (rasa)
    // =====================
    case ArmInstrType::LoadStoreMultiple: {
        // stub simples
        return;
    }

    // =====================
    // MULTIPLY (rasa)
    // =====================
    case ArmInstrType::Multiply: {
        regs[d.rd] = regs[d.rm] * regs[d.rn];
        return;
    }

    // =====================
    // BRANCH
    // =====================
    case ArmInstrType::Branch:
        regs[15] += d.imm;
        return;

    case ArmInstrType::BranchLink:
        regs[14] = regs[15];
        regs[15] += d.imm;
        return;

    // =====================
    // SVC → Kernel
    // =====================
    case ArmInstrType::SVC:
        kernel.serviceSVC(d.imm & 0xFF);
        return;

    default:
        return;
    }
}

#include "arm_interpreter_x360.h"

ARMInterpreterX360::ARMInterpreterX360(
    ARMStateX360& s,
    MemoryManagerX360& m)
    : cpu(s), mem(m) {}

void ARMInterpreterX360::Step() {
    uint32_t pc = cpu.R[15];
    uint32_t op = mem.Read32(pc);

    cpu.R[15] += 4;

    uint32_t type = (op >> 26) & 3;

    if (type == 0)
        ExecDataProc(op);
    else if (type == 1)
        ExecLoadStore(op);
    else if ((op >> 25) == 5)
        ExecBranch(op);
}

void ARMInterpreterX360::ExecDataProc(uint32_t op) {
    uint32_t rd = (op >> 12) & 0xF;
    uint32_t rn = (op >> 16) & 0xF;

    cpu.R[rd] = cpu.R[rn]; // MOV base
}

void ARMInterpreterX360::ExecLoadStore(uint32_t op) {
    uint32_t rd = (op >> 12) & 0xF;
    uint32_t rn = (op >> 16) & 0xF;

    cpu.R[rd] = mem.Read32(cpu.R[rn]);
}

void ARMInterpreterX360::ExecBranch(uint32_t op) {
    int32_t off = (op & 0x00FFFFFF) << 2;
    cpu.R[15] += off;
}

void ARMInterpreterX360::Run(uint32_t cycles) {
    for (uint32_t i = 0; i < cycles; i++)
        Step();
}

uint32_t ARMInterpreterX360::GetPC() const {
    return cpu.R[15];
}