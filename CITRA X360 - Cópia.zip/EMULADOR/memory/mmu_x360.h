#pragma once
#include <cstdint>

class MemoryManagerX360;
struct ARMCPUX360;

class MMUX360 {
public:
    MMUX360(MemoryManagerX360& mem, ARMCPUX360& cpu);

    uint32_t Translate(uint32_t vaddr, bool write);

private:
    MemoryManagerX360& memory;
    ARMCPUX360& cpu;

    uint32_t WalkPageTable(uint32_t vaddr);
};

#include "tlb_x360.h"

class MMUX360 {
public:
    MMUX360(MemoryManagerX360&, ARMCPUX360&);

    uint32_t Translate(uint32_t vaddr, bool write);

    void InvalidateTLB();
    void InvalidateTLB_VA(uint32_t va);

private:
    uint32_t WalkPageTable(uint32_t vaddr);

    TLBX360 tlb;
    MemoryManagerX360& memory;
    ARMCPUX360& cpu;
};