#include "mmu_x360.h"
#include "memory_manager_x360.h"
#include "arm_cpu_x360.h"

MMUX360::MMUX360(
    MemoryManagerX360& mem,
    ARMCPUX360& c)
    : memory(mem), cpu(c) {}

uint32_t MMUX360::Translate(uint32_t vaddr, bool write)
{
    if (!cpu.mmuEnabled)
        return vaddr;

    return WalkPageTable(vaddr);
}

uint32_t MMUX360::WalkPageTable(uint32_t va)
{
    uint32_t l1base = cpu.ttbr0 & 0xFFFFC000;

    uint32_t l1index = va >> 20;
    uint32_t l1desc = memory.Read32(l1base + l1index * 4);

    uint32_t type = l1desc & 3;

    // =====================
    // SECTION (1MB)
    // =====================
    if (type == 2) {
        uint32_t base = l1desc & 0xFFF00000;
        return base | (va & 0xFFFFF);
    }

    // =====================
    // PAGE TABLE
    // =====================
    if (type == 1) {
        uint32_t l2base = l1desc & 0xFFFFFC00;
        uint32_t l2index = (va >> 12) & 0xFF;

        uint32_t l2desc = memory.Read32(l2base + l2index * 4);
        uint32_t type2 = l2desc & 3;

        // small page 4KB
        if (type2 == 2 || type2 == 3) {
            uint32_t base = l2desc & 0xFFFFF000;
            return base | (va & 0xFFF);
        }
    }

    // fallback identity
    return va;
}


uint32_t MMUX360::Translate(uint32_t va, bool write)
{
    if (!cpu.mmuEnabled)
        return va;

    uint32_t pa;

    if (tlb.Lookup(va, pa))
        return pa;

    pa = WalkPageTable(va);

    tlb.Insert(va, pa);

    return pa;
}

void MMUX360::InvalidateTLB()
{
    tlb.InvalidateAll();
}

void MMUX360::InvalidateTLB_VA(uint32_t va)
{
    tlb.InvalidateVA(va);
}