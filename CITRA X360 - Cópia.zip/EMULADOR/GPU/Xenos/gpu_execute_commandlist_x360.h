#pragma once
#include <cstdint>

class MemorySystemX360;
class GXCommandDecoderX360;
class GXRegisterFileX360;
class GXVertexPipelineX360;

class GPUCommandListExecutorX360 {
public:
    GPUCommandListExecutorX360(
        MemorySystemX360& mem,
        GXCommandDecoderX360& dec,
        GXRegisterFileX360& regs,
        GXVertexPipelineX360& vp);

    void Execute(uint32_t addr, uint32_t size);

private:
    MemorySystemX360& memory;
    GXCommandDecoderX360& decoder;
    GXRegisterFileX360& regFile;
    GXVertexPipelineX360& vertexPipe;
};