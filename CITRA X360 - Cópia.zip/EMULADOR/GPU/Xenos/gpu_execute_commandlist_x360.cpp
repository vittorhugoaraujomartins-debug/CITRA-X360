#include "gpu_execute_commandlist_x360.h"
#include "memory_system_x360.h"
#include "gx_decoder_x360.h"
#include "gx_register_file_x360.h"
#include "gx_vertex_pipeline_x360.h"

GPUCommandListExecutorX360::GPUCommandListExecutorX360(
    MemorySystemX360& mem,
    GXCommandDecoderX360& dec,
    GXRegisterFileX360& regs,
    GXVertexPipelineX360& vp)
    : memory(mem), decoder(dec),
      regFile(regs), vertexPipe(vp) {}

void GPUCommandListExecutorX360::Execute(
    uint32_t addr,
    uint32_t size)
{
    uint32_t ptr = addr;
    uint32_t end = addr + size;

    while (ptr < end)
    {
        uint32_t cmd = memory.Read32(ptr);
        ptr += 4;

        GXDecodedCmdX360 d = decoder.Decode(cmd);

        switch (d.type)
        {
            case GXCmdTypeX360::WRITE_REG:
                regFile.Write(d.reg, d.value);
                break;

            case GXCmdTypeX360::DRAW:
                vertexPipe.Draw(
                    regFile.GetVertexBase(),
                    regFile.GetVertexCount());
                break;

            case GXCmdTypeX360::TEXTURE:
                regFile.SetTexture(
                    d.slot,
                    d.addr,
                    d.size);
                break;

            default:
                break;
        }
    }
}