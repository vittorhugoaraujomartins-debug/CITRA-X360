#pragma once
#include <cstdint>

struct XenosDrawCallX360
{
    void* vertexPtr;
    uint32_t vertexCount;

    void* texturePtr;
    uint32_t texW;
    uint32_t texH;
};