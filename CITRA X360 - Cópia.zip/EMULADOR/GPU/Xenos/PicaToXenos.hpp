#pragma once
#include "XenosBackend.hpp"

class PicaToXenos {
public:
    PicaToXenos(XenosBackend& gpu) : gpu(gpu) {}

    void drawStubTriangle() {
        XenosVertex a{100,100,0,1,0,0,0xFFFF0000};
        XenosVertex b{300,120,0,1,0,0,0xFF00FF00};
        XenosVertex c{200,300,0,1,0,0,0xFF0000FF};

        gpu.drawTriangle(a,b,c);
    }

private:
    XenosBackend& gpu;
};