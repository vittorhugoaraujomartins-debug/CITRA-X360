#include "gx_decoder_x360.h"
#include "gx_command_defs_x360.h"
#include "memory_manager_x360.h"
#include "gx_state_x360.h"
#include "xenos_gpu_bridge_x360.h"

GXDecoderX360::GXDecoderX360(
    MemoryManagerX360& mem,
    GXStateX360& state,
    XenosGPUBridgeX360& g)
    : memory(mem), gx(state), gpu(g)
{
}

void GXDecoderX360::ExecuteList(uint32_t addr, uint32_t size)
{
    uint32_t ptr = addr;
    uint32_t end = addr + size;

    while (ptr < end)
    {
        uint32_t word = memory.Read32(ptr);
        ptr += 4;

        uint16_t cmd   = word >> 16;
        uint16_t param = word & 0xFFFF;

        ExecuteCommand(cmd, param);
    }
}

void GXDecoderX360::ExecuteCommand(
    uint16_t cmd,
    uint32_t param)
{
    switch (cmd)
    {
    case GX_SET_VTX_BASE:
        gx.vertexBase = param;
        break;

    case GX_SET_VTX_COUNT:
        gx.vertexCount = param;
        break;

    case GX_SET_TEX_ADDR:
        gx.texAddr = param;
        break;

    case GX_SET_TEX_SIZE:
        gx.texW = param >> 8;
        gx.texH = param & 0xFF;
        break;

    case GX_DRAW_TRIANGLES:
        gpu.DrawTriangles(
            gx.vertexBase,
            gx.vertexCount,
            gx.texAddr,
            gx.texW,
            gx.texH);
        break;

    default:
        // comando não suportado — ignora
        break;
    }
}