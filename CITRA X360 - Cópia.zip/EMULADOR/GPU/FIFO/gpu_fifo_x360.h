#pragma once
#include <cstdint>
#include <vector>

struct GPUFifoCmdX360 {
    uint32_t cmd;
    uint32_t arg;
};

class GPUFifoX360 {
public:

    void Reset();

    void Push(uint32_t cmd, uint32_t arg);
    bool Pop(GPUFifoCmdX360& out);

    bool Empty() const;
    int Size() const;

private:

    static const int MAX_FIFO = 8192;

    GPUFifoCmdX360 buffer[MAX_FIFO];
    int head = 0;
    int tail = 0;
    int count = 0;
};