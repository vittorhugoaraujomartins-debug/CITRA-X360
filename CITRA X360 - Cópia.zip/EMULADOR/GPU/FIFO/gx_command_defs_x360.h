#pragma once
#include <cstdint>

enum GXCommandX360 : uint16_t
{
    GX_NOP              = 0x0000,
    GX_SET_VTX_BASE     = 0x0100,
    GX_SET_VTX_COUNT    = 0x0101,
    GX_SET_TEX_ADDR     = 0x0200,
    GX_SET_TEX_SIZE     = 0x0201,
    GX_DRAW_TRIANGLES   = 0x0300,
};