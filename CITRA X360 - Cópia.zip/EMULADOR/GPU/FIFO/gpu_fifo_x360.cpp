#include "gpu_fifo_x360.h"

void GPUFifoX360::Reset() {
    head = tail = count = 0;
}

bool GPUFifoX360::Empty() const {
    return count == 0;
}

int GPUFifoX360::Size() const {
    return count;
}

void GPUFifoX360::Push(uint32_t cmd, uint32_t arg) {

    if (count >= MAX_FIFO)
        return; // overflow drop (beta safe)

    buffer[tail].cmd = cmd;
    buffer[tail].arg = arg;

    tail = (tail + 1) % MAX_FIFO;
    count++;
}

bool GPUFifoX360::Pop(GPUFifoCmdX360& out) {

    if (count == 0)
        return false;

    out = buffer[head];
    head = (head + 1) % MAX_FIFO;
    count--;

    return true;
}