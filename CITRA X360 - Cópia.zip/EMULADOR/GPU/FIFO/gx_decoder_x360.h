#pragma once
#include <cstdint>

class MemoryManagerX360;
class GXStateX360;
class XenosGPUBridgeX360;

class GXDecoderX360 {
public:

    GXDecoderX360(
        MemoryManagerX360& mem,
        GXStateX360& state,
        XenosGPUBridgeX360& gpu);

    void ExecuteList(uint32_t addr, uint32_t size);

private:

    void ExecuteCommand(uint16_t cmd, uint32_t param);

    MemoryManagerX360& memory;
    GXStateX360& gx;
    XenosGPUBridgeX360& gpu;
};