#pragma once
#include <cstdint>

struct GXStateX360
{
    uint32_t vertexBase = 0;
    uint32_t vertexCount = 0;

    uint32_t texAddr = 0;
    uint32_t texW = 0;
    uint32_t texH = 0;

    void Reset()
    {
        vertexBase = 0;
        vertexCount = 0;
        texAddr = 0;
        texW = texH = 0;
    }
};