#include "gpu_fifo_x360.h"
#include "xenos_gpu_bridge_x360.h"

static XenosGPUBridgeX360 gpu;

void ExecuteFifoCmd(const GPUFifoCmdX360& c)
{
    switch (c.cmd)
    {
        case 0x01:
            gpu.SetViewport(c.arg);
            break;

        case 0x02:
            gpu.Clear(c.arg);
            break;

        case 0x10:
            gpu.DrawFakeTriangle();
            break;

        case 0x20:
            gpu.BindTexture(c.arg);
            break;

        default:
            break;
    }
}

void DrainGPUFifo(GPUFifoX360& fifo)
{
    GPUFifoCmdX360 c;

    while (fifo.Pop(c))
        ExecuteFifoCmd(c);
}