#pragma once
#include <cstdint>

class XenosFramebuffer {
public:
    XenosFramebuffer(int w, int h);

    void clear(uint32_t color);
    void setPixel(int x, int y, uint32_t color);

    uint32_t* data();
    int width() const;
    int height() const;

private:
    int m_width;
    int m_height;
    uint32_t* m_buffer;
};