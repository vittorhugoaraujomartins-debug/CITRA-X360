#include "XenosFramebuffer.hpp"
#include <cstring>

XenosFramebuffer::XenosFramebuffer(int w, int h)
    : m_width(w), m_height(h) {
    m_buffer = new uint32_t[w * h];
}

void XenosFramebuffer::clear(uint32_t color) {
    for (int i = 0; i < m_width * m_height; i++)
        m_buffer[i] = color;
}

void XenosFramebuffer::setPixel(int x, int y, uint32_t color) {
    if (x < 0 || y < 0 || x >= m_width || y >= m_height) return;
    m_buffer[y * m_width + x] = color;
}

uint32_t* XenosFramebuffer::data() { return m_buffer; }
int XenosFramebuffer::width() const { return m_width; }
int XenosFramebuffer::height() const { return m_height; }