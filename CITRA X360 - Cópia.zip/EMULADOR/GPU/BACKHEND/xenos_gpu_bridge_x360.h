#pragma once
#include <cstdint>

class XenosGPUBridgeX360 {
public:
    void SubmitCommand(uint32_t cmd);
    void DrawFakeTriangle();
};

void DrawTriangles(
    uint32_t vtxAddr,
    uint32_t count,
    uint32_t texAddr,
    uint32_t w,
    uint32_t h);