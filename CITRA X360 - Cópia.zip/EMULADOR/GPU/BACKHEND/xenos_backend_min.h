#pragma once
#include <string>

class XenosBackendMin {
public:
    static void EmitALU(const std::string& op);
};