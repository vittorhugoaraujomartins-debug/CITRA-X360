#pragma once
#include <cstdint>

struct GPUTextureX360 {
    uint32_t width;
    uint32_t height;
    uint32_t format;

    uint32_t guestAddr;   // addr na RAM emulada
    void*    xenosHandle; // ponteiro GPU real
};