#include "texture_uploader_x360.h"
#include "memory_manager_x360.h"
#include "xenos_gpu_bridge_x360.h"

TextureUploaderX360::TextureUploaderX360(
    MemoryManagerX360& m,
    XenosGPUBridgeX360& g)
    : mem(m), gpu(g)
{
}

GPUTextureX360 TextureUploaderX360::Upload(
    uint32_t guestAddr,
    uint32_t w,
    uint32_t h,
    uint32_t fmt)
{
    GPUTextureX360 tex{};
    tex.width = w;
    tex.height = h;
    tex.format = fmt;
    tex.guestAddr = guestAddr;

    void* data = mem.GetPointer(guestAddr);

    tex.xenosHandle = gpu.CreateTexture(
        data,
        w,
        h,
        fmt);

    return tex;
}