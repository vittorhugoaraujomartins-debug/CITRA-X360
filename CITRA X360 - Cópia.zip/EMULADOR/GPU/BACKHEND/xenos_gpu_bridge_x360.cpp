#include "xenos_gpu_bridge_x360.h"
#include <cstdio>

void XenosGPUBridgeX360::SubmitCommand(
    uint32_t cmd)
{
    // stub command buffer
}

void XenosGPUBridgeX360::DrawFakeTriangle() {
    // placeholder — depois vira draw real
    printf("[XENOS] draw call\n");
}

void* CreateTexture(
    void* data,
    uint32_t w,
    uint32_t h,
    uint32_t fmt);


void* XenosGPUBridgeX360::CreateTexture(
    void* data,
    uint32_t w,
    uint32_t h,
    uint32_t fmt)
{
    // stub — depois vira texture real Xenos
    return data;
}

#include "xenos_gpu_bridge_x360.h"
#include "memory_manager_x360.h"

extern MemoryManagerX360* g_memory; // já existe no core normalmente

void XenosGPUBridgeX360::DrawTriangles(
    uint32_t vtxAddr,
    uint32_t count,
    uint32_t texAddr,
    uint32_t w,
    uint32_t h)
{
    void* vtx = g_memory->GetPointer(vtxAddr);
    void* tex = g_memory->GetPointer(texAddr);

    // stub beta — ainda sem shader real
    SubmitDrawStub(vtx, count, tex, w, h);
}