#pragma once
#include "gpu_texture_x360.h"

class MemoryManagerX360;
class XenosGPUBridgeX360;

class TextureUploaderX360 {
public:

    TextureUploaderX360(
        MemoryManagerX360& m,
        XenosGPUBridgeX360& g);

    GPUTextureX360 Upload(
        uint32_t guestAddr,
        uint32_t w,
        uint32_t h,
        uint32_t fmt);

private:

    MemoryManagerX360& mem;
    XenosGPUBridgeX360& gpu;
};