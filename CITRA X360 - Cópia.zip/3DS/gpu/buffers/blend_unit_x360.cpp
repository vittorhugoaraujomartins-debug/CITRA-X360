#include "blend_unit_x360.h"

static inline uint8_t ch(uint32_t c, int s)
{
    return (c >> s) & 0xFF;
}

uint32_t BlendUnitX360::Blend(uint32_t s, uint32_t d)
{
    if (mode == BlendModeGX::None)
        return s;

    uint8_t sr = ch(s,0), sg = ch(s,8), sb = ch(s,16), sa = ch(s,24);
    uint8_t dr = ch(d,0), dg = ch(d,8), db = ch(d,16), da = ch(d,24);

    uint8_t r,g,b,a;

    switch(mode)
    {
    case BlendModeGX::Alpha:
    {
        float af = sa / 255.0f;
        r = sr*af + dr*(1-af);
        g = sg*af + dg*(1-af);
        b = sb*af + db*(1-af);
        a = 255;
        break;
    }

    case BlendModeGX::Add:
        r = std::min(255, sr+dr);
        g = std::min(255, sg+dg);
        b = std::min(255, sb+db);
        a = 255;
        break;

    case BlendModeGX::Multiply:
        r = sr*dr/255;
        g = sg*dg/255;
        b = sb*db/255;
        a = 255;
        break;

    default:
        return s;
    }

    return (a<<24)|(b<<16)|(g<<8)|r;
}