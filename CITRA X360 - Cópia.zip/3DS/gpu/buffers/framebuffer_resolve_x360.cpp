#include "xenos_gpu_bridge_x360.h"
#include "framebuffer_x360.h"

void ResolveToXenos(
    const FramebufferX360& fb,
    XenosGPUBridgeX360& gpu)
{
    gpu.UploadColorBuffer(
        fb.Data());
}