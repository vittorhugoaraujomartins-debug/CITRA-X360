#pragma once
#include <cstdint>
#include <vector>

class DepthBufferX360 {
public:
    void Init(int w, int h)
    {
        width = w;
        height = h;
        data.resize(w * h);
        Clear();
    }

    void Clear(float v = 1.0f)
    {
        std::fill(data.begin(), data.end(), v);
    }

    bool TestAndWrite(int x, int y, float z)
    {
        int idx = y * width + x;

        if (z < data[idx]) {
            data[idx] = z;
            return true;
        }
        return false;
    }

private:
    int width = 0;
    int height = 0;
    std::vector<float> data;
};