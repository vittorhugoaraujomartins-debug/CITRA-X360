#pragma once
#include <cstdint>
#include <vector>

class FramebufferX360 {
public:
    void Init(int w, int h)
    {
        width = w;
        height = h;
        color.resize(w*h);
    }

    void Clear(uint32_t c)
    {
        std::fill(color.begin(), color.end(), c);
    }

    uint32_t& Pixel(int x,int y)
    {
        return color[y*width+x];
    }

    const uint32_t* Data() const { return color.data(); }

private:
    int width=0,height=0;
    std::vector<uint32_t> color;
};