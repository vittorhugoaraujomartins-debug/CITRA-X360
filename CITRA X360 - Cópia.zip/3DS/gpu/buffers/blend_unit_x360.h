#pragma once
#include <cstdint>

enum class BlendModeGX {
    None,
    Alpha,
    Add,
    Multiply
};

class BlendUnitX360 {
public:
    void SetMode(BlendModeGX m) { mode = m; }

    uint32_t Blend(uint32_t src, uint32_t dst);

private:
    BlendModeGX mode = BlendModeGX::None;
};