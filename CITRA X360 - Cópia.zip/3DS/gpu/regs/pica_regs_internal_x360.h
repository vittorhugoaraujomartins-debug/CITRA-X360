#pragma once

#include <array>
#include "common/types.h"

namespace Pica::X360 {

/**
 * Registradores internos da PICA200
 * Não mapeados diretamente na memória do 3DS
 * Usados apenas durante execução do pipeline
 */
struct InternalRegs {
    // Program counter do shader
    u32 shader_pc{0};

    // Flags internas
    bool shader_running{false};
    bool geometry_enabled{false};

    // Output mask atual
    u32 output_mask{0};

    // Índices auxiliares
    u32 current_vtx{0};
    u32 current_prim{0};

    // Estado de condição
    bool condition_flags[2]{false, false};

    void Reset() {
        shader_pc = 0;
        shader_running = false;
        geometry_enabled = false;
        output_mask = 0;
        current_vtx = 0;
        current_prim = 0;
        condition_flags[0] = condition_flags[1] = false;
    }
};

} // namespace Pica::X360