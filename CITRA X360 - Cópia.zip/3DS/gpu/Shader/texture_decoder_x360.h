#pragma once

#include <cstdint>
#include <vector>

namespace PicaX360 {

enum class TextureFormatX360 {
    RGBA8,
    RGB565,
    IA8,
    IA4,
    ETC1
};

class TextureDecoderX360 {
public:
    static std::vector<uint32_t> Decode(
        const uint8_t* data,
        int width,
        int height,
        TextureFormatX360 fmt
    );

private:
    static void DecodeRGBA8(const uint8_t* src, uint32_t* dst, int pixels);
    static void DecodeRGB565(const uint8_t* src, uint32_t* dst, int pixels);
};

}