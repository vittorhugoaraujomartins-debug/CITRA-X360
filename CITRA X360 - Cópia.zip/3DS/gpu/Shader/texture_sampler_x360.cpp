#include "texture_sampler_x360.h"

int TextureSamplerX360::Wrap(int x, int max)
{
    if (x < 0) return 0;
    if (x >= max) return max - 1;
    return x;
}

uint32_t TextureSamplerX360::SampleNearest(
    const TextureX360& tex,
    float u,
    float v)
{
    int x = Wrap((int)(u * tex.width), tex.width);
    int y = Wrap((int)(v * tex.height), tex.height);

    const uint8_t* p =
        tex.data + (y * tex.width + x) * 4;

    return
        (p[3] << 24) |
        (p[2] << 16) |
        (p[1] << 8) |
        (p[0]);
}