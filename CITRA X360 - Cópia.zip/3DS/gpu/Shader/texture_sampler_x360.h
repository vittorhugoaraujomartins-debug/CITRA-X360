#pragma once
#include <cstdint>

struct TextureX360 {
    const uint8_t* data;
    int width;
    int height;
};

class TextureSamplerX360 {
public:
    static uint32_t SampleNearest(
        const TextureX360& tex,
        float u,
        float v);

private:
    static int Wrap(int x, int max);
};