#pragma once

#include <array>
#include <cstdint>
#include "pica_types.h"

namespace PicaX360 {

struct ShaderRegs {
    std::array<float, 4> r[16];   // registradores temporários
    std::array<float, 4> v[16];   // inputs
    std::array<float, 4> c[96];   // uniforms
    std::array<float, 4> o[16];   // outputs
};

class ShaderInterpreterX360 {
public:
    void Reset();
    void Run(const uint32_t* program, size_t instruction_count);

    const ShaderRegs& GetRegs() const { return regs; }

private:
    void Exec(uint32_t inst);

    ShaderRegs regs{};
};

}