#include "fragment_pipeline_x360.h"

void FragmentPipelineX360::BindTexture(
    const TextureX360* tex)
{
    texture = tex;
}

uint32_t FragmentPipelineX360::Modulate(
    uint32_t a,
    uint32_t b)
{
    uint8_t ar = a & 0xFF;
    uint8_t ag = (a >> 8) & 0xFF;
    uint8_t ab = (a >> 16) & 0xFF;
    uint8_t aa = (a >> 24) & 0xFF;

    uint8_t br = b & 0xFF;
    uint8_t bg = (b >> 8) & 0xFF;
    uint8_t bb = (b >> 16) & 0xFF;
    uint8_t ba = (b >> 24) & 0xFF;

    uint8_t r = (ar * br) / 255;
    uint8_t g = (ag * bg) / 255;
    uint8_t bl = (ab * bb) / 255;
    uint8_t aout = (aa * ba) / 255;

    return
        (aout << 24) |
        (bl << 16) |
        (g << 8) |
        r;
}

uint32_t FragmentPipelineX360::Shade(
    const FragmentInputX360& in)
{
    uint32_t texColor = 0xFFFFFFFF;

    if (texture)
        texColor = TextureSamplerX360::SampleNearest(
            *texture,
            in.u,
            in.v);

    uint32_t out = Modulate(
        texColor,
        in.vertexColor);

    // alpha test mínimo
    if ((out >> 24) < 16)
        return 0;

    return out;
}


uint32_t texColor = sampler.SampleNearest(...);

uint32_t comb =
    gxCombiner.Combine(
        texColor,
        in.vertexColor);

uint32_t final =
    blendUnit.Blend(
        comb,
        framebuffer.Pixel(x,y));

if (depthBuffer.TestAndWrite(x,y,z))
    framebuffer.Pixel(x,y)=final;