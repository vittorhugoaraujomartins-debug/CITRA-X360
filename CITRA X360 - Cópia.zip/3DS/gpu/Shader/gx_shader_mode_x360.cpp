#include "gx_shader_mode_x360.h"

static inline uint8_t c(uint32_t v,int s)
{
    return (v>>s)&0xFF;
}

uint32_t GXShaderCombinerX360::Combine(
    uint32_t t,
    uint32_t v,
    uint32_t k)
{
    uint8_t tr=c(t,0), tg=c(t,8), tb=c(t,16);
    uint8_t vr=c(v,0), vg=c(v,8), vb=c(v,16);
    uint8_t kr=c(k,0), kg=c(k,8), kb=c(k,16);

    uint8_t r,g,b;

    switch(mode)
    {
    case GXShaderMode::Replace:
        r=tr; g=tg; b=tb;
        break;

    case GXShaderMode::Modulate:
        r=tr*vr/255;
        g=tg*vg/255;
        b=tb*vb/255;
        break;

    case GXShaderMode::Add:
        r=std::min(255,tr+vr);
        g=std::min(255,tg+vg);
        b=std::min(255,tb+vb);
        break;

    case GXShaderMode::Interpolate:
        r=(tr+vr+kr)/3;
        g=(tg+vg+kg)/3;
        b=(tb+vb+kb)/3;
        break;
    }

    return (255<<24)|(b<<16)|(g<<8)|r;
}