#pragma once
#include <cstdint>

enum class GXShaderMode {
    Replace,
    Modulate,
    Add,
    Interpolate
};

class GXShaderCombinerX360 {
public:
    void SetMode(GXShaderMode m)
    {
        mode = m;
    }

    uint32_t Combine(
        uint32_t tex,
        uint32_t vtx,
        uint32_t constant = 0xFFFFFFFF);

private:
    GXShaderMode mode =
        GXShaderMode::Modulate;
};