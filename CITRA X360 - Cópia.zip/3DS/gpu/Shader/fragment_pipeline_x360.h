#pragma once
#include <cstdint>
#include "texture_sampler_x360.h"

struct FragmentInputX360 {
    float u;
    float v;
    uint32_t vertexColor;
};

class FragmentPipelineX360 {
public:
    void BindTexture(const TextureX360* tex);

    uint32_t Shade(
        const FragmentInputX360& in);

private:
    const TextureX360* texture = nullptr;

    uint32_t Modulate(
        uint32_t a,
        uint32_t b);
};