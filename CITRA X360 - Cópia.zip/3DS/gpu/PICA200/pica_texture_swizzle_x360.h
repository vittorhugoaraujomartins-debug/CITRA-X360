#pragma once
#include <cstdint>

class PicaTextureSwizzleX360 {
public:
    static void DecodeRGBA8(
        const uint8_t* src,
        uint8_t* dst,
        int width,
        int height);

private:
    static int Morton2D(int x, int y);
};