#include "pica_texture_swizzle_x360.h"

int PicaTextureSwizzleX360::Morton2D(int x, int y)
{
    int answer = 0;
    for (int i = 0; i < 16; i++) {
        answer |= ((x >> i) & 1) << (2 * i);
        answer |= ((y >> i) & 1) << (2 * i + 1);
    }
    return answer;
}

void PicaTextureSwizzleX360::DecodeRGBA8(
    const uint8_t* src,
    uint8_t* dst,
    int width,
    int height)
{
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {

            int morton = Morton2D(x, y);
            const uint8_t* s = src + morton * 4;
            uint8_t* d = dst + (y * width + x) * 4;

            d[0] = s[0];
            d[1] = s[1];
            d[2] = s[2];
            d[3] = s[3];
        }
    }
}