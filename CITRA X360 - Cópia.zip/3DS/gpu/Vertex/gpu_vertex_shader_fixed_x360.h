#pragma once
#include "gpu_vertex_pipeline_x360.h"

class GPUVertexShaderFixedX360 {
public:
    void Execute(
        const PicaVertexInput& in,
        PicaVertexOutput& out);
};