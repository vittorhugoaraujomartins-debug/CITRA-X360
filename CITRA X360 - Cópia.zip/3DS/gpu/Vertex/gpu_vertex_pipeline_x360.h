#pragma once
#include <vector>
#include <cstdint>

struct PicaVertexInput {
    float attr[16][4]; // até 16 atributos
};

struct PicaVertexOutput {
    float position[4];
    float color[4];
    float texcoord[2];
};

class GPUVertexPipelineX360 {
public:
    void ProcessVertices(
        const std::vector<PicaVertexInput>& in,
        std::vector<PicaVertexOutput>& out);

private:
    void RunFixedVertexShader(
        const PicaVertexInput& vin,
        PicaVertexOutput& vout);

    void ApplyViewport(PicaVertexOutput& v);
};