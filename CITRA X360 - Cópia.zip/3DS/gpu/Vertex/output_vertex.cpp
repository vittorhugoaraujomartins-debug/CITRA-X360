#include <cmath>
#include <cstring>

#include "video_core/pica/output_vertex.h"
#include "video_core/pica/regs_rasterizer.h"

namespace Pica {

OutputVertex::OutputVertex(const RasterizerRegs& regs,
                           const AttributeBuffer& output) {
    // Overflow buffer = registradores VS do PICA
    std::array<f24, 32> slots;
    for (auto& v : slots)
        v = f24::One();

    const u32 num_attributes = regs.vs_output_total & 7;

    for (u32 attrib = 0; attrib < num_attributes; ++attrib) {
        const auto map = regs.vs_output_attributes[attrib];
        slots[map.map_x] = output[attrib][0];
        slots[map.map_y] = output[attrib][1];
        slots[map.map_z] = output[attrib][2];
        slots[map.map_w] = output[attrib][3];
    }

    // Copia direta (layout já garantido)
    std::memcpy(this, slots.data(), sizeof(OutputVertex));

    // Saturação de cor ANTES da interpolação (comportamento real do 3DS)
    for (int i = 0; i < 4; i++) {
        const float c = std::fabs(color[i].ToFloat32());
        color[i] = f24::FromFloat32(c > 1.0f ? 1.0f : c);
    }
}

} // namespace Pica
