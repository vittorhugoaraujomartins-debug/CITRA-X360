#pragma once
#include <cstdint>
#include "gpu_vertex_pipeline_x360.h"

class GPUVertexFormatDecoderX360 {
public:
    void DecodeVertex(
        const uint8_t* raw,
        PicaVertexInput& out,
        uint32_t stride);
};