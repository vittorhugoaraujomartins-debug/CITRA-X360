#include "gpu_vertex_format_decoder_x360.h"
#include <cstring>

void GPUVertexFormatDecoderX360::DecodeVertex(
    const uint8_t* raw,
    PicaVertexInput& out,
    uint32_t stride)
{
    const float* f = reinterpret_cast<const float*>(raw);

    // posição
    memcpy(out.attr[0], f, sizeof(float) * 3);

    // cor
    memcpy(out.attr[1], f + 3, sizeof(float) * 3);

    // UV
    memcpy(out.attr[2], f + 6, sizeof(float) * 2);
}