#pragma once

#include <array>

#include "core/memory.h"
#include "video_core/pica/output_vertex.h"
#include "video_core/pica/regs_pipeline.h"

namespace Memory {
class MemorySystem;
}

namespace Pica {

class VertexLoader {
public:
    VertexLoader(Memory::MemorySystem& memory, const PipelineRegs& regs);
    ~VertexLoader() = default;

    void LoadVertex(PAddr base_address, u32 index, u32 vertex,
                    AttributeBuffer& input,
                    AttributeBuffer& default_input) const;

private:
    template <typename T>
    T ReadBE(PAddr addr) const;

    template <typename T>
    void LoadAttribute(PAddr addr, u32 attrib, AttributeBuffer& out) const;

    Memory::MemorySystem& memory;

    std::array<u32, 16> sources{};
    std::array<u32, 16> strides{};
    std::array<PipelineRegs::VertexAttributeFormat, 16> formats{};
    std::array<u32, 16> elements{};
    std::array<bool, 16> is_default{};

    u32 num_attributes = 0;
};

} // namespace Pica
