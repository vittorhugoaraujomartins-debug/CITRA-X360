#include "gpu_vertex_shader_fixed_x360.h"

void GPUVertexShaderFixedX360::Execute(
    const PicaVertexInput& in,
    PicaVertexOutput& out)
{
    // atributo 0 = posição
    out.position[0] = in.attr[0][0];
    out.position[1] = in.attr[0][1];
    out.position[2] = in.attr[0][2];
    out.position[3] = 1.0f;

    // atributo 1 = cor
    out.color[0] = in.attr[1][0];
    out.color[1] = in.attr[1][1];
    out.color[2] = in.attr[1][2];
    out.color[3] = 1.0f;

    // atributo 2 = UV
    out.texcoord[0] = in.attr[2][0];
    out.texcoord[1] = in.attr[2][1];
}