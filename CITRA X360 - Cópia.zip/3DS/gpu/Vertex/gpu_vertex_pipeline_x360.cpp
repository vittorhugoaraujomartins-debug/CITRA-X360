#include "gpu_vertex_pipeline_x360.h"
#include "gpu_vertex_shader_fixed_x360.h"

static GPUVertexShaderFixedX360 shader;

void GPUVertexPipelineX360::ProcessVertices(
    const std::vector<PicaVertexInput>& in,
    std::vector<PicaVertexOutput>& out)
{
    out.resize(in.size());

    for (size_t i = 0; i < in.size(); i++) {
        RunFixedVertexShader(in[i], out[i]);
        ApplyViewport(out[i]);
    }
}

void GPUVertexPipelineX360::RunFixedVertexShader(
    const PicaVertexInput& vin,
    PicaVertexOutput& vout)
{
    shader.Execute(vin, vout);
}

void GPUVertexPipelineX360::ApplyViewport(
    PicaVertexOutput& v)
{
    // NDC → viewport Xbox 360
    v.position[0] = (v.position[0] * 0.5f + 0.5f);
    v.position[1] = (-v.position[1] * 0.5f + 0.5f);
}