#include "shader_setup_x360.h"
#include "common/bit_set.h"
#include "common/hash.h"
#include "video_core/pica/regs_shader.h"

namespace Pica {

ShaderSetupX360::ShaderSetupX360() = default;

void ShaderSetupX360::WriteUniformBool(u32 value) {
    auto bits = BitSet32(value);
    for (u32 i = 0; i < uniforms.b.size(); i++) {
        uniforms.b[i] = bits[i];
    }
}

void ShaderSetupX360::WriteUniformInt(u32 index, const Common::Vec4<u8>& values) {
    if (index < uniforms.i.size()) {
        uniforms.i[index] = values;
    }
}

std::optional<u32> ShaderSetupX360::WriteUniformFloat(ShaderRegs& regs, u32 value) {
    bool is_f32 = regs.uniform_setup.IsFloat32();

    if (!uniform_queue.Push(value, is_f32))
        return std::nullopt;

    auto uniform = uniform_queue.Get(is_f32);
    u32 index = regs.uniform_setup.index.Value();

    if (index >= uniforms.f.size())
        return std::nullopt;

    uniforms.f[index] = uniform;
    regs.uniform_setup.index.Assign(index + 1);
    return index;
}

u64 ShaderSetupX360::ProgramHash() {
    if (program_dirty) {
        program_hash = Common::ComputeHash64(program_code.data(),
                                             sizeof(program_code));
        program_dirty = false;
    }
    return program_hash;
}

u64 ShaderSetupX360::SwizzleHash() {
    if (swizzle_dirty) {
        swizzle_hash = Common::ComputeHash64(swizzle_data.data(),
                                             sizeof(swizzle_data));
        swizzle_dirty = false;
    }
    return swizzle_hash;
}

} // namespace Pica