#pragma once
#include <cstdint>

class MemoryX360;
class GPUFifoX360;

class GPUCommandExecutorX360 {
public:

    GPUCommandExecutorX360(
        MemoryX360* mem,
        GPUFifoX360* fifo);

    void ExecuteCommandList(
        uint32_t addr,
        uint32_t size);

private:

    MemoryX360* memory;
    GPUFifoX360* fifo;
};