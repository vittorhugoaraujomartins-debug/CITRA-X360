#include "gpu_command_executor_x360.h"
#include "memory_x360.h"
#include "gpu_fifo_x360.h"

GPUCommandExecutorX360::GPUCommandExecutorX360(
    MemoryX360* mem,
    GPUFifoX360* f)
    : memory(mem), fifo(f)
{
}

void GPUCommandExecutorX360::ExecuteCommandList(
    uint32_t addr,
    uint32_t size)
{
    if (!memory || !fifo)
        return;

    // GX commands = pares cmd+arg (8 bytes)
    for (uint32_t off = 0; off + 7 < size; off += 8)
    {
        uint32_t cmd = memory->Read32(addr + off);
        uint32_t arg = memory->Read32(addr + off + 4);

        fifo->Push(cmd, arg);
    }
}