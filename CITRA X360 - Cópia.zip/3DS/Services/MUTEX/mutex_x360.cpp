#include "mutex_x360.h"
#include "kernel_thread_x360.h"

bool MutexX360::ShouldWait(KernelThreadX360* t)
{
    return owner != nullptr && owner != t;
}

bool MutexX360::TryAcquire(KernelThreadX360* t)
{
    if (owner == nullptr) {
        owner = t;
        lockCount = 1;
        return true;
    }

    if (owner == t) {
        lockCount++;
        return true;
    }

    return false;
}

void MutexX360::Acquire(KernelThreadX360* t)
{
    if (owner == t) {
        lockCount++;
        return;
    }

    if (owner == nullptr) {
        owner = t;
        lockCount = 1;
        return;
    }

    AddWaitingThread(t);
}

void MutexX360::Release(KernelThreadX360* t)
{
    if (owner != t)
        return;

    lockCount--;

    if (lockCount > 0)
        return;

    owner = nullptr;

    KernelThreadX360* next = PopNextWaitingThread();
    if (next) {
        owner = next;
        lockCount = 1;
        WakeOne(next);
    }
}
