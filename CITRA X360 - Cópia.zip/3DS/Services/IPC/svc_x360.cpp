#include "svc_x360.h"
#include "arm_state_x360.h"
#include "ipc_x360.h"
#include "kernel_thread_x360.h"

SVCX360::SVCX360(IPCX360& i)
    : ipc(i) {}

void SVCX360::Call(
    uint32_t svcId,
    ARMStateX360& cpu,
    KernelThreadX360& thread)
{
    switch (svcId)
    {
        case 0x32: // SendSyncRequest
            SVC_SendSyncRequest(cpu);
            break;

        case 0x24: // YieldThread
            SVC_Yield(thread);
            break;

        default:
            // stub SVC
            cpu.R[0] = 0;
            break;
    }
}

void SVCX360::SVC_SendSyncRequest(
    ARMStateX360& cpu)
{
    uint32_t msgPtr = cpu.R[0];
    uint32_t handle = cpu.R[1];

    ipc.SendSyncRequest(msgPtr, handle);

    cpu.R[0] = 0;
}

void SVCX360::SVC_Yield(
    KernelThreadX360& thread)
{
    thread.requestYield = true;
}