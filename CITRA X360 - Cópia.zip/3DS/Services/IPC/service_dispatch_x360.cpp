#include "service_dispatch_x360.h"
#include "apt_service_x360.h"
#include "dsp_service_x360.h"
#include "cecd_service_x360.h"

static APTServiceX360 apt;
static DSPServiceX360 dsp;
static CECDServiceX360 cecd;

void DispatchServiceX360(
    uint32_t serviceId,
    uint32_t cmdId,
    IPCReaderX360& ipc)
{
    switch (serviceId)
    {
    case 1: apt.HandleSync(cmdId, ipc); break;
    case 2: dsp.HandleSync(cmdId, ipc); break;
    case 3: cecd.HandleSync(cmdId, ipc); break;
    default:
        ipc.WriteResult(0xFFFFFFFF);
        break;
    }
}