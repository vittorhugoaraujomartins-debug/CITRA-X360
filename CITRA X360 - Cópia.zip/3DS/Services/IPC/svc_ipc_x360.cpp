#include "ipc_x360.h"
#include "arm_state_x360.h"

void SVC_SendSyncRequest_X360(
    ARMStateX360& cpu,
    IPCX360& ipc)
{
    uint32_t messagePtr = cpu.R[0];
    uint32_t handle     = cpu.R[1];

    ipc.SendSyncRequest(messagePtr, handle);

    cpu.R[0] = 0; // success
}