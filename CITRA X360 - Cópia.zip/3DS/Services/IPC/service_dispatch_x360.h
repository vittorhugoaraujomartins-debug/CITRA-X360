#pragma once
#include <cstdint>

class IPCReaderX360;

void DispatchServiceX360(
    uint32_t serviceId,
    uint32_t cmdId,
    IPCReaderX360& ipc);