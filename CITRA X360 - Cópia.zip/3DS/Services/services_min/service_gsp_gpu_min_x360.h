#pragma once
#include <cstdint>

class IPCReaderX360;

struct GSPFrameBufferX360 {
    uint32_t addr = 0;
    uint32_t width = 0;
    uint32_t height = 0;
    uint32_t format = 0;
};

class GSPGPUServiceX360 {
public:
    void HandleSync(uint32_t cmdId, IPCReaderX360& ipc);

private:

    void Initialize(IPCReaderX360& ipc);
    void SubmitCommandList(IPCReaderX360& ipc);
    void SetBufferSwap(IPCReaderX360& ipc);
    void SubmitGxCommand(IPCReaderX360& ipc);

    void ExecuteCommandList(uint32_t addr, uint32_t size);

    bool initialized = false;

    GSPFrameBufferX360 fb[2];
    int current_fb = 0;
};
