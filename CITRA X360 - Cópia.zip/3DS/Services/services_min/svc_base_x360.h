
#pragma once
#include <cstdint>

class ARMStateX360;

namespace SVCX360 {

void SleepThread(ARMStateX360& cpu);
void GetThreadId(ARMStateX360& cpu);
void ExitProcess(ARMStateX360& cpu);

}
