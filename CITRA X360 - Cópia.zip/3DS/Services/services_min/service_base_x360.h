#pragma once
#include <cstdint>
class IPCReaderX360;

class ServiceBaseX360 {
public:
    virtual void HandleSync(uint32_t cmd, IPCReaderX360& ipc) = 0;

protected:
    void Ok(IPCReaderX360& ipc) {
        ipc.WriteResult(0);
    }

    void Stub(IPCReaderX360& ipc) {
        ipc.WriteResult(0); // stub ok = melhor que erro
    }
};