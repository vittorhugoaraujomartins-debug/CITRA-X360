#include "service_gsp_gpu_min_x360.h"
#include "ipc_reader_x360.h"

void GSPGPUServiceX360::HandleSync(uint32_t cmdId, IPCReaderX360& ipc)
{
    switch (cmdId)
    {
    case 0x0001:
        Initialize(ipc);
        break;
    case 0x0005:
        SubmitCommandList(ipc);
        break;
    case 0x000B:
        SetBufferSwap(ipc);
        break;
    default:
        ipc.WriteResult(0);
        break;
    }
}

void GSPGPUServiceX360::Initialize(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}

void GSPGPUServiceX360::SubmitCommandList(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}

void GSPGPUServiceX360::SetBufferSwap(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}


#include "xenos_gpu_bridge_x360.h"

static XenosGPUBridgeX360 gpu;

void GSPGPUServiceX360::SubmitGxCommand(
    IPCReaderX360& ipc)
{
    gpu.DrawFakeTriangle();
    ipc.WriteResult(0);
}


#include "service_gsp_gpu_x360.h"
#include "ipc_reader_x360.h"
#include "memory_system_x360.h"
#include "xenos_gpu_bridge_x360.h"

extern MemorySystemX360* g_memory;

static XenosGPUBridgeX360 gpu;

void GSPGPUServiceX360::HandleSync(
    uint32_t cmdId,
    IPCReaderX360& ipc)
{
    switch (cmdId)
    {
        case 0x0001: Initialize(ipc); break;
        case 0x0005: SubmitCommandList(ipc); break;
        case 0x000B: SetBufferSwap(ipc); break;
        case 0x0010: SubmitGxCommand(ipc); break;

        default:
            ipc.WriteResult(0);
            break;
    }
}

#include "gpu_fifo_x360.h"

static GPUFifoX360 g_fifo;

#include "gpu_command_executor_x360.h"
#include "gpu_fifo_x360.h"

static GPUFifoX360 g_fifo;
static GPUCommandExecutorX360 g_gpuExec(g_memory, &g_fifo);


void GSPGPUServiceX360::SubmitCommandList(
    IPCReaderX360& ipc)
{
    uint32_t addr = ipc.Param(0);
    uint32_t size = ipc.Param(1);

    gpuExecutor.Execute(addr,size);

    ipc.WriteResult(0);
}