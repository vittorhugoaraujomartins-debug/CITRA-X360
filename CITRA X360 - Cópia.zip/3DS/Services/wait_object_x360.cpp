#include "wait_object_x360.h"
#include "kernel_thread_x360.h"

void WaitObjectX360::AddWaiting(
    KernelThreadX360* t)
{
    waiting.push_back(t);
    t->blocked = true;
}

void WaitObjectX360::WakeAll()
{
    for (auto* t : waiting)
        t->blocked = false;

    waiting.clear();
}