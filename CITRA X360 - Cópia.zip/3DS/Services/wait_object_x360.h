#pragma once
#include <queue>

class KernelThreadX360;

class WaitObjectX360 {
public:
    virtual bool ShouldWait(KernelThreadX360*) { return false; }
    virtual void Acquire(KernelThreadX360*) {}

    void AddWaiter(KernelThreadX360* t) {
        waiters.push(t);
    }

protected:
    void WakeOne() {
        if (waiters.empty()) return;
        auto* t = waiters.front();
        waiters.pop();
        t->state = ThreadStateX360::Ready;
    }

    void WakeAll() {
        while (!waiters.empty()) {
            waiters.front()->state = ThreadStateX360::Ready;
            waiters.pop();
        }
    }

private:
    std::queue<KernelThreadX360*> waiters;
};