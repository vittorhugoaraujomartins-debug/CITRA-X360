#pragma once
#include "service_base_x360.h"

class DSPServiceX360 : public ServiceBaseX360 {
public:
    void HandleSync(uint32_t cmd, IPCReaderX360& ipc) override;
};