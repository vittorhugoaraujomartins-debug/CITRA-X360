#include "dsp_service_x360.h"
#include "ipc_reader_x360.h"

void DSPServiceX360::HandleSync(uint32_t cmd, IPCReaderX360& ipc) {
    ipc.WriteResult(0); // stub completo por enquanto
}