#include "cecd_service_x360.h"
#include "ipc_reader_x360.h"

void CECDServiceX360::HandleSync(uint32_t cmdId, IPCReaderX360& ipc)
{
    switch (cmdId)
    {
    case 0x0001:
        Open(ipc);
        break;

    default:
        ipc.WriteResult(0xFFFFFFFF);
        break;
    }
}

void CECDServiceX360::Open(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}

case 0x0002: // Close
case 0x0003: // Read
case 0x0004: // Write
    ipc.WriteResult(0);
    break;