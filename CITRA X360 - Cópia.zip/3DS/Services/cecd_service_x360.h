#pragma once
#include <cstdint>

class IPCReaderX360;

class CECDServiceX360 {
public:
    void HandleSync(uint32_t cmdId, IPCReaderX360& ipc);

private:
    void Open(IPCReaderX360& ipc);
};