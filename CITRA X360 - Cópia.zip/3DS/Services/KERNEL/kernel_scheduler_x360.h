#pragma once
#include <vector>
#include <cstdint>

class KernelThreadX360;

enum class ThreadStateX360 {
    Ready,
    Running,
    Waiting,
    Sleeping,
    Dead
};

class KernelSchedulerX360 {
public:
    void AddThread(KernelThreadX360* t);
    void RemoveDead();

    void Tick();              // chamado a cada timeslice
    KernelThreadX360* Current();

    void Yield();
    void SleepCurrent(uint32_t ticks);

    void WakeThread(KernelThreadX360* t);

private:
    std::vector<KernelThreadX360*> threads;
    int currentIndex = -1;
};