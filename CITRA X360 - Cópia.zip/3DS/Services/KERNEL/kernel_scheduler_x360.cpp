#include "kernel_scheduler_x360.h"
#include "kernel_thread_x360.h"

void KernelSchedulerX360::AddThread(KernelThreadX360* t) {
    threads.push_back(t);
}

KernelThreadX360* KernelSchedulerX360::Current() {
    if (currentIndex < 0 || currentIndex >= (int)threads.size())
        return nullptr;
    return threads[currentIndex];
}

void KernelSchedulerX360::Yield() {
    Tick();
}

void KernelSchedulerX360::Tick() {

    if (threads.empty())
        return;

    for (size_t i = 0; i < threads.size(); i++) {

        currentIndex = (currentIndex + 1) % threads.size();
        auto* t = threads[currentIndex];

        if (t->state == ThreadStateX360::Ready) {
            t->state = ThreadStateX360::Running;
            return;
        }
    }
}

void KernelSchedulerX360::SleepCurrent(uint32_t ticks) {
    auto* t = Current();
    if (!t) return;

    t->sleepTicks = ticks;
    t->state = ThreadStateX360::Sleeping;
}

void KernelSchedulerX360::WakeThread(KernelThreadX360* t) {
    if (t->state != ThreadStateX360::Dead)
        t->state = ThreadStateX360::Ready;
}

void KernelSchedulerX360::RemoveDead() {
    threads.erase(
        std::remove_if(
            threads.begin(),
            threads.end(),
            [](auto* t){ return t->state == ThreadStateX360::Dead; }),
        threads.end());
}