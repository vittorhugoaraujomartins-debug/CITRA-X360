#pragma once
#include <cstdint>
#include <vector>
#include <array>

using u32 = uint32_t;
using u64 = uint64_t;

enum class ThreadStatus {
    Running,
    Ready,
    Waiting,
    Dead
};

struct Thread {
    u32 pc = 0;
    u32 sp = 0;
    ThreadStatus status = ThreadStatus::Dead;
    int priority = 0;
};

enum class KernelObjectType {
    None,
    Event,
    Mutex,
    Semaphore
};

struct KernelObject {
    KernelObjectType type = KernelObjectType::None;
    u64 waitMask = 0;
    bool signaled = false;
};

class KernelLite {
public:
    static constexpr int MaxThreads = 16;

    void reset();
    void svcCall(u32 svc);

    Thread& currentThread();
    void createThread(u32 entry, u32 sp, int prio);

    void signalEvent(int handle);
    bool waitEvent(int handle);

private:
    std::array<Thread, MaxThreads> threads{};
    std::vector<KernelObject> objects;

    int currentThreadIndex = 0;

    void reschedule();
};