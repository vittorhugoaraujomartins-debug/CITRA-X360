#include "kernel_objects_x360.h"
#include "event_x360.h"
#include "mutex_x360.h"

int KernelObjectsX360::CreateEvent(bool sticky)
{
    int h = nextHandle++;
    events[h] = std::make_unique<EventX360>(
        sticky ? ResetTypeX360::Sticky
               : ResetTypeX360::OneShot);
    return h;
}

int KernelObjectsX360::CreateMutex()
{
    int h = nextHandle++;
    mutexes[h] = std::make_unique<MutexX360>();
    return h;
}

EventX360* KernelObjectsX360::GetEvent(int h)
{
    if (!events.contains(h)) return nullptr;
    return events[h].get();
}

MutexX360* KernelObjectsX360::GetMutex(int h)
{
    if (!mutexes.contains(h)) return nullptr;
    return mutexes[h].get();
}