#include "KernelLite.hpp"
#include <cstdio>

void KernelLite::reset() {
    for (auto& t : threads) {
        t = {};
    }
    objects.clear();
    currentThreadIndex = 0;
}

Thread& KernelLite::currentThread() {
    return threads[currentThreadIndex];
}

void KernelLite::createThread(u32 entry, u32 sp, int prio) {
    for (auto& t : threads) {
        if (t.status == ThreadStatus::Dead) {
            t.pc = entry;
            t.sp = sp;
            t.priority = prio;
            t.status = ThreadStatus::Ready;
            return;
        }
    }
}

void KernelLite::signalEvent(int handle) {
    if (handle >= objects.size()) return;
    objects[handle].signaled = true;
}

bool KernelLite::waitEvent(int handle) {
    if (handle >= objects.size()) return false;
    return objects[handle].signaled;
}

void KernelLite::svcCall(u32 svc) {
    switch (svc) {

        case 0x01: // Yield
            reschedule();
            break;

        case 0x02: // Sleep stub
            currentThread().status = ThreadStatus::Waiting;
            reschedule();
            break;

        case 0x03: // Debug print
            printf("[SVC] Debug call\n");
            break;

        default:
            printf("[SVC] Unknown %u\n", svc);
            break;
    }
}

void KernelLite::reschedule() {
    for (int i = 0; i < MaxThreads; i++) {
        int idx = (currentThreadIndex + 1 + i) % MaxThreads;
        if (threads[idx].status == ThreadStatus::Ready) {
            currentThreadIndex = idx;
            threads[idx].status = ThreadStatus::Running;
            return;
        }
    }
}