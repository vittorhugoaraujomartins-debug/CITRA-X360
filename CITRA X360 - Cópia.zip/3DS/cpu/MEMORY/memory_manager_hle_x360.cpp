#include "memory_manager_hle_x360.h"

void MemoryManagerHLEX360::Init(uint32_t base, uint32_t size)
{
    regions.push_back({base, size, 0, false});
}

int MemoryManagerHLEX360::ControlMemory(uint32_t addr, uint32_t size, uint32_t perm)
{
    for (auto& r : regions) {
        if (!r.used && r.size >= size) {
            r.base = addr;
            r.size = size;
            r.perm = perm;
            r.used = true;
            return 0;
        }
    }
    return -1;
}

int MemoryManagerHLEX360::QueryMemory(uint32_t addr, MemoryRegion& out)
{
    for (auto& r : regions) {
        if (addr >= r.base && addr < r.base + r.size) {
            out = r;
            return 0;
        }
    }
    return -1;
}