#include "kernel_scheduler_x360.h"
#include "kernel_thread_x360.h"

void KernelSchedulerX360::AddThread(
    KernelThreadX360* t)
{
    threads.push_back(t);
}

KernelThreadX360* KernelSchedulerX360::Next()
{
    if (threads.empty())
        return nullptr;

    index = (index + 1) % threads.size();
    return threads[index];
}