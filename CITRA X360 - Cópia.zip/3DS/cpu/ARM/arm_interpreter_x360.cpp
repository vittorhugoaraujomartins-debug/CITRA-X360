#include "core/arm/x360/arm_interpreter_x360.h"
#include "core/memory.h"

namespace Core {

ARMInterpreterX360::ARMInterpreterX360(u32 id,
    std::shared_ptr<Core::Timing::Timer> timer)
    : ARM_Interface(id, timer) {}

void ARMInterpreterX360::Run() {
    while (!state.halted) {
        Step();
    }
}

void ARMInterpreterX360::Step() {
    u32 pc = state.r[15];
    u32 opcode = Memory::Read32(pc);

    state.r[15] += 4;

    // 🔹 Placeholder de decode (por enquanto)
    // Exemplo: NOP
    if (opcode == 0xE1A00000) {
        return;
    }

    // TODO: Decode real (MOV, ADD, B, LDR, STR…)
}

void ARMInterpreterX360::ClearExclusiveState() {
    state.exclusive_valid = false;
}

void ARMInterpreterX360::SetPageTable(
    const std::shared_ptr<Memory::PageTable>& pt) {
    page_table = pt;
}

std::shared_ptr<Memory::PageTable>
ARMInterpreterX360::GetPageTable() const {
    return page_table;
}

void ARMInterpreterX360::SetPC(u32 addr) {
    state.r[15] = addr;
}

u32 ARMInterpreterX360::GetPC() const {
    return state.r[15];
}

u32 ARMInterpreterX360::GetReg(int index) const {
    return state.r[index];
}

void ARMInterpreterX360::SetReg(int index, u32 value) {
    state.r[index] = value;
}

u32 ARMInterpreterX360::GetVFPReg(int index) const {
    return state.vfp_regs[index];
}

void ARMInterpreterX360::SetVFPReg(int index, u32 value) {
    state.vfp_regs[index] = value;
}

u32 ARMInterpreterX360::GetVFPSystemReg(VFPSystemRegister reg) const {
    switch (reg) {
    case VFP_FPSCR: return state.fpscr;
    case VFP_FPEXC: return state.fpexc;
    default: return 0;
    }
}

void ARMInterpreterX360::SetVFPSystemReg(
    VFPSystemRegister reg, u32 value) {
    switch (reg) {
    case VFP_FPSCR: state.fpscr = value; break;
    case VFP_FPEXC: state.fpexc = value; break;
    default: break;
    }
}

u32 ARMInterpreterX360::GetCPSR() const {
    return state.cpsr;
}

void ARMInterpreterX360::SetCPSR(u32 value) {
    state.cpsr = value;
}

u32 ARMInterpreterX360::GetCP15Register(CP15Register reg) const {
    return state.cp15[reg];
}

void ARMInterpreterX360::SetCP15Register(
    CP15Register reg, u32 value) {
    state.cp15[reg] = value;
}

void ARMInterpreterX360::SaveContext(ThreadContext& ctx) {
    for (int i = 0; i < 16; i++)
        ctx.cpu_registers[i] = state.r[i];

    ctx.cpsr = state.cpsr;

    for (int i = 0; i < 64; i++)
        ctx.fpu_registers[i] = state.vfp_regs[i];

    ctx.fpscr = state.fpscr;
    ctx.fpexc = state.fpexc;
}

void ARMInterpreterX360::LoadContext(const ThreadContext& ctx) {
    for (int i = 0; i < 16; i++)
        state.r[i] = ctx.cpu_registers[i];

    state.cpsr = ctx.cpsr;

    for (int i = 0; i < 64; i++)
        state.vfp_regs[i] = ctx.fpu_registers[i];

    state.fpscr = ctx.fpscr;
    state.fpexc = ctx.fpexc;
}

} // namespace Core