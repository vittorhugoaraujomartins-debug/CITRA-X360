#pragma once

#include <cstdint>

namespace Core_X360 {

uint64_t TicksForInstruction(bool is_thumb, uint32_t instruction);

}