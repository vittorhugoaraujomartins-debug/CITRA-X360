#pragma once
#include <cstdint>
#include "kernel_scheduler_x360.h"

class KernelThreadX360 {
public:
    uint32_t id;
    ThreadStateX360 state = ThreadStateX360::Ready;

    uint32_t sleepTicks = 0;

    void TickSleep() {
        if (state == ThreadStateX360::Sleeping && sleepTicks > 0) {
            sleepTicks--;
            if (sleepTicks == 0)
                state = ThreadStateX360::Ready;
        }
    }
};