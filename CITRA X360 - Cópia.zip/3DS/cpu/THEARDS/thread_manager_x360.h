#pragma once
#include <vector>
#include <cstdint>

struct ARMState;

enum ThreadStatus {
    THREAD_READY,
    THREAD_RUNNING,
    THREAD_SLEEPING,
    THREAD_WAITING,
    THREAD_DEAD
};

struct ThreadContext {
    ARMState* cpu;
    uint32_t entry_point;
    uint32_t stack_top;
};

class X360Thread {
public:
    uint32_t id;
    int priority;
    ThreadStatus status;
    ThreadContext context;
    uint64_t wake_tick;

    X360Thread(uint32_t tid, ARMState* state, uint32_t entry, uint32_t stack, int prio);
};

class ThreadSchedulerX360 {
public:
    void CreateThread(uint32_t entry, uint32_t stack, int prio);
    void SleepThread(uint64_t ticks);
    void ExitThread();

    void Tick();
    X360Thread* GetCurrent();

private:
    std::vector<X360Thread*> threads;
    X360Thread* current = nullptr;
    uint32_t next_id = 1;

    X360Thread* PickNext();
};