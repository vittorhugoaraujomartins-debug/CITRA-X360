#include "vfp_state_x360.h"
#include "vfp_helpers_x360.h"
#include <cmath>

void VFP_FTOI(VFPStateX360& vfp, int dst, int src) {
    float f = vfp_u32_to_f32(vfp.s[src]);
    int i = static_cast<int>(f);
    vfp.s[dst] = static_cast<uint32_t>(i);
}

void VFP_ITOF(VFPStateX360& vfp, int dst, int src) {
    int i = static_cast<int>(vfp.s[src]);
    float f = static_cast<float>(i);
    vfp.s[dst] = vfp_f32_to_u32(f);
}