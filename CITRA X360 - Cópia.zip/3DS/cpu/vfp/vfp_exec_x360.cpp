#include "vfp_decode_x360.h"
#include "vfp_state_x360.h"

void VFP_FADD(VFPStateX360&, int,int,int);
void VFP_FSUB(VFPStateX360&, int,int,int);
void VFP_FMUL(VFPStateX360&, int,int,int);
void VFP_FDIV(VFPStateX360&, int,int,int);
void VFP_FSQRT(VFPStateX360&, int,int);

void ExecuteVFP_X360(VFPStateX360& vfp, const VFPDecodedX360& d) {

    switch (d.op) {

        case VFP_OpX360::VADD:
            VFP_FADD(vfp, d.Sd, d.Sn, d.Sm);
            break;

        case VFP_OpX360::VSUB:
            VFP_FSUB(vfp, d.Sd, d.Sn, d.Sm);
            break;

        case VFP_OpX360::VMUL:
            VFP_FMUL(vfp, d.Sd, d.Sn, d.Sm);
            break;

        case VFP_OpX360::VDIV:
            VFP_FDIV(vfp, d.Sd, d.Sn, d.Sm);
            break;

        case VFP_OpX360::VABS:
            vfp.s[d.Sd] = vfp.s[d.Sm] & 0x7FFFFFFF;
            break;

        case VFP_OpX360::VNEG:
            vfp.s[d.Sd] = vfp.s[d.Sm] ^ 0x80000000;
            break;

        case VFP_OpX360::VSQRT:
            VFP_FSQRT(vfp, d.Sd, d.Sm);
            break;

        default:
            break;
    }
}


void VFP_FMLA(VFPStateX360&, int,int,int);
void VFP_FMLS(VFPStateX360&, int,int,int);
void VFP_FTOI(VFPStateX360&, int,int);
void VFP_ITOF(VFPStateX360&, int,int);