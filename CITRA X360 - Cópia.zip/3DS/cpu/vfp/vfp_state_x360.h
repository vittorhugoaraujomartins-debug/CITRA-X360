#pragma once
#include <cstdint>

struct VFPStateX360 {

    uint32_t s[32];   // single regs
    uint64_t d[16];   // double regs (overlay)

    uint32_t FPSCR;
    uint32_t FPEXC;
    uint32_t FPSID;

    void Reset() {
        for (int i=0;i<32;i++) s[i]=0;
        for (int i=0;i<16;i++) d[i]=0;
        FPSCR = 0;
        FPEXC = 0;
        FPSID = 0x410120B4; // ARM11 profile
    }
};


float GetS(int i) const {
    union { uint32_t u; float f; } x;
    x.u = s[i];
    return x.f;
}

void SetS(int i, float f) {
    union { uint32_t u; float f; } x;
    x.f = f;
    s[i] = x.u;
}