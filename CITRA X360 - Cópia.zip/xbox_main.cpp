
#include <xtl.h>

extern void GPU_Init();
extern void GPU_Frame();
extern void ARM_RunHello();

extern "C" int main() {
    GPU_Init();
    ARM_RunHello();
    while(true) {
        GPU_Frame();
        Sleep(1);
    }
    return 0;
}

#include "../../core/engine/engine.h"
#include <xtl.h>
#include <chrono>

int main() {
    Engine_Init();

    const double targetMs = 16.6667; // 60 FPS
    using clock = std::chrono::high_resolution_clock;

    while (true) {
        auto start = clock::now();

        Engine_RunFrame();

        auto end = clock::now();
        double frameMs =
            std::chrono::duration<double, std::milli>(end - start).count();

        if (frameMs < targetMs) {
            DWORD sleepMs = (DWORD)(targetMs - frameMs);
            if (sleepMs > 0)
                XSleep(sleepMs);
        }
    }

    Engine_Shutdown();
    return 0;
}

// Auto ROM boot
#include "core/rom_autoload.cpp"
