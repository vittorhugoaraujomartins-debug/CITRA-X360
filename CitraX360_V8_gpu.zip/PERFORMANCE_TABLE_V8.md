# Performance Table - CitraX360 V8 (GPU Powered Edition)
Generated: 2025-11-14T15:24:42.075818 UTC

**Key new systems:** Shader Rewriter, Occlusion IA, Smart Resolution, GhostCore GPU assists.

| Game Complexity | Typical Target Resolution | Expected FPS (Xbox 360) | Notes |
|---|---:|---:|---|
| Very Light | 1080p/720p | 55 - 75 FPS | Near full speed due to shader & culling optimizations.
| Light | 720p/540p | 45 - 65 FPS | Smart preload + impostors + instancing give big wins.
| Medium | 720p/480p | 30 - 50 FPS | Shader Rewriter and Smart Resolution reduce GPU bottlenecks.
| Heavy | 540p/360p | 15 - 35 FPS | Depends on particle/dynamic lighting; still improved.
| Extreme | 360p/240p | 8 - 20 FPS | Large open worlds require further engine-level work.

## Expected GPU-focused gains vs V7
- Shader Rewriter: +20% to +35% in shading heavy scenes.
- Occlusion IA: +10% to +25% by not rendering occluded geometry.
- Smart Resolution: +10% to +20% by adaptive RT.
- GhostCore GPU assists: +5% to +12% by batching instance buffers and UV packing.

## Notes
Actual gains vary by title and scene; V8 targets GPU-bound cases primarily and should raise average FPS substantially where shading and overdraw are the bottleneck.
