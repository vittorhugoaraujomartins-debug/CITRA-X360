
V8 GPU Edition: added Shader Rewriter, Occlusion IA, Smart Resolution, Ghost GPU Assist, demo v8_demo_gpu.cpp, performance table.
