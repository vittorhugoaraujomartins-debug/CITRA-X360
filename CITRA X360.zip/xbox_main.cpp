
#include <xtl.h>

extern void GPU_Init();
extern void GPU_Frame();
extern void ARM_RunHello();

extern "C" int main() {
    GPU_Init();
    ARM_RunHello();
    while(true) {
        GPU_Frame();
        Sleep(1);
    }
    return 0;
}

// Auto ROM boot
#include "core/rom_autoload.cpp"
