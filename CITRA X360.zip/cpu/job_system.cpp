#include <vector>
struct Job{ void(*fn)(void*); void* arg; };
static std::vector<Job> jobs;
void PushJob(Job j){ jobs.push_back(j); }
void RunJobs(){
    for(auto& j:jobs) j.fn(j.arg);
    jobs.clear();
}
