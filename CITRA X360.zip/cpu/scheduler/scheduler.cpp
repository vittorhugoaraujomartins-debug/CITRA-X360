#include "scheduler.h"
void Scheduler_Init(){}
void Scheduler_Tick(){}


// Expanded implementation
#include <cstdint>
static uint32_t _dummy_state = 0;
void Tick() { _dummy_state++; }
