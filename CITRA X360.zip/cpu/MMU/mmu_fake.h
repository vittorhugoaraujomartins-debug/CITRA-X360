#pragma once
#include <xtl.h>
void MMU_Init();
