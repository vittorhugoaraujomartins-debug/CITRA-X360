#pragma once
#include <cstdint>

namespace MemoryMap {
// Unified RAM layout (Xbox 360 shared RAM model)
static const uint32_t CPU_BASE      = 0x00000000;
static const uint32_t CPU_SIZE_MB   = 64;

static const uint32_t GPU_BASE      = 0x20000000;
static const uint32_t GPU_SIZE_MB   = 448;

// 3DS virtual regions (mapped)
static const uint32_t ARM11_CODE    = 0x00100000;
static const uint32_t ARM11_HEAP    = 0x08000000;
static const uint32_t ARM11_STACK   = 0x0FFF0000;
}
