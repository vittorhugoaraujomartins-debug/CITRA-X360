#include "block_cache.h"
#include <cstdint>

void LinkBlocks(JitBlock* from, JitBlock* to){
    if(!from || !to) return;
    // Patch exit to jump directly to next block entry
    from->exit_pc[0] = to->arm_pc;
}
