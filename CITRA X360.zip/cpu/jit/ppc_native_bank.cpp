#include "ppc_native_bank.h"
#include <vector>
#include <mutex>
static std::vector<PPCNativeEntry> g_bank;
static std::mutex g_lock;
void PPCBank_Init(){ std::lock_guard<std::mutex> lk(g_lock); g_bank.clear(); }
void PPCBank_Insert(uint32_t arm_hash, void* ppc_entry){
    std::lock_guard<std::mutex> lk(g_lock);
    for(auto &e: g_bank){ if(e.arm_hash==arm_hash){ e.ppc_entry=ppc_entry; return; } }
    g_bank.push_back({arm_hash, ppc_entry});
}
void* PPCBank_Find(uint32_t arm_hash){
    std::lock_guard<std::mutex> lk(g_lock);
    for(auto &e: g_bank) if(e.arm_hash==arm_hash) return e.ppc_entry;
    return nullptr;
}
