#include "arm_ppc_table.h"
uint32_t ARMHash(const uint32_t* code, uint32_t words){
    uint32_t h=2166136261u;
    for(uint32_t i=0;i<words;i++) h = (h ^ code[i]) * 16777619u;
    return h;
}
