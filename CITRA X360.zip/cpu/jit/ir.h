#pragma once
#include <cstdint>
enum class IROp : uint8_t {
    NOP, MOV, ADD, SUB, CMP, LDR, STR, B, BL, BX
};
struct IRInstr {
    IROp op;
    uint8_t rd, rn, rm;
    uint32_t imm;
};
