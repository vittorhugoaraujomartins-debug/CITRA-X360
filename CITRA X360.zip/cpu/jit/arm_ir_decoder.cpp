#include "ir.h"
#include <vector>
#include <cstdint>

// Very fast ARM->IR decoder (subset, hot-path oriented)
void DecodeARMToIR(uint32_t instr, std::vector<IRInstr>& out) {
    IRInstr ir{};
    uint32_t op = (instr >> 21) & 0xF;
    if ((instr & 0x0C000000) == 0x00000000) {
        // Data processing
        switch (op) {
            case 0xD: ir.op = IROp::MOV; break;
            case 0x4: ir.op = IROp::ADD; break;
            case 0x2: ir.op = IROp::SUB; break;
            case 0xA: ir.op = IROp::CMP; break;
            default: ir.op = IROp::NOP; break;
        }
        ir.rd = (instr >> 12) & 0xF;
        ir.rn = (instr >> 16) & 0xF;
        ir.rm = instr & 0xF;
        out.push_back(ir);
        return;
    }
    // Branch
    if ((instr & 0x0E000000) == 0x0A000000) {
        ir.op = IROp::B;
        ir.imm = instr & 0x00FFFFFF;
        out.push_back(ir);
        return;
    }
    ir.op = IROp::NOP;
    out.push_back(ir);
}
