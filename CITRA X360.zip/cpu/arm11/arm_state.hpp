
#pragma once
#include <cstdint>

struct ARMState {
    uint32_t r[16];
    uint32_t cpsr;
};


// Expanded declarations
void Tick();
