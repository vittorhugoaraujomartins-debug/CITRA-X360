
#pragma once
#include <cstdint>

enum ARMOpcode {
    OP_NOP,
    OP_ADD,
    OP_SUB,
    OP_MOV,
    OP_B
};

ARMOpcode DecodeARM(uint32_t instr);
