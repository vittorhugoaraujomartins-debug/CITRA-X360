
#pragma once
#include "arm_state.hpp"
#include <cstdint>

class ARMJIT {
public:
    void ExecuteBlock(ARMState& state, uint32_t* code, int count);
};
