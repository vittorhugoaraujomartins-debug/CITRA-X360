#include <cstdint>
#include "arm_state.hpp"

ARMOpcode Decode(uint32_t instr);
uint32_t Read32(uint32_t addr);
void Write32(uint32_t addr, uint32_t v);

void Execute(uint32_t instr, ARMState& s) {
    switch(Decode(instr)) {
        case OP_MOV: {
            uint32_t rd = (instr >> 12) & 0xF;
            uint32_t imm = instr & 0xFF;
            s.r[rd] = imm;
            break;
        }
        case OP_ADD: {
            uint32_t rd = (instr >> 12) & 0xF;
            uint32_t rn = (instr >> 16) & 0xF;
            uint32_t imm = instr & 0xFF;
            s.r[rd] = s.r[rn] + imm;
            break;
        }
        case OP_SUB: {
            uint32_t rd = (instr >> 12) & 0xF;
            uint32_t rn = (instr >> 16) & 0xF;
            uint32_t imm = instr & 0xFF;
            s.r[rd] = s.r[rn] - imm;
            break;
        }
        case OP_LDR: {
            uint32_t rd = (instr >> 12) & 0xF;
            uint32_t rn = (instr >> 16) & 0xF;
            uint32_t off = instr & 0xFFF;
            uint32_t addr = s.r[rn] + off;
            s.r[rd] = Read32(addr);
            break;
        }
        case OP_STR: {
            uint32_t rd = (instr >> 12) & 0xF;
            uint32_t rn = (instr >> 16) & 0xF;
            uint32_t off = instr & 0xFFF;
            uint32_t addr = s.r[rn] + off;
            Write32(addr, s.r[rd]);
            break;
        }
        case OP_B: {
            int32_t off = ((instr & 0x00FFFFFF) << 2);
            s.r[15] += off;
            break;
        }
        case OP_BL: {
            int32_t off = ((instr & 0x00FFFFFF) << 2);
            s.r[14] = s.r[15];
            s.r[15] += off;
            break;
        }
        default:
            break;
    }
}
