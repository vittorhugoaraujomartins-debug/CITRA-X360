#include <cstdint>
#include "arm_state.hpp"

uint32_t Read32(uint32_t addr);
void Execute(uint32_t instr, ARMState& s);

void ExecuteBlock(ARMState& state, uint32_t maxInstr) {
    for (uint32_t i = 0; i < maxInstr; i++) {
        uint32_t pc = state.r[15];
        uint32_t instr = Read32(pc);
        state.r[15] += 4;
        Execute(instr, state);
    }
}
