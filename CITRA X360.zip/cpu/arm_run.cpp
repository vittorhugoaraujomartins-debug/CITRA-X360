
#include <cstdint>
extern "C" void MMU_Write32(uint32_t addr, uint32_t value);

void ARM_RunHello() {
    MMU_Write32(0x10000000, 0x00FF00); // green screen
}
