
#include <cstdint>
#include <vector>

struct ARMState {
    uint32_t r[16];
    uint32_t cpsr;
};

enum ARMOp {
    OP_NOP,
    OP_MOV_IMM,
    OP_ADD,
    OP_SUB,
    OP_LDR,
    OP_STR,
    OP_B
};

struct IRInst {
    ARMOp op;
    uint32_t a, b, c;
};

struct IRBlock {
    uint32_t pc;
    std::vector<IRInst> insts;
};

static IRBlock DecodeBlock(uint32_t* code, uint32_t pc) {
    IRBlock block;
    block.pc = pc;

    for (int i = 0; i < 16; ++i) {
        uint32_t instr = code[i];
        IRInst ir{};
        if ((instr & 0x0FE00000) == 0x03A00000) {
            ir.op = OP_MOV_IMM;
            ir.a = (instr >> 12) & 0xF;
            ir.b = instr & 0xFF;
        } else if ((instr & 0x0FE00000) == 0x02800000) {
            ir.op = OP_ADD;
            ir.a = (instr >> 12) & 0xF;
            ir.b = (instr >> 16) & 0xF;
            ir.c = instr & 0xFF;
        } else if ((instr & 0x0F000000) == 0x0A000000) {
            ir.op = OP_B;
            block.insts.push_back(ir);
            break;
        } else {
            ir.op = OP_NOP;
        }
        block.insts.push_back(ir);
    }
    return block;
}

static void ExecuteBlock(const IRBlock& block, ARMState& s) {
    for (auto& ir : block.insts) {
        switch (ir.op) {
            case OP_MOV_IMM: s.r[ir.a] = ir.b; break;
            case OP_ADD: s.r[ir.a] = s.r[ir.b] + ir.c; break;
            case OP_SUB: s.r[ir.a] = s.r[ir.b] - ir.c; break;
            default: break;
        }
    }
}
