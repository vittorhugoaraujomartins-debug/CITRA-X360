
#include "service_fs_min.h"
void RegisterFSServiceMin(MemorySystemX360&) {}
