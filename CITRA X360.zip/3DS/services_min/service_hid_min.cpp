
#include "service_hid_min.h"
void RegisterHIDServiceMin(MemorySystemX360&) {}
