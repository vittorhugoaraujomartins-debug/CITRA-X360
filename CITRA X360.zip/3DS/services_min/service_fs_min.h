
#pragma once
class MemorySystemX360;
void RegisterFSServiceMin(MemorySystemX360& mem);
