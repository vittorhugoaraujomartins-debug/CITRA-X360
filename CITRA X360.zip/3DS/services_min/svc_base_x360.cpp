
#include "svc_base_x360.h"
#include "arm_state_x360.h"

namespace SVCX360 {

void SleepThread(ARMStateX360& cpu) {
    cpu.R[0] = 0;
}

void GetThreadId(ARMStateX360& cpu) {
    cpu.R[0] = 1;
}

void ExitProcess(ARMStateX360& cpu) {
    cpu.running = false;
}

}
