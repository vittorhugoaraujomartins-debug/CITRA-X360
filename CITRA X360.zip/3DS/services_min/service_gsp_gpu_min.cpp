
#include "service_gsp_gpu_min.h"
void RegisterGSPGPUServiceMin(MemorySystemX360&) {}
