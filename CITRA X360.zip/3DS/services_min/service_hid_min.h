
#pragma once
class MemorySystemX360;
void RegisterHIDServiceMin(MemorySystemX360& mem);
