
#pragma once
class MemorySystemX360;
void RegisterGSPGPUServiceMin(MemorySystemX360& mem);
