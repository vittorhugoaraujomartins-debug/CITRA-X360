#include "apt_service_x360.h"
#include "ipc_reader_x360.h"

void APTServiceX360::HandleSync(uint32_t cmdId, IPCReaderX360& ipc)
{
    switch (cmdId)
    {
    case 0x0001:
        GetLockHandle(ipc);
        break;

    case 0x0002:
        Initialize(ipc);
        break;

    case 0x0003:
        Enable(ipc);
        break;

    default:
        ipc.WriteResult(0xFFFFFFFF);
        break;
    }
}

void APTServiceX360::GetLockHandle(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}

void APTServiceX360::Initialize(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}

void APTServiceX360::Enable(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}