#pragma once
#include <memory>
#include <unordered_map>

class EventX360;
class MutexX360;

class KernelObjectsX360 {
public:
    int CreateEvent(bool sticky);
    int CreateMutex();

    EventX360* GetEvent(int handle);
    MutexX360* GetMutex(int handle);

private:
    int nextHandle = 0x200;

    std::unordered_map<int,std::unique_ptr<EventX360>> events;
    std::unordered_map<int,std::unique_ptr<MutexX360>> mutexes;
};