#include "service_manager_x360.h"
#include "memory_system_x360.h"

ServiceManagerX360::ServiceManagerX360(MemorySystemX360& mem)
    : memory(mem) {}

void ServiceManagerX360::RegisterService(
    const std::string& name,
    ServiceHandler handler)
{
    uint32_t handle = nextHandle++;
    nameToHandle[name] = handle;
    handleToHandler[handle] = handler;
}

uint32_t ServiceManagerX360::GetServiceHandle(const std::string& name)
{
    auto it = nameToHandle.find(name);
    if (it != nameToHandle.end())
        return it->second;

    return 0;
}

void ServiceManagerX360::HandleSyncRequest(uint32_t msgPtr, uint32_t handle)
{
    auto it = handleToHandler.find(handle);

    if (it == handleToHandler.end()) {
        memory.Write32(msgPtr, 0xFFFFFFFF);
        return;
    }

    ServiceHandler fn = it->second;
    fn(memory, msgPtr);
}

uint32_t ServiceManagerX360::BuildResponseHeader(uint32_t cmd_id, uint32_t words)
{
    return (cmd_id << 16) | (words & 0x3F);
}