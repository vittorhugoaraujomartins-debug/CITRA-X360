#include "event_x360.h"
#include "kernel_thread_x360.h"

EventX360::EventX360(
    ResetTypeX360 type)
    : resetType(type) {}

bool EventX360::ShouldWait(
    KernelThreadX360*)
{
    return !signaled;
}

void EventX360::Acquire(
    KernelThreadX360*)
{
    if (resetType == ResetTypeX360::OneShot)
        signaled = false;
}

void EventX360::Signal()
{
    signaled = true;
    WakeAll();
}

void EventX360::Clear()
{
    signaled = false;
}