#pragma once
#include "wait_object_x360.h"

enum class ResetTypeX360 {
    OneShot,
    Sticky
};

class EventX360 : public WaitObjectX360 {
public:
    EventX360(ResetTypeX360 type);

    bool ShouldWait(KernelThreadX360* t) override;
    void Acquire(KernelThreadX360* t) override;

    void Signal();
    void Clear();

private:
    bool signaled = false;
    ResetTypeX360 resetType;
};