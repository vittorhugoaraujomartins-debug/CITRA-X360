#pragma once
#include <cstdint>

class IPCReaderX360;

class GSPGPUServiceX360 {
public:
    void HandleSync(uint32_t cmdId, IPCReaderX360& ipc);

private:
    void Initialize(IPCReaderX360& ipc);
    void SubmitCommandList(IPCReaderX360& ipc);
    void SetBufferSwap(IPCReaderX360& ipc);
};
