#include "service_gsp_gpu_min_x360.h"
#include "ipc_reader_x360.h"

void GSPGPUServiceX360::HandleSync(uint32_t cmdId, IPCReaderX360& ipc)
{
    switch (cmdId)
    {
    case 0x0001:
        Initialize(ipc);
        break;
    case 0x0005:
        SubmitCommandList(ipc);
        break;
    case 0x000B:
        SetBufferSwap(ipc);
        break;
    default:
        ipc.WriteResult(0);
        break;
    }
}

void GSPGPUServiceX360::Initialize(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}

void GSPGPUServiceX360::SubmitCommandList(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}

void GSPGPUServiceX360::SetBufferSwap(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}


#include "xenos_gpu_bridge_x360.h"

static XenosGPUBridgeX360 gpu;

void GSPGPUServiceX360::SubmitGxCommand(
    IPCReaderX360& ipc)
{
    gpu.DrawFakeTriangle();
    ipc.WriteResult(0);
}