#pragma once
#include <vector>

class KernelThreadX360;

class WaitObjectX360 {
public:
    virtual ~WaitObjectX360() = default;

    virtual bool ShouldWait(KernelThreadX360* t) = 0;
    virtual void Acquire(KernelThreadX360* t) = 0;

    void AddWaiting(KernelThreadX360* t);
    void WakeAll();

protected:
    std::vector<KernelThreadX360*> waiting;
};