#pragma once
#include <cstdint>
#include <string>
#include <unordered_map>

class MemorySystemX360;

typedef void (*ServiceHandler)(MemorySystemX360&, uint32_t msgPtr);

class ServiceManagerX360 {
public:
    ServiceManagerX360(MemorySystemX360& mem);

    void RegisterService(const std::string& name, ServiceHandler handler);
    uint32_t GetServiceHandle(const std::string& name);

    void HandleSyncRequest(uint32_t msgPtr, uint32_t handle);

    static uint32_t BuildResponseHeader(uint32_t cmd_id, uint32_t words);

private:
    MemorySystemX360& memory;

    std::unordered_map<std::string, uint32_t> nameToHandle;
    std::unordered_map<uint32_t, ServiceHandler> handleToHandler;

    uint32_t nextHandle = 0x100;
};