#include "dsp_service_x360.h"
#include "ipc_reader_x360.h"

void DSPServiceX360::HandleSync(uint32_t cmdId, IPCReaderX360& ipc)
{
    switch (cmdId)
    {
    case 0x0001:
        LoadComponent(ipc);
        break;

    case 0x0002:
        GetSemaphore(ipc);
        break;

    default:
        ipc.WriteResult(0xFFFFFFFF);
        break;
    }
}

void DSPServiceX360::LoadComponent(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}

void DSPServiceX360::GetSemaphore(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}