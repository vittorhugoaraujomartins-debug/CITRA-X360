#pragma once
#include "wait_object_x360.h"

class MutexX360 : public WaitObjectX360 {
public:
    bool ShouldWait(KernelThreadX360* t) override;
    void Acquire(KernelThreadX360* t) override;

    void Release(KernelThreadX360* t);

private:
    KernelThreadX360* owner = nullptr;
    int lockCount = 0;
};