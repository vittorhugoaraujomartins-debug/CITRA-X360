#pragma once
#include "wait_object_x360.h"

class MutexX360 : public WaitObjectX360 {
public:
    bool ShouldWait(KernelThreadX360* t) override;
    void Acquire(KernelThreadX360* t) override;
    bool TryAcquire(KernelThreadX360* t);
    void Release(KernelThreadX360* t);

    KernelThreadX360* GetOwner() const { return owner; }
    int GetLockCount() const { return lockCount; }

private:
    KernelThreadX360* owner = nullptr;
    int lockCount = 0;
};
