#include "service_hid_min_x360.h"
#include "ipc_reader_x360.h"

void HIDServiceX360::HandleSync(uint32_t cmdId, IPCReaderX360& ipc)
{
    switch (cmdId)
    {
    case 0x000A:
        GetSharedMemoryHandle(ipc);
        break;
    case 0x0011:
        EnableAccelerometer(ipc);
        break;
    case 0x0012:
        EnableGyro(ipc);
        break;
    default:
        ipc.WriteResult(0);
        break;
    }
}

void HIDServiceX360::GetSharedMemoryHandle(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}

void HIDServiceX360::EnableAccelerometer(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}

void HIDServiceX360::EnableGyro(IPCReaderX360& ipc)
{
    ipc.WriteResult(0);
}
