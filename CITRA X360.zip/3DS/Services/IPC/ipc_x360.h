#pragma once
#include <cstdint>

class MemorySystemX360;
class ServiceManagerX360;

class IPCX360 {
public:
    IPCX360(MemorySystemX360& mem,
            ServiceManagerX360& sm);

    void SendSyncRequest(uint32_t messagePtr,
                         uint32_t handle);

private:
    MemorySystemX360& memory;
    ServiceManagerX360& serviceManager;
};