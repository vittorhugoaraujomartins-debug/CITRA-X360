#pragma once
#include <cstdint>

class IPCReaderX360;

class HIDServiceX360 {
public:
    void HandleSync(uint32_t cmdId, IPCReaderX360& ipc);

private:
    void GetSharedMemoryHandle(IPCReaderX360& ipc);
    void EnableAccelerometer(IPCReaderX360& ipc);
    void EnableGyro(IPCReaderX360& ipc);
};
