#pragma once
#include <cstdint>

class IPCReaderX360;

class APTServiceX360 {
public:
    void HandleSync(uint32_t cmdId, IPCReaderX360& ipc);

private:
    void GetLockHandle(IPCReaderX360& ipc);
    void Initialize(IPCReaderX360& ipc);
    void Enable(IPCReaderX360& ipc);
};