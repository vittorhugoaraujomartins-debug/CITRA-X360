#include "vertex_loader.h"
#include "common/alignment.h"
#include "common/logging/log.h"

namespace Pica {

template <typename T>
T VertexLoader::ReadBE(PAddr addr) const {
    T v{};
    memory.ReadBlock(addr, &v, sizeof(T));

#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    return v;
#else
    return Common::SwapEndian(v);
#endif
}

template <typename T>
void VertexLoader::LoadAttribute(PAddr addr, u32 attrib,
                                 AttributeBuffer& out) const {
    for (u32 c = 0; c < elements[attrib]; ++c) {
        T raw = ReadBE<T>(addr + sizeof(T) * c);
        out[attrib][c] = f24::FromFloat32(static_cast<float>(raw));
    }
}

VertexLoader::VertexLoader(Memory::MemorySystem& mem,
                           const PipelineRegs& regs)
    : memory(mem) {

    const auto& cfg = regs.vertex_attributes;
    num_attributes = cfg.GetNumTotalAttributes();

    for (u32 i = 0; i < 16; i++)
        is_default[i] = cfg.IsDefaultAttribute(i);

    for (u32 loader = 0; loader < 12; loader++) {
        const auto& l = cfg.attribute_loaders[loader];
        u32 offset = 0;

        for (u32 c = 0; c < l.component_count; c++) {
            u32 id = l.GetComponent(c);

            if (id < 12) {
                offset = Common::AlignUp(offset,
                         cfg.GetElementSizeInBytes(id));

                sources[id]  = l.data_offset + offset;
                strides[id]  = l.byte_count;
                formats[id]  = cfg.GetFormat(id);
                elements[id] = cfg.GetNumElements(id);

                offset += cfg.GetStride(id);
            }
        }
    }
}

void VertexLoader::LoadVertex(PAddr base, u32, u32 vertex,
                              AttributeBuffer& input,
                              AttributeBuffer& defaults) const {
    for (u32 i = 0; i < num_attributes; i++) {
        if (is_default[i]) {
            input[i] = defaults[i];
            continue;
        }

        if (elements[i] == 0)
            continue;

        const PAddr addr = base + sources[i] + strides[i] * vertex;

        switch (formats[i]) {
        case PipelineRegs::VertexAttributeFormat::BYTE:
            LoadAttribute<s8>(addr, i, input);
            break;
        case PipelineRegs::VertexAttributeFormat::UBYTE:
            LoadAttribute<u8>(addr, i, input);
            break;
        case PipelineRegs::VertexAttributeFormat::SHORT:
            LoadAttribute<s16>(addr, i, input);
            break;
        case PipelineRegs::VertexAttributeFormat::FLOAT:
            LoadAttribute<f32>(addr, i, input);
            break;
        }

        for (u32 c = elements[i]; c < 4; c++)
            input[i][c] = (c == 3) ? f24::One() : f24::Zero();
    }
}

} // namespace Pica
