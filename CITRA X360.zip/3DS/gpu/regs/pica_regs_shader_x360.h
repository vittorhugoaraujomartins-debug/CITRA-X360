#pragma once

namespace Pica::X360 {

struct ShaderRegs {
    BitField<0, 16, u32> bool_uniforms;

    union IntUniform {
        BitField<0, 8, u32> x;
        BitField<8, 8, u32> y;
        BitField<16, 8, u32> z;
        BitField<24, 8, u32> w;
    } int_uniforms[4];

    Common::Vec4<u8> GetIntUniform(u32 idx) const {
        const auto& v = int_uniforms[idx];
        return {v.x, v.y, v.z, v.w};
    }

    u32 pad0[4];

    BitField<0, 4, u32> max_input_attr;
    BitField<24, 8, u32> shader_mode;

    BitField<0, 16, u32> entry;

    u32 attr_map_lo;
    u32 attr_map_hi;

    BitField<0, 16, u32> output_mask;

    u32 pad1[2];

    struct {
        BitField<0, 7, u32> index;
        BitField<31, 1, u32> is_f32;
        u32 value[8];
    } uniform;

    u32 pad2[2];

    struct {
        u32 offset;
        u32 word[8];
    } program;

    u32 pad3;

    struct {
        u32 offset;
        u32 word[8];
    } swizzle;

    u32 pad4[2];
};

static_assert(sizeof(ShaderRegs) == 0x30 * sizeof(u32),
              "ShaderRegs X360 size mismatch");

} // namespace Pica::X360