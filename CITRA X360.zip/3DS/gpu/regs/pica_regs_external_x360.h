#pragma once

#include <array>
#include "common/types.h"

namespace Pica::X360 {

/**
 * Registradores externos da PICA200
 * Esses são mapeados na MMIO do 3DS
 */
struct ExternalRegs {
    // Controle geral
    u32 gpu_control{0};
    u32 gpu_status{0};

    // Framebuffer
    u32 framebuffer_addr{0};
    u32 framebuffer_width{0};
    u32 framebuffer_height{0};
    u32 framebuffer_format{0};

    // Viewport
    s32 viewport_x{0};
    s32 viewport_y{0};
    s32 viewport_width{0};
    s32 viewport_height{0};

    // Clear
    u32 clear_color{0};
    u32 clear_depth{0};

    // Command processor
    u32 command_buffer_addr{0};
    u32 command_buffer_size{0};
    u32 command_buffer_offset{0};

    // Interrupt flags
    bool irq_gpu{false};

    void Reset() {
        gpu_control = 0;
        gpu_status = 0;
        framebuffer_addr = 0;
        framebuffer_width = 0;
        framebuffer_height = 0;
        framebuffer_format = 0;
        viewport_x = viewport_y = 0;
        viewport_width = viewport_height = 0;
        clear_color = 0;
        clear_depth = 0;
        command_buffer_addr = 0;
        command_buffer_size = 0;
        command_buffer_offset = 0;
        irq_gpu = false;
    }
};

} // namespace Pica::X360