#pragma once


namespace Pica::X360 {

union ColorFill {
    u32 raw;

    BitField<0, 8, u32> r;
    BitField<8, 8, u32> g;
    BitField<16, 8, u32> b;
    BitField<24, 1, u32> enable;

    Common::Vec3<u8> ToVec() const {
        return {static_cast<u8>(r), static_cast<u8>(g), static_cast<u8>(b)};
    }
};

struct RegsLcd {
    u32 pad0[0x81];
    ColorFill top_fill;
    u32 pad1[0xE];
    u32 backlight_top;
    u32 pad2[0x1F0];
    ColorFill bottom_fill;
    u32 pad3[0xE];
    u32 backlight_bottom;
    u32 pad4[0x16F];

    static constexpr u32 NumRegs() {
        return sizeof(RegsLcd) / sizeof(u32);
    }

    u32& operator[](u32 idx) {
        return reinterpret_cast<u32*>(this)[idx];
    }

    const u32& operator[](u32 idx) const {
        return reinterpret_cast<const u32*>(this)[idx];
    }
};

static_assert(sizeof(RegsLcd) == 0x400 * sizeof(u32),
              "RegsLcd X360 size mismatch");

} // namespace Pica::X360