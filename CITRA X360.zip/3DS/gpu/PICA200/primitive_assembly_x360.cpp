#include "video_core/pica_x360/primitive_assembly_x360.h"
#include "common/logging/log.h"

namespace Pica::X360 {

PrimitiveAssembler::PrimitiveAssembler(
    PipelineRegs::TriangleTopology topology)
    : topology(topology) {}

void PrimitiveAssembler::SubmitVertex(
    const OutputVertex& vtx,
    const TriangleHandler& triangle_handler) {

    switch (topology) {
    case PipelineRegs::TriangleTopology::List:
    case PipelineRegs::TriangleTopology::Shader:
        if (buffer_index < 2) {
            buffer[buffer_index++] = vtx;
        } else {
            buffer_index = 0;

            if (topology == PipelineRegs::TriangleTopology::Shader && winding) {
                triangle_handler(buffer[1], buffer[0], vtx);
                winding = false;
            } else {
                triangle_handler(buffer[0], buffer[1], vtx);
            }
        }
        break;

    case PipelineRegs::TriangleTopology::Strip:
    case PipelineRegs::TriangleTopology::Fan:
        if (strip_ready) {
            triangle_handler(buffer[0], buffer[1], vtx);
        }

        buffer[buffer_index] = vtx;
        strip_ready |= (buffer_index == 1);

        if (topology == PipelineRegs::TriangleTopology::Strip) {
            buffer_index ^= 1;
        } else {
            buffer_index = 1;
        }
        break;

    default:
        LOG_ERROR(HW_GPU,
                  "X360 PrimitiveAssembler: unknown topology {:x}",
                  static_cast<u32>(topology));
        break;
    }
}

} // namespace Pica::X360