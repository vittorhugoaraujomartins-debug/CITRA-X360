#pragma once

#include <array>
#include <functional>

#include "video_core/pica_x360/output_vertex_x360.h"
#include "video_core/pica_x360/regs_pipeline_x360.h"

namespace Pica::X360 {

/**
 * Builds triangles from submitted vertices according to PICA200 topology rules.
 * Pure CPU-side logic, renderer-agnostic.
 */
struct PrimitiveAssembler {
    using TriangleHandler =
        std::function<void(const OutputVertex&, const OutputVertex&, const OutputVertex&)>;

    explicit PrimitiveAssembler(
        PipelineRegs::TriangleTopology topology =
            PipelineRegs::TriangleTopology::List);

    void SubmitVertex(const OutputVertex& vtx,
                      const TriangleHandler& triangle_handler);

    void SetWinding() noexcept {
        winding = true;
    }

    void Reset() {
        buffer_index = 0;
        strip_ready = false;
        winding = false;
    }

    void Reconfigure(PipelineRegs::TriangleTopology new_topology) {
        Reset();
        topology = new_topology;
    }

    bool IsEmpty() const {
        return buffer_index == 0 && !strip_ready;
    }

    PipelineRegs::TriangleTopology GetTopology() const {
        return topology;
    }

private:
    PipelineRegs::TriangleTopology topology;

    int buffer_index = 0;
    std::array<OutputVertex, 2> buffer{};
    bool strip_ready = false;
    bool winding = false;
};

} // namespace Pica::X360