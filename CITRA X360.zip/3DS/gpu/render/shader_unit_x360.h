#pragma once

#include <array>
#include <span>
#include "video_core/pica/output_vertex.h"

namespace Pica {

/**
 * Unidade de execução PICA200 (modo interpretado).
 * Cada instância representa um shader rodando.
 */
struct ShaderUnitX360 {
    ShaderUnitX360();

    void LoadInput(const ShaderRegs& regs, const AttributeBuffer& input);
    void WriteOutput(const ShaderRegs& regs, AttributeBuffer& output);

    // Registros PICA
    alignas(16) std::array<Common::Vec4<f24>, 16> input_regs{};
    alignas(16) std::array<Common::Vec4<f24>, 16> temp_regs{};
    alignas(16) std::array<Common::Vec4<f24>, 16> output_regs{};

    s32 address_regs[3]{};
    bool condition_flags[2]{};
};

} // namespace Pica