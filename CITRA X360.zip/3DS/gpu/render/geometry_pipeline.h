#pragma once

#include <memory>
#include "shader_unit.h"
#include "output_vertex.h"

namespace Pica {

struct RegsInternal;
struct GeometryShaderUnit;
struct ShaderSetup;
class ShaderEngine;

class GeometryPipelineBackend;

/// Pipeline simples e determinístico (Xbox 360)
class GeometryPipeline {
public:
    GeometryPipeline(RegsInternal& regs,
                     GeometryShaderUnit& gs_unit,
                     ShaderSetup& gs);
    ~GeometryPipeline();

    void SetVertexHandler(VertexHandler handler);

    /// Inicializa GS se ativo (senão vira passthrough)
    void Setup(ShaderEngine* engine);

    /// Recria backend conforme registradores
    void Reconfigure();

    bool NeedIndexInput() const;
    void SubmitIndex(u32 index);

    /// Recebe saída do Vertex Shader
    void SubmitVertex(const AttributeBuffer& input);

private:
    VertexHandler vertex_handler{};
    ShaderEngine* shader_engine{nullptr};

    std::unique_ptr<GeometryPipelineBackend> backend;

    RegsInternal& regs;
    GeometryShaderUnit& gs_unit;
    ShaderSetup& gs;
};

} // namespace Pica
