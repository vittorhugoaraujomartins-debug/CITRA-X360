#pragma once
#include "vfp_state_x360.h"

inline void VFP_SyncDFromS(VFPStateX360& vfp)
{
    for (int i=0;i<16;i++) {
        uint64_t lo = vfp.s[i*2];
        uint64_t hi = vfp.s[i*2+1];
        vfp.d[i] = lo | (hi << 32);
    }
}

inline void VFP_SyncSFromD(VFPStateX360& vfp)
{
    for (int i=0;i<16;i++) {
        vfp.s[i*2]   = (uint32_t)(vfp.d[i] & 0xFFFFFFFF);
        vfp.s[i*2+1] = (uint32_t)(vfp.d[i] >> 32);
    }
}