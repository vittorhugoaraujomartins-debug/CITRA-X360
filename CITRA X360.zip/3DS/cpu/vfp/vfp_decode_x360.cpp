#include "vfp_decode_x360.h"

#define BIT(x,n) (((x)>>(n))&1)
#define BITS(x,a,b) (((x)>>(a)) & ((1u<<((b)-(a)+1))-1))

static int decode_sreg(uint32_t inst, int base_low, int base_high, int extra_bit) {
    return (BITS(inst, base_low, base_high) << 1) | BIT(inst, extra_bit);
}

VFPDecodedX360 DecodeVFP_X360(uint32_t inst) {

    VFPDecodedX360 d{};
    d.op = VFP_OpX360::NONE;

    // detect VFP major class
    if ((inst & 0x0F000E10) != 0x0E000A00)
        return d;

    const bool dp = BIT(inst, 8); // double flag (ignoramos — tratamos como single)

    int Sd = decode_sreg(inst, 12, 15, 22);
    int Sn = decode_sreg(inst, 16, 19, 7);
    int Sm = decode_sreg(inst, 0, 3, 5);

    d.Sd = Sd;
    d.Sn = Sn;
    d.Sm = Sm;

    uint32_t opcode = (inst >> 20) & 0xF;

    switch (opcode) {

        case 0b0011: d.op = VFP_OpX360::VADD; break;
        case 0b0010: d.op = VFP_OpX360::VMUL; break;
        case 0b0100: d.op = VFP_OpX360::VDIV; break;
        case 0b0011 | 1: d.op = VFP_OpX360::VSUB; break;

        default:
            break;
    }

    // unary ops
    if ((inst & 0x0FB00F50) == 0x0EB00A40) d.op = VFP_OpX360::VABS;
    if ((inst & 0x0FB00F50) == 0x0EB10A40) d.op = VFP_OpX360::VNEG;
    if ((inst & 0x0FB00F50) == 0x0EB10AC0) d.op = VFP_OpX360::VSQRT;

    return d;
}