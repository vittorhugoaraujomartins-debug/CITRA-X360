#include "vfp_state_x360.h"
#include "vfp_helpers_x360.h"
#include "vfp_regs_x360.h"
#include <cmath>

static void vfp_update_flags(VFPStateX360& vfp, float result) {

    if (result == 0.0f)
        vfp.FPSCR |= VFP_FPSCR_Z;
    else
        vfp.FPSCR &= ~VFP_FPSCR_Z;

    if (std::signbit(result))
        vfp.FPSCR |= VFP_FPSCR_N;
    else
        vfp.FPSCR &= ~VFP_FPSCR_N;
}

void VFP_FADD(VFPStateX360& vfp, int dst, int a, int b) {
    float fa = vfp_u32_to_f32(vfp.s[a]);
    float fb = vfp_u32_to_f32(vfp.s[b]);

    float r = fa + fb;

    vfp.s[dst] = vfp_f32_to_u32(r);
    vfp_update_flags(vfp, r);
}

void VFP_FSUB(VFPStateX360& vfp, int dst, int a, int b) {
    float fa = vfp_u32_to_f32(vfp.s[a]);
    float fb = vfp_u32_to_f32(vfp.s[b]);

    float r = fa - fb;

    vfp.s[dst] = vfp_f32_to_u32(r);
    vfp_update_flags(vfp, r);
}

void VFP_FMUL(VFPStateX360& vfp, int dst, int a, int b) {
    float fa = vfp_u32_to_f32(vfp.s[a]);
    float fb = vfp_u32_to_f32(vfp.s[b]);

    float r = fa * fb;

    vfp.s[dst] = vfp_f32_to_u32(r);
    vfp_update_flags(vfp, r);
}

void VFP_FDIV(VFPStateX360& vfp, int dst, int a, int b) {
    float fa = vfp_u32_to_f32(vfp.s[a]);
    float fb = vfp_u32_to_f32(vfp.s[b]);

    float r = fa / fb;

    vfp.s[dst] = vfp_f32_to_u32(r);
    vfp_update_flags(vfp, r);
}

void VFP_FSQRT(VFPStateX360& vfp, int dst, int a) {
    float fa = vfp_u32_to_f32(vfp.s[a]);

    float r = std::sqrt(fa);

    vfp.s[dst] = vfp_f32_to_u32(r);
    vfp_update_flags(vfp, r);
}


void VFP_FMLA(VFPStateX360& vfp, int dst, int a, int b)
{
    float fd = vfp_u32_to_f32(vfp.s[dst]);
    float fa = vfp_u32_to_f32(vfp.s[a]);
    float fb = vfp_u32_to_f32(vfp.s[b]);

    float r = fd + (fa * fb);

    vfp.s[dst] = vfp_f32_to_u32(r);
    vfp_update_flags(vfp, r);
}

void VFP_FMLS(VFPStateX360& vfp, int dst, int a, int b)
{
    float fd = vfp_u32_to_f32(vfp.s[dst]);
    float fa = vfp_u32_to_f32(vfp.s[a]);
    float fb = vfp_u32_to_f32(vfp.s[b]);

    float r = fd - (fa * fb);

    vfp.s[dst] = vfp_f32_to_u32(r);
    vfp_update_flags(vfp, r);
}