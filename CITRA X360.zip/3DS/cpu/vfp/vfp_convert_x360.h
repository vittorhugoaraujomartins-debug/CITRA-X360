// VMOV reg
if ((inst & 0x0FB00FF0) == 0x0EB00A00)
{
    d.op = VFP_OpX360::VMOV_REG;
}

// VMOV immediate (simplificado)
if ((inst & 0x0F800000) == 0x0F000000)
{
    d.op = VFP_OpX360::VMOV_IMM;
    d.imm = inst & 0xFF;
}

// MLA / MLS (simplificado)
if ((inst & 0x0FF000F0) == 0x0E200A00)
    d.op = VFP_OpX360::VMLA;

if ((inst & 0x0FF000F0) == 0x0E300A00)
    d.op = VFP_OpX360::VMLS;