#pragma once
#include <cstdint>
#include <cmath>

inline float vfp_u32_to_f32(uint32_t v) {
    union { uint32_t u; float f; } x;
    x.u = v;
    return x.f;
}

inline uint32_t vfp_f32_to_u32(float f) {
    union { uint32_t u; float f; } x;
    x.f = f;
    return x.u;
}

inline bool vfp_is_nan(float f) {
    return std::isnan(f);
}

inline bool vfp_is_inf(float f) {
    return std::isinf(f);
}