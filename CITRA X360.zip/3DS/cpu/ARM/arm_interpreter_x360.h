#pragma once

#include "core/arm/arm_interface.h"
#include "core/arm/x360/arm_state.h"

namespace Core {

class ARMInterpreterX360 final : public ARM_Interface {
public:
    ARMInterpreterX360(u32 id, std::shared_ptr<Core::Timing::Timer> timer);

    void Run() override;
    void Step() override;

    void ClearInstructionCache() override {}
    void InvalidateCacheRange(u32, std::size_t) override {}

    void ClearExclusiveState() override;

    void SetPageTable(const std::shared_ptr<Memory::PageTable>& page_table) override;

    void SetPC(u32 addr) override;
    u32 GetPC() const override;

    u32 GetReg(int index) const override;
    void SetReg(int index, u32 value) override;

    u32 GetVFPReg(int index) const override;
    void SetVFPReg(int index, u32 value) override;

    u32 GetVFPSystemReg(VFPSystemRegister reg) const override;
    void SetVFPSystemReg(VFPSystemRegister reg, u32 value) override;

    u32 GetCPSR() const override;
    void SetCPSR(u32 value) override;

    u32 GetCP15Register(CP15Register reg) const override;
    void SetCP15Register(CP15Register reg, u32 value) override;

    void SaveContext(ThreadContext& ctx) override;
    void LoadContext(const ThreadContext& ctx) override;

    void PrepareReschedule() override {}

protected:
    std::shared_ptr<Memory::PageTable> GetPageTable() const override;

private:
    ARMState state{};
    std::shared_ptr<Memory::PageTable> page_table;
};

} // namespace Core