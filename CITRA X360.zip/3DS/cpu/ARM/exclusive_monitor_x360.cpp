#include "exclusive_monitor_x360.h"
#include "core/memory.h"

namespace CoreX360 {

ExclusiveMonitorX360::ExclusiveMonitorX360(Memory::MemorySystem& mem, size_t cores)
    : memory(mem)
{
    states.resize(cores);
}

// ================= READ =================

u8 ExclusiveMonitorX360::Read8(size_t core, VAddr addr)
{
    states[core] = { addr, true };
    return memory.Read8(addr);
}

u16 ExclusiveMonitorX360::Read16(size_t core, VAddr addr)
{
    states[core] = { addr, true };
    return memory.Read16(addr);
}

u32 ExclusiveMonitorX360::Read32(size_t core, VAddr addr)
{
    states[core] = { addr, true };
    return memory.Read32(addr);
}

u64 ExclusiveMonitorX360::Read64(size_t core, VAddr addr)
{
    states[core] = { addr, true };
    return memory.Read64(addr);
}

// ================= WRITE =================

bool ExclusiveMonitorX360::Write8(size_t core, VAddr addr, u8 value)
{
    if (!states[core].valid || states[core].addr != addr)
        return false;

    memory.Write8(addr, value);
    states[core].valid = false;
    return true;
}

bool ExclusiveMonitorX360::Write16(size_t core, VAddr addr, u16 value)
{
    if (!states[core].valid || states[core].addr != addr)
        return false;

    memory.Write16(addr, value);
    states[core].valid = false;
    return true;
}

bool ExclusiveMonitorX360::Write32(size_t core, VAddr addr, u32 value)
{
    if (!states[core].valid || states[core].addr != addr)
        return false;

    memory.Write32(addr, value);
    states[core].valid = false;
    return true;
}

bool ExclusiveMonitorX360::Write64(size_t core, VAddr addr, u64 value)
{
    if (!states[core].valid || states[core].addr != addr)
        return false;

    memory.Write64(addr, value);
    states[core].valid = false;
    return true;
}

// ================= CLEAR =================

void ExclusiveMonitorX360::Clear(size_t core)
{
    states[core].valid = false;
}

}