#include "kernel_thread_x360.h"
#include "arm_state_x360.h"

KernelThreadX360::KernelThreadX360(
    uint32_t entry,
    uint32_t stackTop)
{
    entryPoint = entry;
    stackPointer = stackTop;

    cpu = new ARMStateX360();

    cpu->PC = entryPoint;
    cpu->R[13] = stackPointer; // SP
}