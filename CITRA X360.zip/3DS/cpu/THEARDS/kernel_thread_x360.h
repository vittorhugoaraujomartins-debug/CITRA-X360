#pragma once
#include <cstdint>

class ARMStateX360;

class KernelThreadX360 {
public:
    KernelThreadX360(uint32_t entry,
                     uint32_t stackTop);

    ARMStateX360* cpu;

    uint32_t entryPoint;
    uint32_t stackPointer;

    bool finished = false;
    bool requestYield = false;
};

bool blocked = false;