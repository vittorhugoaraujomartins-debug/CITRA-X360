#include "thread_manager_x360.h"
#include "arm_state_x360.h"

X360Thread::X360Thread(uint32_t tid, ARMState* state, uint32_t entry, uint32_t stack, int prio)
{
    id = tid;
    priority = prio;
    status = THREAD_READY;
    context.cpu = state;
    context.entry_point = entry;
    context.stack_top = stack;
    wake_tick = 0;
}

void ThreadSchedulerX360::CreateThread(uint32_t entry, uint32_t stack, int prio)
{
    ARMState* state = new ARMState();
    state->Reset();
    state->regs[15] = entry;
    state->regs[13] = stack;

    threads.push_back(new X360Thread(next_id++, state, entry, stack, prio));
}

void ThreadSchedulerX360::SleepThread(uint64_t ticks)
{
    if (!current) return;
    current->status = THREAD_SLEEPING;
    current->wake_tick = ticks;
}

void ThreadSchedulerX360::ExitThread()
{
    if (!current) return;
    current->status = THREAD_DEAD;
}

X360Thread* ThreadSchedulerX360::PickNext()
{
    X360Thread* best = nullptr;

    for (auto t : threads) {
        if (t->status != THREAD_READY) continue;
        if (!best || t->priority > best->priority)
            best = t;
    }

    return best;
}

void ThreadSchedulerX360::Tick()
{
    for (auto t : threads) {
        if (t->status == THREAD_SLEEPING && t->wake_tick == 0)
            t->status = THREAD_READY;
    }

    current = PickNext();
    if (current)
        current->status = THREAD_RUNNING;
}

X360Thread* ThreadSchedulerX360::GetCurrent()
{
    return current;
}