#include "timing_scheduler.h"

namespace CitraX360
{

Scheduler::Scheduler()
{
}

void Scheduler::Schedule(int64_t cyclesAhead,
                         SchedulerCallback cb,
                         uintptr_t userData)
{
    ScheduledEvent ev;

    ev.time = currentTicks + cyclesAhead;
    ev.order = fifoCounter++;
    ev.userData = userData;
    ev.callback = cb;

    events.push_back(ev);

    std::push_heap(events.begin(), events.end(), std::greater<>());
}

void Scheduler::Tick(uint64_t cycles)
{
    currentTicks += cycles;

    while(!events.empty() && events.front().time <= currentTicks)
    {
        ScheduledEvent ev = events.front();

        std::pop_heap(events.begin(), events.end(), std::greater<>());
        events.pop_back();

        if(ev.callback)
        {
            int late = (int)(currentTicks - ev.time);
            ev.callback(ev.userData, late);
        }
    }
}

uint64_t Scheduler::GetTicks() const
{
    return currentTicks;
}

}