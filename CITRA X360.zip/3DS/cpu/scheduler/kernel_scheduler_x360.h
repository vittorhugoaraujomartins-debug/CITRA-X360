#pragma once
#include <vector>

class KernelThreadX360;

class KernelSchedulerX360 {
public:
    void AddThread(KernelThreadX360* t);
    KernelThreadX360* Next();

private:
    std::vector<KernelThreadX360*> threads;
    size_t index = 0;
};