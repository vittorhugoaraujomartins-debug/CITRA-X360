#include "arm_tick_counts_x360.h"

u64 CPU_Interpreter::Step(u32 instruction)
{
    ExecuteInstruction(instruction);

    u64 ticks = CoreX360::GetTicksForInstruction(instruction);
    scheduler.Tick(ticks);

    return ticks;
}