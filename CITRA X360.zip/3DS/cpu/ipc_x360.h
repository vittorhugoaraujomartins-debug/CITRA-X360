#pragma once
#include <cstdint>

class MemorySystemX360;
class ServiceManagerX360;

class IPCX360 {
public:
    IPCX360(MemorySystemX360& mem, ServiceManagerX360& sm);

    // chamada pelo SVC SendSyncRequest
    void SendSyncRequest(uint32_t messagePtr, uint32_t serviceHandle);

    // helpers
    static uint32_t BuildHeader(uint16_t cmd, uint16_t paramCount);
    static uint16_t GetCmd(uint32_t header);
    static uint16_t GetParamCount(uint32_t header);

private:
    MemorySystemX360& memory;
    ServiceManagerX360& services;
};