#include "memory_system_x360.h"
#include <cstring>

namespace CoreX360 {

// =========================
// Endian swap (Xbox360 BE)
// =========================

template<> u16 MemorySystemX360::ByteSwapIfNeeded(u16 v) {
    return (v >> 8) | (v << 8);
}

template<> u32 MemorySystemX360::ByteSwapIfNeeded(u32 v) {
    return __builtin_bswap32(v);
}

template<> u64 MemorySystemX360::ByteSwapIfNeeded(u64 v) {
    return __builtin_bswap64(v);
}

template<> u8 MemorySystemX360::ByteSwapIfNeeded(u8 v) {
    return v;
}

// =========================
// PageTable
// =========================

void PageTableX360::Map(VAddr vaddr, u8* host, bool r, bool w) {
    size_t index = vaddr >> PAGE_SHIFT;
    entries[index] = {host, r, w};
}

PageEntry* PageTableX360::Get(VAddr addr) {
    return &entries[addr >> PAGE_SHIFT];
}

// =========================
// MemorySystemX360
// =========================

MemorySystemX360::MemorySystemX360() = default;
MemorySystemX360::~MemorySystemX360() = default;

void MemorySystemX360::Initialize() {
    fcram.resize(FCRAM_SIZE);
    vram.resize(VRAM_SIZE);
    dsp.resize(DSP_SIZE);

    // Map FCRAM base 0x20000000 (3DS padrão)
    for (size_t off = 0; off < FCRAM_SIZE; off += PAGE_SIZE) {
        page_table.Map(0x20000000 + off, fcram.data() + off, true, true);
    }

    // Map VRAM
    for (size_t off = 0; off < VRAM_SIZE; off += PAGE_SIZE) {
        page_table.Map(0x18000000 + off, vram.data() + off, true, true);
    }

    // Map DSP
    for (size_t off = 0; off < DSP_SIZE; off += PAGE_SIZE) {
        page_table.Map(0x1FF00000 + off, dsp.data() + off, true, true);
    }
}

// =========================
// Read Impl
// =========================

template<typename T>
T MemorySystemX360::ReadImpl(VAddr addr) {
    auto* entry = page_table.Get(addr);
    if (!entry->readable || !entry->host_ptr)
        return 0;

    T value;
    std::memcpy(&value, entry->host_ptr + (addr & PAGE_MASK), sizeof(T));
    return ByteSwapIfNeeded(value);
}

u8  MemorySystemX360::Read8(VAddr a){ return ReadImpl<u8>(a); }
u16 MemorySystemX360::Read16(VAddr a){ return ReadImpl<u16>(a); }
u32 MemorySystemX360::Read32(VAddr a){ return ReadImpl<u32>(a); }
u64 MemorySystemX360::Read64(VAddr a){ return ReadImpl<u64>(a); }

// =========================
// Write Impl
// =========================

template<typename T>
void MemorySystemX360::WriteImpl(VAddr addr, T value) {
    auto* entry = page_table.Get(addr);
    if (!entry->writable || !entry->host_ptr)
        return;

    value = ByteSwapIfNeeded(value);
    std::memcpy(entry->host_ptr + (addr & PAGE_MASK), &value, sizeof(T));
}

void MemorySystemX360::Write8 (VAddr a,u8  v){ WriteImpl(a,v); }
void MemorySystemX360::Write16(VAddr a,u16 v){ WriteImpl(a,v); }
void MemorySystemX360::Write32(VAddr a,u32 v){ WriteImpl(a,v); }
void MemorySystemX360::Write64(VAddr a,u64 v){ WriteImpl(a,v); }

// =========================
// Exclusive Writes (ARM)
// =========================

bool MemorySystemX360::WriteExclusive8(VAddr a,u8 v,u8 e){
    if(Read8(a)!=e) return false;
    Write8(a,v); return true;
}

bool MemorySystemX360::WriteExclusive16(VAddr a,u16 v,u16 e){
    if(Read16(a)!=e) return false;
    Write16(a,v); return true;
}

bool MemorySystemX360::WriteExclusive32(VAddr a,u32 v,u32 e){
    if(Read32(a)!=e) return false;
    Write32(a,v); return true;
}

bool MemorySystemX360::WriteExclusive64(VAddr a,u64 v,u64 e){
    if(Read64(a)!=e) return false;
    Write64(a,v); return true;
}

} // namespace CoreX360

// =========================
// Extended Mapping Helpers
// =========================

namespace CoreX360 {

static VirtualRegionManager g_region_manager;

// Map with execute flag + state tracking
void MapRegionEx(PageTableX360& pt,
                 VAddr base,
                 u8* host,
                 u32 size,
                 bool r,
                 bool w,
                 bool x,
                 MemState state)
{
    for (u32 off = 0; off < size; off += PAGE_SIZE) {
        pt.Map(base + off, host + off, r, w);
    }

    g_region_manager.AddRegion(base, size >> PAGE_SHIFT, r, w, x, state);
}

// Query region info
bool QueryRegion(VAddr addr, RegionInfo& out) {
    auto* r = g_region_manager.Query(addr);
    if (!r) return false;
    out = *r;
    return true;
}

// Simple virtual allocation (contiguous inside FCRAM)
VAddr AllocVirtualFromFCRAM(MemorySystemX360& mem,
                            u32 size,
                            bool r,
                            bool w,
                            bool x)
{
    static VAddr next = 0x21000000; // safe area after base map

    VAddr base = next;
    next += size;

    auto& pt = mem.GetPageTable();

    for (u32 off = 0; off < size; off += PAGE_SIZE) {
        auto* entry = pt.Get(0x20000000 + off);
        if (entry && entry->host_ptr) {
            pt.Map(base + off, entry->host_ptr, r, w);
        }
    }

    g_region_manager.AddRegion(base, size >> PAGE_SHIFT, r, w, x, MemState::Normal);

    return base;
}

// Remap virtual → virtual (alias mapping)
void RemapVirtualAlias(PageTableX360& pt,
                       VAddr dst,
                       VAddr src,
                       u32 size)
{
    for (u32 off = 0; off < size; off += PAGE_SIZE) {
        auto* e = pt.Get(src + off);
        if (e && e->host_ptr) {
            pt.Map(dst + off, e->host_ptr, e->readable, e->writable);
        }
    }
}

} // namespace CoreX360