#pragma once
#include <memory>
#include <vector>
#include <span>
#include "common_types.h"

class BackingMem {
public:
    virtual ~BackingMem() = default;
    virtual u8* GetPtr() = 0;
    virtual const u8* GetPtr() const = 0;
    virtual size_t GetSize() const = 0;
};

class BufferMem : public BackingMem {
public:
    explicit BufferMem(size_t size) : data(size) {}

    u8* GetPtr() override { return data.data(); }
    const u8* GetPtr() const override { return data.data(); }
    size_t GetSize() const override { return data.size(); }

private:
    std::vector<u8> data;
};

class MemoryRef {
public:
    MemoryRef() = default;
    MemoryRef(std::shared_ptr<BackingMem> mem, u64 off = 0)
        : backing(mem), offset(off) {
        Refresh();
    }

    u8* GetPtr() { return ptr; }
    const u8* GetPtr() const { return ptr; }
    size_t GetSize() const { return size; }

    std::span<u8> Span(size_t len) {
        return {ptr, std::min(len, size)};
    }

private:
    void Refresh() {
        if (!backing) {
            ptr = nullptr;
            size = 0;
            return;
        }
        ptr = backing->GetPtr() + offset;
        size = backing->GetSize() - offset;
    }

    std::shared_ptr<BackingMem> backing;
    u64 offset{};
    u8* ptr{};
    size_t size{};
};