#pragma once
#include "common/common_types.h"

namespace Common {

struct MemoryInfo {
    u64 total_physical_memory;
    u64 total_swap_memory;
};

MemoryInfo GetMemInfoX360();
u64 GetPageSizeX360();

}