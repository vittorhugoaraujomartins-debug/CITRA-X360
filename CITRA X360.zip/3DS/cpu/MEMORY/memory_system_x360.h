#pragma once

#include <cstdint>
#include <cstddef>
#include <vector>
#include <array>

namespace CoreX360 {

using u8  = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;

using VAddr = u32;
using PAddr = u32;

// =========================
// Configuração memória 3DS
// =========================

static constexpr size_t FCRAM_SIZE = 128 * 1024 * 1024;
static constexpr size_t VRAM_SIZE  = 6 * 1024 * 1024;
static constexpr size_t DSP_SIZE   = 512 * 1024;

static constexpr size_t PAGE_SIZE = 4096;
static constexpr size_t PAGE_SHIFT = 12;
static constexpr size_t PAGE_MASK = PAGE_SIZE - 1;

// =========================
// Page Table
// =========================

struct PageEntry {
    u8* host_ptr{};
    bool readable{};
    bool writable{};
};

class PageTableX360 {
public:
    void Map(VAddr vaddr, u8* host, bool r, bool w);
    PageEntry* Get(VAddr addr);

private:
    std::vector<PageEntry> entries{1 << 20}; // 4GB / 4KB
};

// =========================
// Memory System X360
// =========================

class MemorySystemX360 {
public:
    MemorySystemX360();
    ~MemorySystemX360();

    void Initialize();

    // ---------- Read ----------
    u8  Read8(VAddr addr);
    u16 Read16(VAddr addr);
    u32 Read32(VAddr addr);
    u64 Read64(VAddr addr);

    // ---------- Write ----------
    void Write8(VAddr addr, u8 v);
    void Write16(VAddr addr, u16 v);
    void Write32(VAddr addr, u32 v);
    void Write64(VAddr addr, u64 v);

    // ---------- Exclusive (ARM) ----------
    bool WriteExclusive8(VAddr addr, u8 value, u8 expected);
    bool WriteExclusive16(VAddr addr, u16 value, u16 expected);
    bool WriteExclusive32(VAddr addr, u32 value, u32 expected);
    bool WriteExclusive64(VAddr addr, u64 value, u64 expected);

    PageTableX360& GetPageTable() { return page_table; }

private:
    PageTableX360 page_table;

    std::vector<u8> fcram;
    std::vector<u8> vram;
    std::vector<u8> dsp;

private:
    template<typename T>
    T ReadImpl(VAddr addr);

    template<typename T>
    void WriteImpl(VAddr addr, T value);

    template<typename T>
    static T ByteSwapIfNeeded(T v);
};


// =========================
// Extended Memory Features
// =========================

namespace CoreX360 {

enum class MemState : uint8_t {
    Free = 0,
    Normal,
    Shared,
    Locked,
    Continuous
};

struct RegionInfo {
    VAddr base{};
    u32 pages{};
    bool r{};
    bool w{};
    bool x{};
    MemState state{MemState::Free};
};

class VirtualRegionManager {
public:
    void AddRegion(VAddr base, u32 pages, bool r, bool w, bool x, MemState state) {
        regions.push_back({base, pages, r, w, x, state});
    }

    RegionInfo* Query(VAddr addr) {
        for (auto& r : regions) {
            VAddr end = r.base + (r.pages << PAGE_SHIFT);
            if (addr >= r.base && addr < end)
                return &r;
        }
        return nullptr;
    }

private:
    std::vector<RegionInfo> regions;
};

} // namespace CoreX360