#include "memory_detect_x360.h"

// Valores fixos do Xbox 360
// 512 MB RAM total
// Page size típica 4 KB

namespace Common {

MemoryInfo GetMemInfoX360() {
    MemoryInfo info{};
    info.total_physical_memory = 512ull * 1024 * 1024;
    info.total_swap_memory = 0;
    return info;
}

u64 GetPageSizeX360() {
    return 4096;
}

}