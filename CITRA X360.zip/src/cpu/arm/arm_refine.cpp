
#include "arm_state.hpp"
void ExecMUL(ARMState& s, int rd, int rm, int rs){
    s.regs[rd] = s.regs[rm] * s.regs[rs];
    s.cpsr.Z = (s.regs[rd]==0);
    s.cpsr.N = (s.regs[rd]>>31)&1;
}
void ExecCMP(ARMState& s, int rn, int rm){
    int32_t r = s.regs[rn] - s.regs[rm];
    s.cpsr.Z = (r==0);
    s.cpsr.N = (r<0);
}
