
#include <unordered_map>
#include <cstdint>
struct Link { uint32_t from, to; };
static std::unordered_map<uint32_t, uint32_t> links;
void LinkBlocks(uint32_t from, uint32_t to){ links[from]=to; }
bool HasLink(uint32_t from, uint32_t& to){
    auto it=links.find(from); if(it==links.end()) return false; to=it->second; return true;
}
