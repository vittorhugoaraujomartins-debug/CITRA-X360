
#include "arm_state.hpp"
#include <cstdint>
extern bool HasLink(uint32_t, uint32_t&);
void FastExec(ARMState& s){
    uint32_t next;
    if(HasLink(s.pc, next)){ s.pc = next; }
}
