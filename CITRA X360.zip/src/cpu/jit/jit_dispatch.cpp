
#include "arm_state.hpp"
bool IsHot(uint32_t pc);
void FastExec(ARMState& s);
void Dispatch(ARMState& s){
    if(IsHot(s.pc)){
        FastExec(s);
    }
}
