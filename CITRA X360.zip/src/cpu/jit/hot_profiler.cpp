
#include <unordered_map>
#include <cstdint>
static std::unordered_map<uint32_t, uint32_t> hits;
bool IsHot(uint32_t pc){ return ++hits[pc] > 64; }
