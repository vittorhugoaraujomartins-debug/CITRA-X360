#pragma once
#include <cstdint>
#include <vector>

struct XenosVertex {
    float x, y, z, w;
    float u, v;
    uint32_t color;
};

class XenosBackendX360 {
public:
    void Init();

    void Clear(uint32_t color);

    void SubmitVertices(const std::vector<XenosVertex>& vtx);

    void DrawTriangles();

    // ligação com PICA decode
    void SubmitPicaCommand(uint32_t reg,
                           uint32_t value);

private:
    void ApplyState();
};