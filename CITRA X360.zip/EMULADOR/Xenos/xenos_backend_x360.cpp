#include "xenos_backend_x360.h"
#include <iostream>

void XenosBackendX360::Init() {
    std::cout << "[XENOS] Backend init\n";
}

void XenosBackendX360::Clear(uint32_t color) {
    // stub — aqui iria comando real do Xenos
}

void XenosBackendX360::SubmitVertices(
    const std::vector<XenosVertex>& vtx)
{
    // buffer upload stub
}

void XenosBackendX360::DrawTriangles() {
    ApplyState();
    // draw stub
}

void XenosBackendX360::SubmitPicaCommand(
    uint32_t reg,
    uint32_t value)
{
    // tradução PICA → Xenos futura
}

void XenosBackendX360::ApplyState() {
    // aplicar estados raster / blend / depth
}