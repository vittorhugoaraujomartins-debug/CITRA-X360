#include "ncsd_loader_x360.h"
#include "memory_system_x360.h"

#include <fstream>
#include <cstring>
#include <iostream>

static constexpr uint32_t NCSD_MAGIC = 0x4453434E; // "NCSD"
static constexpr uint32_t MEDIA_UNIT = 0x200;

NCSDLoaderX360::NCSDLoaderX360(MemorySystemX360& mem)
    : memory(mem) {}

bool NCSDLoaderX360::LoadCCI(const std::string& path)
{
    std::ifstream file(path, std::ios::binary);
    if (!file)
        return false;

    // ===== NCSD HEADER =====
    file.seekg(0x100);
    uint32_t magic;
    file.read(reinterpret_cast<char*>(&magic), 4);

    if (magic != NCSD_MAGIC) {
        std::cout << "NCSD magic inválido\n";
        return false;
    }

    // partition table
    file.seekg(0x120);
    NCSDPartitionEntry parts[8];
    file.read(reinterpret_cast<char*>(parts), sizeof(parts));

    // usar partição 0 (principal)
    if (parts[0].offset_units == 0)
        return false;

    uint64_t part_offset = uint64_t(parts[0].offset_units) * MEDIA_UNIT;

    return LoadExeFS(file, part_offset);
}

bool NCSDLoaderX360::LoadExeFS(std::ifstream& file, uint64_t part_offset)
{
    // NCCH → ExeFS offset @ 0x1A0
    file.seekg(part_offset + 0x1A0);

    uint32_t exefs_offset_units;
    file.read(reinterpret_cast<char*>(&exefs_offset_units), 4);

    if (!exefs_offset_units)
        return false;

    uint64_t exefs_offset =
        part_offset + uint64_t(exefs_offset_units) * MEDIA_UNIT;

    return LoadCodeFromExeFS(file, exefs_offset);
}

bool NCSDLoaderX360::LoadCodeFromExeFS(std::ifstream& file, uint64_t exefs_offset)
{
    file.seekg(exefs_offset);

    struct Entry {
        char name[8];
        uint32_t offset;
        uint32_t size;
    };

    Entry entries[10];
    file.read(reinterpret_cast<char*>(entries), sizeof(entries));

    for (auto& e : entries) {
        if (std::strncmp(e.name, ".code", 5) == 0) {

            std::vector<uint8_t> code(e.size);

            file.seekg(exefs_offset + e.offset);
            file.read(reinterpret_cast<char*>(code.data()), e.size);

            // endereço padrão app 3DS
            uint32_t load_addr = 0x00100000;

            memory.WriteBlock(load_addr, code.data(), code.size());

            entryPoint = load_addr;

            std::cout << "CODE carregado: "
                      << e.size << " bytes\n";

            return true;
        }
    }

    std::cout << ".code não encontrado\n";
    return false;
}