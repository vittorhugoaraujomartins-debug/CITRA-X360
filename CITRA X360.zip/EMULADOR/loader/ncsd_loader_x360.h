#pragma once
#include <cstdint>
#include <string>
#include <vector>

class MemorySystemX360;

struct NCSDPartitionEntry {
    uint32_t offset_units;
    uint32_t size_units;
};

class NCSDLoaderX360 {
public:
    explicit NCSDLoaderX360(MemorySystemX360& mem);

    bool LoadCCI(const std::string& path);

    uint32_t GetEntryPoint() const { return entryPoint; }

private:
    bool LoadExeFS(std::ifstream& file, uint64_t part_offset);
    bool LoadCodeFromExeFS(std::ifstream& file, uint64_t exefs_offset);

private:
    MemorySystemX360& memory;
    uint32_t entryPoint = 0;
};