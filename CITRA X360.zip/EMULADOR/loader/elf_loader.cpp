
#include "elf_loader.hpp"
#include <fstream>

struct ELFHeader {
    uint8_t magic[4];
    uint32_t entry;
};

bool ELFLoader::Load(const std::string& path, MMU& mmu, ARMState& state) {
    std::ifstream f(path, std::ios::binary);
    if(!f.good()) return false;

    ELFHeader hdr{};
    f.read((char*)&hdr, sizeof(hdr));
    if(hdr.magic[0] != 0x7F) return false;

    // naive load: load rest at 0x0
    uint32_t addr = 0;
    char byte;
    while(f.get(byte)) {
        mmu.Write8(addr++, (uint8_t)byte);
    }

    state.r[15] = hdr.entry;
    state.r[13] = 0x00FF0000; // simple stack
    return true;
}
