#pragma once

#include "XenosFramebuffer.hpp"
#include "XenosTypes.hpp"

class XenosBackend {
public:
    XenosBackend(int w, int h);

    void beginFrame();
    void endFrame();

    void drawTriangle(
        const XenosVertex& v0,
        const XenosVertex& v1,
        const XenosVertex& v2);

    XenosFramebuffer& framebuffer();

private:
    XenosFramebuffer fb;

    void rasterTriangle(
        const XenosVertex& a,
        const XenosVertex& b,
        const XenosVertex& c);
};