#include "xenos_backend_min.h"
#include <cstdio>

void XenosBackendMin::EmitALU(const std::string& op) {
    printf("[XENOS] ALU op: %s\n", op.c_str());
}