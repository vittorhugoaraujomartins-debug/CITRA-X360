#pragma once
#include <cstdint>

class XenosGPUBridgeX360 {
public:
    void SubmitCommand(uint32_t cmd);
    void DrawFakeTriangle();
};