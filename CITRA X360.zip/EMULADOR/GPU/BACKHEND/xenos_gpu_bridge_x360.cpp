#include "xenos_gpu_bridge_x360.h"
#include <cstdio>

void XenosGPUBridgeX360::SubmitCommand(
    uint32_t cmd)
{
    // stub command buffer
}

void XenosGPUBridgeX360::DrawFakeTriangle() {
    // placeholder — depois vira draw real
    printf("[XENOS] draw call\n");
}