#include "XenosBackend.hpp"
#include <algorithm>

XenosBackend::XenosBackend(int w, int h)
    : fb(w, h) {}

void XenosBackend::beginFrame() {
    fb.clear(0x00000000);
}

void XenosBackend::endFrame() {
    // aqui depois entra Xe_Resolve / swap buffer real
}

XenosFramebuffer& XenosBackend::framebuffer() {
    return fb;
}

static float edge(float ax, float ay, float bx, float by, float cx, float cy) {
    return (cx-ax)*(by-ay) - (cy-ay)*(bx-ax);
}

void XenosBackend::drawTriangle(
    const XenosVertex& v0,
    const XenosVertex& v1,
    const XenosVertex& v2)
{
    rasterTriangle(v0, v1, v2);
}

void XenosBackend::rasterTriangle(
    const XenosVertex& a,
    const XenosVertex& b,
    const XenosVertex& c)
{
    int minX = std::max(0, (int)std::floor(std::min({a.x,b.x,c.x})));
    int maxX = std::min(fb.width()-1, (int)std::ceil(std::max({a.x,b.x,c.x})));

    int minY = std::max(0, (int)std::floor(std::min({a.y,b.y,c.y})));
    int maxY = std::min(fb.height()-1, (int)std::ceil(std::max({a.y,b.y,c.y})));

    float area = edge(a.x,a.y, b.x,b.y, c.x,c.y);
    if (area == 0) return;

    for (int y=minY; y<=maxY; y++) {
        for (int x=minX; x<=maxX; x++) {
            float w0 = edge(b.x,b.y, c.x,c.y, x,y);
            float w1 = edge(c.x,c.y, a.x,a.y, x,y);
            float w2 = edge(a.x,a.y, b.x,b.y, x,y);

            if (w0>=0 && w1>=0 && w2>=0) {
                fb.setPixel(x, y, a.color);
            }
        }
    }
}