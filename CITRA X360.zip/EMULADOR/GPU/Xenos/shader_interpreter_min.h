#pragma once
#include <cstdint>
#include <vector>

struct ShaderInstrMin {
    uint32_t raw;
};

class ShaderInterpreterMin {
public:
    void Load(const std::vector<uint32_t>& code);
    void Run();

private:
    std::vector<ShaderInstrMin> program;

    void Exec(uint32_t instr);
};