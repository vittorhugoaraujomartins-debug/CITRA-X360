#include "shader_interpreter_min.h"
#include "xenos_backend_min.h"
#include <cstdio>

void ShaderInterpreterMin::Load(const std::vector<uint32_t>& code) {
    program.clear();
    for (auto v : code) {
        program.push_back({v});
    }
}

void ShaderInterpreterMin::Run() {
    for (auto& i : program) {
        Exec(i.raw);
    }
}

void ShaderInterpreterMin::Exec(uint32_t instr) {
    uint8_t op = instr & 0xFF;

    switch (op) {

    case 0x01: // ADD
        XenosBackendMin::EmitALU("ADD");
        break;

    case 0x02: // MUL
        XenosBackendMin::EmitALU("MUL");
        break;

    case 0x03: // MOV
        XenosBackendMin::EmitALU("MOV");
        break;

    default:
        printf("Shader opcode desconhecido %02X\n", op);
        break;
    }
}