#pragma once
#include <cstdint>

struct XenosVertex {
    float x, y, z, w;
    float u, v;
    uint32_t color;
};

enum class XenosPrimitive {
    Triangles,
    Lines
};