#include "engine.h"

// Core
#include "../system.h"

// JIT / Banco
#include "../jit/double_block_cache.h"
#include "../jit/ppc_native_bank.h"

// Scheduler
#include "../sched/job_system.h"

// Vídeo
#include "../../video/state_cache.h"

void Engine_Init() {
    // JIT / tradução
    DBC_Init();
    PPCBank_Init();

    // Scheduler (jobs assíncronos)
    Jobs_Init(256);

    // Cache de estados da GPU
    StateCache_Init();

    // Sistema principal (CPU, memória, etc)
    System_Init();
}

void Engine_RunFrame() {
    // Executa CPU + JIT + emulação principal
    System_RunFrame();

    // Executa jobs pendentes (GPU prep, async, etc)
    Jobs_RunAll();
}

void Engine_Shutdown() {
    System_Shutdown();
}