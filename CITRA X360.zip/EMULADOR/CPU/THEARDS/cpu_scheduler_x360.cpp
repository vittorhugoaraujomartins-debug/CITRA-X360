#include "cpu_scheduler_x360.h"

void CPUSchedulerX360::AddThread(
    KernelThreadX360* t)
{
    threads.push_back(t);
}

void CPUSchedulerX360::RunSlice() {
    if (threads.empty())
        return;

    threads[index]->RunCycles(2000);

    index++;
    if (index >= threads.size())
        index = 0;
}