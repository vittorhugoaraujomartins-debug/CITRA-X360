#pragma once
#include <vector>
#include "kernel_thread_x360.h"

class CPUSchedulerX360 {
public:
    void AddThread(KernelThreadX360* t);
    void RunSlice();

private:
    std::vector<KernelThreadX360*> threads;
    int index = 0;
};