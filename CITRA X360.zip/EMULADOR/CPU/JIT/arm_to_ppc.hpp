#pragma once
#include <string>
#include "arm_decoder_real.hpp"

std::string armToPPC(const ArmInstr& a);