#pragma once
#include <thread>
#include <vector>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <functional>

class X360ThreadPool {
public:
    X360ThreadPool();
    ~X360ThreadPool();

    void submit(std::function<void()> job);

private:
    std::vector<std::thread> workers;
    std::queue<std::function<void()>> jobs;

    std::mutex m;
    std::condition_variable cv;
    bool stop = false;

    void worker();
};