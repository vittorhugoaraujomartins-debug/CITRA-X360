#pragma once
#include <cstdint>
#include "arm_state_x360.h"
#include "memory_manager_x360.h"

class ARMInterpreterX360 {
public:
    ARMInterpreterX360(ARMStateX360& s,
                       MemoryManagerX360& m);

    void Step();
    void Run(uint32_t cycles);

private:
    ARMStateX360& cpu;
    MemoryManagerX360& mem;

    void ExecDataProc(uint32_t op);
    void ExecLoadStore(uint32_t op);
    void ExecBranch(uint32_t op);
};