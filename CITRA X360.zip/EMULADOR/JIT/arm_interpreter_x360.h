#pragma once
#include <cstdint>
#include "arm_state_x360.h"
#include "memory_system_x360.h"

class ARMInterpreterX360 {
public:
    ARMInterpreterX360(ARMStateX360& cpu,
                       MemorySystemX360& mem);

    // executa 1 instrução
    void Step();

    // loop simples
    void Run(uint32_t cycles);

private:
    ARMStateX360& cpu;
    MemorySystemX360& memory;

    uint32_t Fetch32(uint32_t addr);

    void DecodeExecute(uint32_t opcode);

    // grupos iniciais
    void ExecDataProc(uint32_t op);
    void ExecLoadStore(uint32_t op);
    void ExecBranch(uint32_t op);
};