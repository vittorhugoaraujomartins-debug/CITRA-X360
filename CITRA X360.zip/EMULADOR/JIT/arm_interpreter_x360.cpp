#include "arm_interpreter_x360.h"

ARMInterpreterX360::ARMInterpreterX360(
    ARMStateX360& c,
    MemorySystemX360& m)
    : cpu(c), memory(m) {}

uint32_t ARMInterpreterX360::Fetch32(uint32_t addr) {
    return memory.Read32(addr);
}

void ARMInterpreterX360::Run(uint32_t cycles) {
    while (cycles--) {
        Step();
    }
}

void ARMInterpreterX360::Step() {
    uint32_t pc = cpu.R[15];
    uint32_t opcode = Fetch32(pc);

    cpu.R[15] += 4;

    DecodeExecute(opcode);
}

void ARMInterpreterX360::DecodeExecute(uint32_t op) {
    uint32_t type = (op >> 25) & 0x7;

    switch (type) {
    case 0b000:
    case 0b001:
        ExecDataProc(op);
        break;

    case 0b010:
    case 0b011:
        ExecLoadStore(op);
        break;

    case 0b101:
        ExecBranch(op);
        break;

    default:
        // stub — instrução não implementada
        break;
    }
}

void ARMInterpreterX360::ExecDataProc(uint32_t op) {
    uint32_t opcode = (op >> 21) & 0xF;
    uint32_t rn = (op >> 16) & 0xF;
    uint32_t rd = (op >> 12) & 0xF;
    uint32_t imm = op & 0xFFF;

    switch (opcode) {
    case 0xD: // MOV
        cpu.R[rd] = imm;
        break;

    case 0x4: // ADD
        cpu.R[rd] = cpu.R[rn] + imm;
        break;

    case 0x2: // SUB
        cpu.R[rd] = cpu.R[rn] - imm;
        break;

    default:
        break;
    }
}

void ARMInterpreterX360::ExecLoadStore(uint32_t op) {
    bool load = (op >> 20) & 1;
    uint32_t rn = (op >> 16) & 0xF;
    uint32_t rd = (op >> 12) & 0xF;
    uint32_t off = op & 0xFFF;

    uint32_t addr = cpu.R[rn] + off;

    if (load)
        cpu.R[rd] = memory.Read32(addr);
    else
        memory.Write32(addr, cpu.R[rd]);
}

void ARMInterpreterX360::ExecBranch(uint32_t op) {
    int32_t off = op & 0x00FFFFFF;

    if (off & 0x00800000)
        off |= 0xFF000000;

    off <<= 2;

    cpu.R[15] += off;
}