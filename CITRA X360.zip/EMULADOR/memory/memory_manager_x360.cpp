#include "memory_manager_x360.h"

MemoryManagerX360::MemoryManagerX360() {
    for (int i = 0; i < BLOCK_COUNT; i++) {
        blocks[i].resize(BLOCK_SIZE);
    }
}

uint8_t* MemoryManagerX360::Translate(uint32_t addr) {
    uint32_t block = addr / BLOCK_SIZE;
    uint32_t off   = addr % BLOCK_SIZE;

    if (block >= BLOCK_COUNT)
        return nullptr;

    return &blocks[block][off];
}

uint32_t MemoryManagerX360::Read32(uint32_t addr) {
    uint8_t* p = Translate(addr);
    if (!p) return 0;
    return *(uint32_t*)p;
}

void MemoryManagerX360::Write32(uint32_t addr, uint32_t v) {
    uint8_t* p = Translate(addr);
    if (!p) return;
    *(uint32_t*)p = v;
}

void WriteBlock(uint32_t addr,
                const uint8_t* data,
                size_t size);