#pragma once
#include <cstdint>
#include <vector>

class MemoryManagerX360 {
public:
    static constexpr uint32_t BLOCK_SIZE = 128 * 1024 * 1024;
    static constexpr uint32_t BLOCK_COUNT = 4;

    MemoryManagerX360();

    uint8_t* Translate(uint32_t addr);

    uint32_t Read32(uint32_t addr);
    void Write32(uint32_t addr, uint32_t v);

private:
    std::vector<uint8_t> blocks[BLOCK_COUNT];
};