
#pragma once
#include <thread>
#include <atomic>

class Scheduler {
public:
    void Init();
    void Shutdown();
private:
    std::thread workers[4];
    std::atomic<bool> running;
    void WorkerFixed(int id);
    void WorkerFlexible();
};
