#pragma once
#define GHOSTCORE_FASTPATH 1
