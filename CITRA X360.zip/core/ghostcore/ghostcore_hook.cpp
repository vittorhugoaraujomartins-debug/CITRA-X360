extern void Ghostcore_Run();
void Emulator_RunGhostcore(){ Ghostcore_Run(); }
