#include <vector>
#include <cstdint>

struct GhostJob {
    void (*fn)(void*);
    void* data;
};

static std::vector<GhostJob> jobQueue;

void Ghostcore_Push(void(*fn)(void*), void* data){
    jobQueue.push_back({fn,data});
}

void Ghostcore_Run(){
    for(size_t i=0;i<jobQueue.size();++i){
        jobQueue[i].fn(jobQueue[i].data);
    }
    jobQueue.clear();
}
