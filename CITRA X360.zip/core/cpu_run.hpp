
#pragma once
#include "../cpu/arm11/arm_jit.hpp"
#include "../memory/mmu.hpp"

class CPURun {
public:
    void Run(ARMState& state, MMU& mmu);
};
