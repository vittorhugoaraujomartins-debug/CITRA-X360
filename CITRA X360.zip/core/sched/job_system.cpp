#include "job_system.h"
#include <vector>
#include <mutex>

struct Job{ job_fn_t fn; void* arg; int affinity; };
static std::vector<Job> g_jobs;
static std::mutex g_jobs_lock;

void Jobs_Init(size_t maxJobs){ g_jobs.reserve(maxJobs); }
int Jobs_Push(job_fn_t fn, void* arg, int affinityHint){ std::lock_guard<std::mutex> lk(g_jobs_lock); g_jobs.push_back({fn,arg,affinityHint}); return (int)g_jobs.size()-1; }
void Jobs_RunAll(){ std::vector<Job> local; { std::lock_guard<std::mutex> lk(g_jobs_lock); local.swap(g_jobs); } for(auto &j: local) j.fn(j.arg); }
