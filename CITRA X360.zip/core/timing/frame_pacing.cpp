#include <chrono>
void FrameLimit(double ms){
    static auto last=std::chrono::high_resolution_clock::now();
    auto now=std::chrono::high_resolution_clock::now();
    double dt=std::chrono::duration<double,std::milli>(now-last).count();
    if(dt<ms){ /* sleep */ }
    last=now;
}
