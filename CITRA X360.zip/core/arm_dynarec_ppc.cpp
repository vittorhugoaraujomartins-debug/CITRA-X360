#include "arm_dynarec_ppc.h"
#include "arm_block_decoder.h"
void ExecuteArmBlock(u32 pc){ ArmBlock b = DecodeArmBlock(pc); }
