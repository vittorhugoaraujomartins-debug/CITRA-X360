#pragma once
#include <xtl.h>
typedef unsigned int u32;
void ExecuteArmBlock(u32 pc);
