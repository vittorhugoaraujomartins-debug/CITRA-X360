#pragma once
#define EMU_RELEASE 1
#define DISABLE_LOGS 1
