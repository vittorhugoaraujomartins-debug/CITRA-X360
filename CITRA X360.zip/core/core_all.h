#pragma once
// Unified core interface
void Core_Init();
void Core_RunFrame();
void Core_RunGhostcore();
