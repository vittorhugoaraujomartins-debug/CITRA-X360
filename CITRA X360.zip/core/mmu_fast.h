#pragma once
#include <cstdint>

extern uint8_t* g_mem;

static inline uint32_t MMU_Read32(uint32_t addr){
    return *(uint32_t*)(g_mem + (addr & 0x1FFFFFF));
}

static inline void MMU_Write32(uint32_t addr, uint32_t v){
    *(uint32_t*)(g_mem + (addr & 0x1FFFFFF)) = v;
}
