#include "core_all.h"
#include "../video/video_all.h"

void Core_Init(){
    Video_Init();
}

void Core_RunFrame(){
    Video_BeginFrame();
    // emulation step
    Video_EndFrame();
}

void Core_RunGhostcore(){}
