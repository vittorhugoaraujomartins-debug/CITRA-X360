#include "jit/block_cache.h"
#include <cstdint>

extern BlockCache g_cache;
extern uint32_t g_pc;

void CpuRunFast(){
    while(true){
        JitBlock* b = g_cache.Get(g_pc);
        if(!b) break;
        using Fn = uint32_t(*)();
        g_pc = ((Fn)b->ppc_entry)();
    }
}
