#pragma once
#include <cstdint>
uint32_t ARMHash(const uint32_t* code, uint32_t words);
