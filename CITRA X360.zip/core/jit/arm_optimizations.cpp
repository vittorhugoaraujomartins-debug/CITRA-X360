#include "ir.h"
#include <vector>

void OptimizeIR(std::vector<IRInstr>& ir){
    for(size_t i=0;i+1<ir.size();++i){
        if(ir[i].op==IROp::CMP && ir[i+1].op==IROp::B){
            // Mark branch as folded (no flags materialization)
            ir[i].op = IROp::NOP;
        }
    }
}
