#pragma once
#include <cstdint>
#include <unordered_map>

struct JitBlock {
    uint32_t arm_pc;
    void* ppc_entry;
    uint32_t exit_pc[2];
};

class BlockCache {
public:
    JitBlock* Get(uint32_t pc){
        auto it = map.find(pc);
        return it==map.end()? nullptr : &it->second;
    }
    void Put(uint32_t pc, JitBlock&& b){ map.emplace(pc, b); }
private:
    std::unordered_map<uint32_t, JitBlock> map;
};
