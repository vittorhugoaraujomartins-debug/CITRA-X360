#include "double_block_cache.h"
#include <atomic>

static SuperBlock g_slot0 = {0,nullptr,0};
static SuperBlock g_slot1 = {0,nullptr,0};
static std::atomic<uint32_t> g_gen{1};

void DBC_Init(){ g_slot0.pc=g_slot1.pc=0; g_slot0.entry=g_slot1.entry=nullptr; g_slot0.generation=g_slot1.generation=0; }
void DBC_Put(uint32_t pc, void* entry){ uint32_t gen = g_gen.fetch_add(1, std::memory_order_relaxed); if(g_slot0.generation <= g_slot1.generation){ g_slot0.pc=pc; g_slot0.entry=entry; g_slot0.generation=gen; } else { g_slot1.pc=pc; g_slot1.entry=entry; g_slot1.generation=gen; } }
void* DBC_Get(uint32_t pc){ if(g_slot0.pc==pc) return g_slot0.entry; if(g_slot1.pc==pc) return g_slot1.entry; return nullptr; }
