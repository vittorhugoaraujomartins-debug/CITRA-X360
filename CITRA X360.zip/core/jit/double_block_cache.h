#pragma once
#include <cstdint>
#include <atomic>

struct SuperBlock { uint32_t pc; void* entry; uint32_t generation; };
void DBC_Init();
void DBC_Put(uint32_t pc, void* entry);
void* DBC_Get(uint32_t pc);
