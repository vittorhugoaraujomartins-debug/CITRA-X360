#pragma once
#include <cstdint>
#include <vector>

struct PPCEmitter {
    std::vector<uint32_t> code;
    void Emit(uint32_t v){ code.push_back(v); }
    // rD, rA, rB already mapped
    void ADD(uint8_t d, uint8_t a, uint8_t b){
        Emit(0x7C000214 | (d<<21) | (a<<16) | (b<<11));
    }
    void SUB(uint8_t d, uint8_t a, uint8_t b){
        Emit(0x7C000050 | (d<<21) | (a<<16) | (b<<11));
    }
    void MOV(uint8_t d, uint8_t a){
        Emit(0x7C000378 | (d<<21) | (a<<16));
    }
};
