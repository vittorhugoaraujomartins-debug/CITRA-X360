#pragma once
#include <cstdint>
struct PPCNativeEntry { uint32_t arm_hash; void* ppc_entry; };
void PPCBank_Init();
void PPCBank_Insert(uint32_t arm_hash, void* ppc_entry);
void* PPCBank_Find(uint32_t arm_hash);
