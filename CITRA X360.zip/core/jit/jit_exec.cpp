#include "double_block_cache.h"
#include <cstdint>

extern "C" void ExecuteCompiledBlock(void* entry);

void JIT_Execute(uint32_t pc){
    void* block = DBC_Get(pc);
    if(block){
        ExecuteCompiledBlock(block);
    }
    // fallback interpreter would be called here if null
}
