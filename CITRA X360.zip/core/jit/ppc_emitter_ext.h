#pragma once
#include <cstdint>
#include <vector>

struct PPCEmitterExt {
    std::vector<uint32_t> code;
    void Emit(uint32_t v){ code.push_back(v); }

    void ADD(uint8_t d, uint8_t a, uint8_t b){
        Emit(0x7C000214 | (d<<21) | (a<<16) | (b<<11));
    }
    void B(uint32_t target){
        Emit(0x48000000 | (target & 0x03FFFFFC));
    }
    void LWZ(uint8_t d, uint16_t off, uint8_t a){
        Emit(0x80000000 | (d<<21) | (a<<16) | off);
    }
    void STW(uint8_t s, uint16_t off, uint8_t a){
        Emit(0x90000000 | (s<<21) | (a<<16) | off);
    }
};
