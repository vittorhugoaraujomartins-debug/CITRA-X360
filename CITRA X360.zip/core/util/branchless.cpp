inline float Clamp01(float v){
    return v < 0.f ? 0.f : (v > 1.f ? 1.f : v);
}
