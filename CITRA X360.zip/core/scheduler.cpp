
#include "scheduler.hpp"

void Scheduler::Init() {
    running = true;
    workers[0] = std::thread(&Scheduler::WorkerFixed, this, 0);
    workers[1] = std::thread(&Scheduler::WorkerFixed, this, 1);
    workers[2] = std::thread(&Scheduler::WorkerFixed, this, 2);
    workers[3] = std::thread(&Scheduler::WorkerFlexible, this);
}

void Scheduler::Shutdown() {
    running = false;
    for(auto& w : workers) if(w.joinable()) w.join();
}

void Scheduler::WorkerFixed(int) {
    while(running) { }
}

void Scheduler::WorkerFlexible() {
    while(running) { }
}
