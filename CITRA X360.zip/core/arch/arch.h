#pragma once
void Arch_Init();
void Arch_RunFrame();
