#include "arch.h"
#include "../core_all.h"
#include "../jit/jit_all.h"

void Arch_Init(){
    Core_Init();
    JIT_Init();
}

void Arch_RunFrame(){
    JIT_Run();
    Core_RunFrame();
}
