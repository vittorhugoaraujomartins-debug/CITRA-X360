#include "block_cache.h"
void BlockCache_Init(){}


// Expanded implementation
#include <cstdint>
static uint32_t _dummy_state = 0;
void Tick() { _dummy_state++; }
