#include <cstdint>

static uint32_t g_cycles = 0;

inline void CpuRunBatch(uint32_t cycles){
    g_cycles += cycles;
    // events processed only every batch
}
