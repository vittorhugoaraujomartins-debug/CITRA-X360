#pragma once
#include <xtl.h>
void BlockCache_Init();
