#include <vector>
struct Agent { float x,y,vx,vy; };
void UpdateCollectiveAI(std::vector<Agent>& agents){
    float cx=0,cy=0;
    for(auto&a:agents){cx+=a.x;cy+=a.y;}
    cx/=agents.size();cy/=agents.size();
    for(auto&a:agents){
        a.vx+=(cx-a.x)*0.01f;
        a.vy+=(cy-a.y)*0.01f;
        a.x+=a.vx; a.y+=a.vy;
    }
}
