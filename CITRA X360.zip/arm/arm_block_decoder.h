#pragma once
#include <xtl.h>
typedef unsigned int u32;
struct ArmBlock { u32 pc; };
ArmBlock DecodeArmBlock(u32 pc);
