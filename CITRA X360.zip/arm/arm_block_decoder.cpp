#include "arm_block_decoder.h"
ArmBlock DecodeArmBlock(u32 pc){ ArmBlock b; b.pc=pc; return b; }


// Expanded implementation
#include <cstdint>
static uint32_t _dummy_state = 0;
void Tick() { _dummy_state++; }
