
#include "arm_decoder.hpp"

ARMOpcode DecodeARM(uint32_t instr) {
    if((instr & 0x0FE00000) == 0x00800000) return OP_ADD;
    if((instr & 0x0FE00000) == 0x00400000) return OP_SUB;
    if((instr & 0x0FF00000) == 0x01A00000) return OP_MOV;
    if((instr & 0x0F000000) == 0x0A000000) return OP_B;
    return OP_NOP;
}
