
#include "arm_jit.hpp"
#include "arm_decoder.hpp"

void ARMJIT::ExecuteBlock(ARMState& state, uint32_t* code, int count) {
    for(int i=0;i<count;i++) {
        ARMOpcode op = DecodeARM(code[i]);
        switch(op) {
            case OP_ADD: state.r[0] += state.r[1]; break;
            case OP_SUB: state.r[0] -= state.r[1]; break;
            case OP_MOV: state.r[0] = state.r[1]; break;
            case OP_B: state.r[15] += 4; break;
            default: break;
        }
    }
}
