#include <unordered_map>
#include <vector>
#include <cstdint>
#include "arm_state.hpp"

uint32_t Read32(uint32_t addr);
void Execute(uint32_t instr, ARMState& s);

struct ARMBlock {
    uint32_t start_pc;
    std::vector<uint32_t> instrs;
};

static std::unordered_map<uint32_t, ARMBlock> g_blockCache;

ARMBlock& BuildBlock(uint32_t pc, uint32_t maxInstr=16) {
    ARMBlock blk;
    blk.start_pc = pc;
    for (uint32_t i=0;i<maxInstr;i++) {
        uint32_t instr = Read32(pc + i*4);
        blk.instrs.push_back(instr);
        if ((instr & 0x0E000000) == 0x0A000000) break; // stop on branch
    }
    auto it = g_blockCache.emplace(pc, blk).first;
    return it->second;
}

void ExecuteBlockCached(ARMState& s) {
    uint32_t pc = s.r[15];
    ARMBlock* blk;
    auto it = g_blockCache.find(pc);
    if (it == g_blockCache.end()) {
        blk = &BuildBlock(pc);
    } else {
        blk = &it->second;
    }
    for (auto instr : blk->instrs) {
        s.r[15] += 4;
        Execute(instr, s);
    }
}
