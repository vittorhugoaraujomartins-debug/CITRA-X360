#include <cstdint>

enum ARMOpcode {
    OP_MOV, OP_ADD, OP_SUB, OP_CMP, OP_B, OP_BL, OP_LDR, OP_STR, OP_UNKNOWN
};

ARMOpcode Decode(uint32_t instr) {
    if ((instr & 0x0FE00000) == 0x01A00000) return OP_MOV;
    if ((instr & 0x0FE00000) == 0x00800000) return OP_ADD;
    if ((instr & 0x0FE00000) == 0x00400000) return OP_SUB;
    if ((instr & 0x0FE00000) == 0x01500000) return OP_CMP;
    if ((instr & 0x0E000000) == 0x0A000000) return OP_B;
    if ((instr & 0x0F000000) == 0x0B000000) return OP_BL;
    // LDR/STR word, immediate
    if ((instr & 0x0C100000) == 0x04100000) return OP_LDR;
    if ((instr & 0x0C100000) == 0x04000000) return OP_STR;
    return OP_UNKNOWN;
}
