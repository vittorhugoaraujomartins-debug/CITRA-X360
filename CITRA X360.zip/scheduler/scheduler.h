#pragma once
void Scheduler_Init();
void Scheduler_Tick();
