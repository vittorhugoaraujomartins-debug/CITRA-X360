#include <unordered_map>
#include <cstdint>
static std::unordered_map<uint32_t,uint32_t> page_cache;
uint32_t Translate(uint32_t v){
    auto it=page_cache.find(v>>12);
    if(it!=page_cache.end()) return (it->second<<12)|(v&0xFFF);
    return v;
}
