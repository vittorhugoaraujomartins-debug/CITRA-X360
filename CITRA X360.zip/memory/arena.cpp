#include <cstdint>
static uint8_t* arena=nullptr;
static size_t size=0, offset=0;
void ArenaInit(void* mem, size_t sz){ arena=(uint8_t*)mem; size=sz; offset=0; }
void* ArenaAlloc(size_t sz){
    if(offset+sz>size) return nullptr;
    void* p=arena+offset;
    offset+=(sz+15)&~15;
    return p;
}
