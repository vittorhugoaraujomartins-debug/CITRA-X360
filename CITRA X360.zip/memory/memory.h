#pragma once
#include <xtl.h>
void Memory_Init();
unsigned int* Memory_GetARM();
