#include <vector>
static std::vector<void*> ro_assets;
void RegisterRO(void* p){ ro_assets.push_back(p); }
