#pragma once
#include <xtl.h>
void Memory_Init();
