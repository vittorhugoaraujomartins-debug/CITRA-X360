#include "memory.h"
static unsigned int* g_arm_mem = 0;
void Memory_Init(){ g_arm_mem = (unsigned int*)XPhysicalAlloc(64*1024*1024, MAXULONG_PTR, 0, PAGE_READWRITE); }
unsigned int* Memory_GetARM(){ return g_arm_mem; }
