
#include <xtl.h>
#include <xgraphics.h>

extern "C" uint32_t MMU_Read32(uint32_t addr);

static IDirect3D9* g_d3d = NULL;
static IDirect3DDevice9* g_dev = NULL;

void GPU_Init() {
    g_d3d = Direct3DCreate9(D3D_SDK_VERSION);
    D3DPRESENT_PARAMETERS pp = {};
    pp.BackBufferWidth = 1280;
    pp.BackBufferHeight = 720;
    pp.BackBufferFormat = D3DFMT_X8R8G8B8;
    pp.BackBufferCount = 1;
    pp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    g_d3d->CreateDevice(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,NULL,
        D3DCREATE_HARDWARE_VERTEXPROCESSING,&pp,&g_dev);
}

void GPU_Frame() {
    uint32_t v = MMU_Read32(0x10000000);
    int r = (v >> 16) & 0xFF;
    int g = (v >> 8) & 0xFF;
    int b = v & 0xFF;

    g_dev->Clear(0,NULL,D3DCLEAR_TARGET,D3DCOLOR_XRGB(r,g,b),1.0f,0);
    g_dev->BeginScene();
    g_dev->EndScene();
    g_dev->Present(NULL,NULL,NULL,NULL);
}
