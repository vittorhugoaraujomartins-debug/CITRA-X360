
#pragma once
#include "culling.hpp"
#include "instancing.hpp"

class RendererDX9 {
public:
    void SubmitDraw(const AABB& bounds, uint32_t mesh, uint32_t material);
    void Flush();
private:
    Frustum frustum;
    OcclusionCuller occlusion;
};
