
#include "renderer.hpp"

void RendererDX9::SubmitDraw(const AABB& bounds, uint32_t mesh, uint32_t material) {
    if(!frustum.TestAABB(bounds)) return;
    if(occlusion.IsOccluded(bounds)) return;
    // batch / instancing path
}

void RendererDX9::Flush() {
    // issue instanced or normal draws
}
