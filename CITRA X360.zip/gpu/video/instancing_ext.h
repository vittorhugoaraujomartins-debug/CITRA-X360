#pragma once
#include <cstdint>
void Instancing_Init(size_t maxInstances);
int Instancing_RegisterInstanceBuffer(uint32_t meshId, size_t instanceSize);
void Instancing_UpdateBuffer(int id, const void* data, size_t bytes);
void Instancing_Draw(int id, uint32_t count);
