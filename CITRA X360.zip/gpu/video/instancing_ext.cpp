#include "instancing_ext.h"
#include <vector>
#include <mutex>
#include <cstring>

struct InstBuf{ uint32_t mesh; std::vector<uint8_t> data; };
static std::vector<InstBuf> g_inst;
static std::mutex g_inst_lock;

void Instancing_Init(size_t maxInstances){ g_inst.reserve(maxInstances); }
int Instancing_RegisterInstanceBuffer(uint32_t meshId, size_t instanceSize){ std::lock_guard<std::mutex> lk(g_inst_lock); g_inst.push_back({meshId, std::vector<uint8_t>(instanceSize)}); return (int)g_inst.size()-1; }
void Instancing_UpdateBuffer(int id, const void* data, size_t bytes){ if(id<0 || (size_t)id>=g_inst.size()) return; std::lock_guard<std::mutex> lk(g_inst_lock); g_inst[id].data.resize(bytes); memcpy(g_inst[id].data.data(), data, bytes); }
void Instancing_Draw(int id, uint32_t count){ if(id<0 || (size_t)id>=g_inst.size()) return; (void)count; }
