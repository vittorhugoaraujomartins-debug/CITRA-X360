#include <cstdint>

static uint64_t g_gpuCycles = 0;

void GPU_AddCycles(uint32_t cycles){
    g_gpuCycles += cycles;
}

uint64_t GPU_GetCycles(){
    return g_gpuCycles;
}

void GPU_ResetCycles(){
    g_gpuCycles = 0;
}
