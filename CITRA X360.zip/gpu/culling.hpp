
#pragma once
#include <vector>

struct Vec3 { float x,y,z; };
struct AABB { Vec3 min,max; };

class Frustum {
public:
    float planes[6][4];
    bool TestAABB(const AABB& box) const;
};

class OcclusionCuller {
public:
    bool IsOccluded(const AABB& box);
};

