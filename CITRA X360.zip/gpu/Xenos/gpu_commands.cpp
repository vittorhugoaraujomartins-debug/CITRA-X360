#include "gpu_commands.h"
#include "gpu_core.h"
void GPU_Translate3DSCommand(u32 cmd, u32* params){
 // Basic command translation stub
 switch(cmd){
  case 0x01: /* draw */ GPU_SubmitCommand(cmd); break;
  default: break; }
}
