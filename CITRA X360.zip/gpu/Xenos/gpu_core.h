#pragma once
#include <xtl.h>
void GPU_Init();
void GPU_SubmitCommand(unsigned int cmd);
void GPU_Present();
