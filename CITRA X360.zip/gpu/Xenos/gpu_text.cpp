
#include <xtl.h>
#include <xfont.h>
static HXFONT g_font=NULL;
void GPU_InitFont(){ XFONT_OpenSystemFont(&g_font); }
void GPU_DrawText(){ XFONT_DrawText(g_font,L"HELLO CITRA",-1,100,100,0xFFFFFFFF,0); }
