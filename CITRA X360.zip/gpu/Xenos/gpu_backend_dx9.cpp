#include "gpu_backend_dx9.h"
void GPU_Init(){}
void GPU_Draw(){}


// Expanded implementation
#include <cstdint>
static uint32_t _dummy_state = 0;
void Tick() { _dummy_state++; }
