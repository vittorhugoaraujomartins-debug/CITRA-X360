#include "gpu_core.h"
#include "gpu_commands.h"
#include <d3d9.h>
static IDirect3DDevice9* g_dev=0;
void GPU_Init(){}
void GPU_SubmitCommand(unsigned int cmd){ /* translated draw */ }
void GPU_Present(){ if(g_dev) g_dev->Present(0,0,0,0); }
