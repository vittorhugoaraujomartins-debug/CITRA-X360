#pragma once
#include <xtl.h>
void GPU_Translate3DSCommand(u32 cmd, u32* params);
