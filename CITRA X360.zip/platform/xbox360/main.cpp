#include <xtl.h>
#include <xboxkrnl/xboxkrnl.h>
#include "core/emulator.h"
#include "video/prerender/scene_cache.h"

void __cdecl main(){
    XVideoSetMode(1280,720,32,REFRESH_60HZ);
    Emulator_Init();
    // Loading screen prerender (20s budget)
    SceneKey key{0xDEADBEEF,1280,720};
    PrerenderScene(key, 20000);
    while(true){
        Emulator_RunFrame();
        XSleep(1);
    }
}
