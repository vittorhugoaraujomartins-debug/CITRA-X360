#include <d3d9.h>

extern IDirect3DDevice9* g_dev;

static UINT batched = 0;

void GPU_DrawBatched(){
    if(batched){
        g_dev->DrawPrimitive(D3DPT_TRIANGLELIST, 0, batched);
        batched = 0;
    }
}

void GPU_QueueDraw(UINT prim){
    batched += prim;
    if(batched > 1024)
        GPU_DrawBatched();
}
