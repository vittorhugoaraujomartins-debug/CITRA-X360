#include "state_cache.h"
#include <vector>
#include <mutex>
#include <algorithm>
static std::vector<uint32_t> g_textures;
static uint32_t g_shader = 0xFFFFFFFF;
static std::mutex g_state_lock;
void StateCache_Init(){ std::lock_guard<std::mutex> lk(g_state_lock); g_textures.assign(8,0xFFFFFFFF); g_shader = 0xFFFFFFFF; }
void StateCache_SetTexture(uint32_t slot, uint32_t texId){ std::lock_guard<std::mutex> lk(g_state_lock); if(slot>=g_textures.size()) return; if(g_textures[slot]==texId) return; g_textures[slot]=texId; }
void StateCache_SetShader(uint32_t shaderId){ std::lock_guard<std::mutex> lk(g_state_lock); if(g_shader==shaderId) return; g_shader=shaderId; }
void StateCache_FlushAll(){ std::lock_guard<std::mutex> lk(g_state_lock); std::fill(g_textures.begin(), g_textures.end(), 0xFFFFFFFF); g_shader = 0xFFFFFFFF; }
