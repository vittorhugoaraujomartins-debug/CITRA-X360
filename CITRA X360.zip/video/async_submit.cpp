#include <queue>
struct Cmd{};
static std::queue<Cmd> q;
void Enqueue(const Cmd& c){ q.push(c); }
void Submit(){
    while(!q.empty()){ /* submit to GPU */ q.pop(); }
}
