#include <cstdint>
#include <stdexcept>

uint32_t ResolveTexture(uint32_t tex_id){
    // All textures must belong to an atlas
    if(tex_id >= 5)
        throw std::runtime_error("Invalid atlas access");
    return tex_id;
}
