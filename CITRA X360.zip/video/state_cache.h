#pragma once
#include <cstdint>
void StateCache_Init();
void StateCache_SetTexture(uint32_t slot, uint32_t texId);
void StateCache_SetShader(uint32_t shaderId);
void StateCache_FlushAll();
