static float scale=1.0f;
void UpdateDynRes(float gpu_ms){
    if(gpu_ms>16.7f) scale*=0.95f;
    else if(gpu_ms<14.0f) scale*=1.02f;
    if(scale<0.7f) scale=0.7f;
    if(scale>1.0f) scale=1.0f;
}
float GetScale(){return scale;}
