#include <algorithm>
#include <vector>

struct DrawCmd { int tex; int prim; };

void SortDraws(std::vector<DrawCmd>& cmds){
    std::sort(cmds.begin(), cmds.end(),
        [](const DrawCmd&a,const DrawCmd&b){return a.tex<b.tex;});
}
