extern float ComputeResolutionScale(float depth);

void ApplyDynamicResolution(float avgDepth){
    float scale = ComputeResolutionScale(avgDepth);
    // adjust viewport or render target scale
}
