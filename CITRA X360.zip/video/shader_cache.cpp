#include <unordered_map>
#include <cstdint>
static std::unordered_map<uint64_t,void*> cache;
void* GetShader(uint64_t key){
    auto it=cache.find(key);
    if(it!=cache.end()) return it->second;
    void* s=nullptr; // compile
    cache[key]=s; return s;
}
