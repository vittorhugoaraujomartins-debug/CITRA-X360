#include "video_all.h"
void Video_Init(){}
void Video_BeginFrame(){}
void Video_EndFrame(){}
