#include <cmath>

static float nearScale = 1.0f;
static float midScale  = 0.85f;
static float farScale  = 0.65f;

float ComputeResolutionScale(float depth){
    if(depth < 0.3f) return nearScale;   // near objects
    if(depth < 0.7f) return midScale;    // mid range
    return farScale;                     // far geometry
}
