#pragma once
#include <cstdint>
#include <vector>
struct SceneKey { uint64_t hash; uint32_t w,h; };
struct CachedScene { SceneKey key; uint32_t offset; uint32_t size; };
bool SceneCache_Has(const SceneKey& k);
bool SceneCache_Load(const SceneKey& k);
void SceneCache_BeginBuild(const SceneKey& k);
void SceneCache_EndBuild();
