#include "scene_cache.h"
#include <xtl.h>
void PrerenderScene(const SceneKey& key, int ms_budget){
    if(SceneCache_Has(key)) return;
    SceneCache_BeginBuild(key);
    DWORD start = GetTickCount();
    while((int)(GetTickCount()-start) < ms_budget){
        // render static batches only
    }
    SceneCache_EndBuild();
}
