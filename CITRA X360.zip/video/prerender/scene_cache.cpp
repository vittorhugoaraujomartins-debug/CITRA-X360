#include "scene_cache.h"
#include <vector>
#include <unordered_map>
static std::unordered_map<uint64_t, CachedScene> index;
static SceneKey building{};
bool SceneCache_Has(const SceneKey& k){ return index.find(k.hash)!=index.end(); }
bool SceneCache_Load(const SceneKey& k){ return SceneCache_Has(k); }
void SceneCache_BeginBuild(const SceneKey& k){ building=k; }
void SceneCache_EndBuild(){ index[building.hash]={building,0,0}; }
