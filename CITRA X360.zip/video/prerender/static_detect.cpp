#include <cstdint>
bool IsStaticDraw(uint32_t flags){
    // heuristics: no skinning, no morph, no per-frame uniform changes
    return (flags & 0x1)==0;
}
