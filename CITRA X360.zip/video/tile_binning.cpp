#include <vector>
struct Draw { float minx,miny,maxx,maxy; };
static const int TILE=64;
void BinTiles(const std::vector<Draw>& in, std::vector<int>& bins, int w, int h){
    int tx=w/TILE, ty=h/TILE; bins.assign(tx*ty,0);
    for(const auto& d:in){
        int x0=d.minx/TILE, x1=d.maxx/TILE;
        int y0=d.miny/TILE, y1=d.maxy/TILE;
        for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++) bins[y*tx+x]++;
    }
}
