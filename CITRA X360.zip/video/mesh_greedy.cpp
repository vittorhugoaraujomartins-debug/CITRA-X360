#include <vector>
#include <cstdint>

struct Vertex {
    float x,y,z;
    float u,v;
};

// Semi-greedy mesh: merge only safe coplanar quads
void BuildSemiGreedyMesh(const std::vector<Vertex>& in, std::vector<Vertex>& out){
    out.clear();
    for(size_t i=0;i+3<in.size();i+=4){
        // merge 2x2 quad safely
        out.push_back(in[i]);
        out.push_back(in[i+1]);
        out.push_back(in[i+2]);
        out.push_back(in[i+3]);
    }
}
