#include <cmath>

float ComputeLOD(float dist){
    if(dist < 10.0f) return 0.0f;
    if(dist < 50.0f) return 1.0f;
    return 2.0f;
}
