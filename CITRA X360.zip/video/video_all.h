#pragma once
void Video_Init();
void Video_BeginFrame();
void Video_EndFrame();
