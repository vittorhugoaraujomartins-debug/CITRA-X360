#include <d3d9.h>
#include <vector>
#include <cstdint>

static IDirect3DDevice9* g_dev = nullptr;

struct Atlas {
    IDirect3DTexture9* tex;
    uint32_t width, height;
};

static Atlas g_atlases[5];

void GPU_Init(IDirect3DDevice9* dev){
    g_dev = dev;
}

void GPU_BindAtlas(int id){
    if(id<0 || id>=5) return;
    g_dev->SetTexture(0, g_atlases[id].tex);
}

void GPU_DrawQuad(){
    // Minimal state changes, batched draws only
    g_dev->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);
}
