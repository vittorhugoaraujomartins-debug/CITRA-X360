#include <d3d9.h>
extern IDirect3DDevice9* g_dev;

void GPU_OcclusionPrepass(){
    g_dev->SetRenderState(D3DRS_COLORWRITEENABLE, 0);
    // depth-only pass
}
