#include <d3d9.h>

extern IDirect3DDevice9* g_dev;

static DWORD lastCull = 0xFFFFFFFF;

void GPU_SetCull(DWORD mode){
    if(mode != lastCull){
        g_dev->SetRenderState(D3DRS_CULLMODE, mode);
        lastCull = mode;
    }
}
