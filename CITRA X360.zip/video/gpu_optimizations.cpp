#include <d3d9.h>

extern IDirect3DDevice9* g_dev;

void GPU_EnableOptimizations(){
    // Back-face culling
    g_dev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
    // Depth test
    g_dev->SetRenderState(D3DRS_ZENABLE, TRUE);
    // Occlusion hint
    g_dev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
}

void GPU_DrawInstanced(UINT primCount, UINT instances){
    for(UINT i=0;i<instances;i++)
        g_dev->DrawPrimitive(D3DPT_TRIANGLELIST, 0, primCount);
}
