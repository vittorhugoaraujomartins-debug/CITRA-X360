#include "state_cache.h"
struct _StateCacheAutoInit { _StateCacheAutoInit(){ StateCache_Init(); } } _g_state_cache_init;
