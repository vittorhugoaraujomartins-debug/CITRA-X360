struct Instance { float m[16]; };
void DrawInstanced(int meshId, const Instance* inst, int count){
    // issue one draw call with instance buffer
}
