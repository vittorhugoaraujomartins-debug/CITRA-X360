#pragma once
#include <vector>
struct Vertex { float x,y,z,u,v; uint32_t material; };
void GreedyMesh_Safe(const std::vector<Vertex>& in, std::vector<Vertex>& out, size_t maxMergeVertices);
