struct GPUState{int tex,shader;};
static GPUState cur, last;
bool StateChanged(){
    return cur.tex!=last.tex || cur.shader!=last.shader;
}
void ApplyState(){
    if(StateChanged()){
        last=cur;
        // apply dx state
    }
}
