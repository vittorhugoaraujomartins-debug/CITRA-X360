#pragma once
#include <cstdint>

struct JitBlock {
    uint32_t pc;
    void* entry;
};

static JitBlock g_blocks[4096];
static uint32_t g_block_count = 0;

inline JitBlock* BlockCacheFastGet(uint32_t pc){
    for(uint32_t i=0;i<g_block_count;i++)
        if(g_blocks[i].pc == pc) return &g_blocks[i];
    return nullptr;
}

inline void BlockCacheFastPut(uint32_t pc, void* entry){
    g_blocks[g_block_count++] = { pc, entry };
}
