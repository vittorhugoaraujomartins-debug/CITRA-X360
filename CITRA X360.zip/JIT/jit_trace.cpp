#include "block_cache_fast.h"

void LinkDirect(JitBlock* from, JitBlock* to){
    if(!from || !to) return;
    from->entry = to->entry; // hard link, no dispatcher
}
