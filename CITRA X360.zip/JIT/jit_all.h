#pragma once
// Unified JIT interface
void JIT_Init();
void JIT_Run();
