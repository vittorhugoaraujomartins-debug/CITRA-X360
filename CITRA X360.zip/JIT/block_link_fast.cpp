#include <unordered_map>
#include <cstdint>
static std::unordered_map<uint32_t,uint32_t> link_cache;
uint32_t JIT_NextPC(uint32_t pc){
    auto it=link_cache.find(pc);
    return it!=link_cache.end()?it->second:pc;
}
void JIT_Link(uint32_t from,uint32_t to){ link_cache[from]=to; }
