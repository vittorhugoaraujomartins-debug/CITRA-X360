#include "ppc_emitter_ext.h"
#include "mmu_fast.h"
#include "ir.h"

static inline uint8_t MapReg(uint8_t r){ return 14 + (r & 7); }

void EmitLDR(PPCEmitterExt& e, uint8_t rd, uint8_t rn, uint16_t off){
    // rD = *(rN + off)
    e.LWZ(MapReg(rd), off, MapReg(rn));
}

void EmitSTR(PPCEmitterExt& e, uint8_t rd, uint8_t rn, uint16_t off){
    e.STW(MapReg(rd), off, MapReg(rn));
}
