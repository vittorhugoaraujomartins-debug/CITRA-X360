#include "ir.h"
#include "ppc_emitter.h"
#include <vector>
#include <cstdint>

static inline uint8_t MapReg(uint8_t arm){
    // ARM R0-R7 -> PPC R14-R21
    return 14 + (arm & 7);
}

void CompileIRToPPC(const std::vector<IRInstr>& ir, PPCEmitter& e){
    for (auto& i : ir){
        switch(i.op){
            case IROp::ADD:
                e.ADD(MapReg(i.rd), MapReg(i.rn), MapReg(i.rm));
                break;
            case IROp::SUB:
                e.SUB(MapReg(i.rd), MapReg(i.rn), MapReg(i.rm));
                break;
            case IROp::MOV:
                e.MOV(MapReg(i.rd), MapReg(i.rn));
                break;
            default:
                break;
        }
    }
}
