#include "ir_executor_ppc.h"

extern unsigned int g_arm_r[16];
extern unsigned int g_arm_pc;

void IR_Execute(IRBlock* block)
{
    for (u32 i = 0; i < block->count; i++)
    {
        IRInst& ir = block->inst[i];

        switch (ir.op)
        {
            case IR_MOV:
                g_arm_r[ir.rd] = ir.imm;
                break;

            case IR_ADD:
                g_arm_r[ir.rd] = g_arm_r[ir.rn] + ir.imm;
                break;

            case IR_SUB:
                g_arm_r[ir.rd] = g_arm_r[ir.rn] - ir.imm;
                break;

            case IR_BRANCH:
                g_arm_pc += (ir.imm << 2);
                return;

            default:
                break;
        }

        g_arm_pc += 4;
    }
}