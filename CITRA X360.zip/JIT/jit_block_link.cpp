#include <unordered_map>
#include <cstdint>
static std::unordered_map<uint32_t, uint32_t> links;
uint32_t JIT_Link(uint32_t pc){
    auto it=links.find(pc);
    if(it!=links.end()) return it->second;
    return pc;
}
void JIT_SetLink(uint32_t from,uint32_t to){links[from]=to;}
