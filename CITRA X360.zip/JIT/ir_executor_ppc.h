#pragma once
#include "arm_to_ir.h"

void IR_Execute(IRBlock* block);

extern u32 g_arm_r[16];
extern u32 g_arm_pc;
extern u32* g_arm_memory;
extern u32 g_arm_flags; // bit 0 = Z

void IR_Execute(IRBlock* block)
{
    for (u32 i = 0; i < block->count; i++)
    {
        IRInst& ir = block->inst[i];

        switch (ir.op)
        {
            case IR_MOV:
                g_arm_r[ir.rd] = ir.rm ? g_arm_r[ir.rm] : ir.imm;
                break;

            case IR_ADD:
                g_arm_r[ir.rd] = g_arm_r[ir.rn] + ir.imm;
                break;

            case IR_SUB:
                g_arm_r[ir.rd] = g_arm_r[ir.rn] - ir.imm;
                break;

            case IR_CMP:
                g_arm_flags = ((g_arm_r[ir.rn] - ir.imm) == 0);
                break;

            case IR_LDR:
                g_arm_r[ir.rd] =
                    g_arm_memory[(g_arm_r[ir.rn] + ir.imm) >> 2];
                break;

            case IR_STR:
                g_arm_memory[(g_arm_r[ir.rn] + ir.imm) >> 2] =
                    g_arm_r[ir.rd];
                break;

            case IR_BRANCH:
                g_arm_pc += (ir.imm << 2);
                return;

            case IR_RETURN:
                g_arm_pc = g_arm_r[14]; // LR
                return;

            default:
                break;
        }

        g_arm_pc += 4;
    }
}