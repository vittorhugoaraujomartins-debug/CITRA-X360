#include <cstdint>
struct Flags{bool dirty;uint32_t val;} g_flags;
uint32_t GetFlags(){ if(g_flags.dirty){ /* compute */ g_flags.dirty=false;} return g_flags.val; }
