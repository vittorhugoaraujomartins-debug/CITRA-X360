#include <cstdint>

// Loop unrolling + zero branch hot loop
void JIT_ExecuteFast(uint32_t* pc){
    for(int i=0;i<8;i++){
        // unrolled execution
        (*pc)++;
    }
}
