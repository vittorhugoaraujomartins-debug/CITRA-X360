#include <cstdint>

enum {
    GSP_FLUSH = 0x01,
    GSP_SWAP  = 0x02
};

uint32_t HLE_GSP(uint32_t cmd){
    switch(cmd){
        case GSP_FLUSH: return 0;
        case GSP_SWAP:  return 0;
        default: return 0;
    }
}
