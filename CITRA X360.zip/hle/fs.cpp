#include <cstdint>
#include <cstring>

uint32_t FS_OpenArchive(){ return 0; }
uint32_t FS_OpenFile(){ return 0; }
uint32_t FS_ReadFile(void* out, uint32_t size){
    memset(out, 0, size);
    return size;
}
