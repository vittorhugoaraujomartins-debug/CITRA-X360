#include <cstdint>

uint32_t HLE_SVC(uint32_t id){
    switch(id){
        case 0x01: return 0; // ExitThread
        case 0x02: return 0; // SleepThread
        default: return 0;
    }
}
