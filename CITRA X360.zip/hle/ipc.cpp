#include <cstdint>

uint32_t IPC_Dispatch(uint32_t service, uint32_t cmd){
    switch(service){
        case 0x01: return 0; // FS
        case 0x02: return 0; // HID
        case 0x03: return 0; // GSP
        case 0x04: return 0; // DSP
        default: return 0;
    }
}
