#include <cstdint>

struct HIDState {
    uint32_t buttons;
    int16_t cx, cy;
};

static HIDState g_hid{};

void HID_Update(uint32_t btn, int16_t x, int16_t y){
    g_hid.buttons = btn;
    g_hid.cx = x;
    g_hid.cy = y;
}

HIDState* HID_Get(){ return &g_hid; }
