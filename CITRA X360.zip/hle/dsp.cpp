#include <cstdint>

void DSP_Submit(const int16_t* samples, uint32_t count){
    // Fake audio sink
}
