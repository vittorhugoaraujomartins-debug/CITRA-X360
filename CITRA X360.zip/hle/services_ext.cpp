#include <cstdint>

uint32_t SVC_Ext(uint32_t id){
    switch(id){
        case 0x30: return 0; // GetSystemTick
        case 0x31: return 0; // CreateThread
        default: return 0;
    }
}
