#pragma once
#include <cstdint>

namespace XENOS {

class Video {
public:
    bool Init(uint32_t width, uint32_t height);
    void BeginFrame();
    void EndFrame();

    uint32_t GetWidth() const;
    uint32_t GetHeight() const;

private:
    uint32_t screen_width  = 1280;
    uint32_t screen_height = 720;
};

}