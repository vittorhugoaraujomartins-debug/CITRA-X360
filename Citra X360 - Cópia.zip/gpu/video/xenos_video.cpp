#include "xenos_video.h"

// Exemplo (ajuste pro seu ambiente real)
// #include <xgraphics.h>
// #include <xvideo.h>

namespace XENOS {

bool Video::Init(uint32_t width, uint32_t height) {
    screen_width  = width;
    screen_height = height;

    // 1️⃣ Inicializa sistema de vídeo
    // XVideoInit();

    // 2️⃣ Define modo de vídeo (720p é o mais seguro)
    // XVideoSetMode(1280, 720, XVIDEO_FORMAT_720P);

    // 3️⃣ Inicializa GPU / device
    // XGInit();

    return true;
}

void Video::BeginFrame() {
    // 4️⃣ Limpa framebuffer
    // XGClearColor(0.1f, 0.1f, 0.3f, 1.0f);
    // XGClearDepth(1.0f);
}

void Video::EndFrame() {
    // 5️⃣ Apresenta o frame
    // XGSwapBuffers();
}

uint32_t Video::GetWidth() const {
    return screen_width;
}

uint32_t Video::GetHeight() const {
    return screen_height;
}

}