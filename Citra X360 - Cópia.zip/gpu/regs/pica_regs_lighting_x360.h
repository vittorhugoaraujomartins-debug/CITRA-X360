#pragma once

#include <array>

namespace Pica::X360 {

struct LightingRegs {
    enum class Config : u32 {
        Cfg0 = 0,
        Cfg1 = 1,
        Cfg2 = 2,
        Cfg3 = 3,
        Cfg4 = 4,
        Cfg5 = 5,
        Cfg6 = 6,
        Cfg7 = 8
    };

    struct LightColor {
        BitField<0, 10, u32> b;
        BitField<10, 10, u32> g;
        BitField<20, 10, u32> r;

        Common::Vec3f ToVec() const {
            return {
                r / 255.0f,
                g / 255.0f,
                b / 255.0f
            };
        }
    };

    struct Light {
        LightColor spec0;
        LightColor spec1;
        LightColor diffuse;
        LightColor ambient;

        BitField<0, 16, u32> pos_x;
        BitField<16, 16, u32> pos_y;
        BitField<0, 16, u32> pos_z;

        BitField<0, 13, s32> spot_x;
        BitField<16, 13, s32> spot_y;
        BitField<0, 13, s32> spot_z;

        u32 pad;

        BitField<0, 1, u32> directional;
        BitField<1, 1, u32> two_sided;
        BitField<2, 1, u32> geom0;
        BitField<3, 1, u32> geom1;

        BitField<0, 20, u32> dist_bias;
        BitField<0, 20, u32> dist_scale;

        u32 pad2[4];
    };

    Light lights[8];
    LightColor global_ambient;
    u32 pad0;
    BitField<0, 3, u32> max_light;

    u32 config0;
    u32 config1;

    u32 pad1[0x40];
};

static_assert(sizeof(LightingRegs) == 0xC0 * sizeof(u32),
              "LightingRegs X360 size mismatch");

} // namespace Pica::X360