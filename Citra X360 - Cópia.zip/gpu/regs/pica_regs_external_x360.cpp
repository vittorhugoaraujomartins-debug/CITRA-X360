#include "pica_regs_external_x360.h"

namespace Pica::X360 {
// Lógica de leitura/escrita MMIO vai ficar no PicaCoreX360.
// Aqui só estrutura + reset.
}