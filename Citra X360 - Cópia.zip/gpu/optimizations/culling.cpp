
#include "culling.hpp"

bool Frustum::TestAABB(const AABB& box) const {
    // basic conservative test
    for(int i=0;i<6;i++){
        const float* p = planes[i];
        Vec3 v = {
            p[0] >= 0 ? box.max.x : box.min.x,
            p[1] >= 0 ? box.max.y : box.min.y,
            p[2] >= 0 ? box.max.z : box.min.z
        };
        if(p[0]*v.x + p[1]*v.y + p[2]*v.z + p[3] < 0)
            return false;
    }
    return true;
}

bool OcclusionCuller::IsOccluded(const AABB& box) {
    // Placeholder: hierarchical Z / depth pre-pass hook
    return false;
}
