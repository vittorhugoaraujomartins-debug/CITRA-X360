#include "xenos_renderer.h"

// headers reais do XDK / libxenon entram aqui
// #include <xgraphics.h>

namespace XENOS {

void Renderer::Init() {
    // inicialização mínima da GPU
}

void Renderer::BeginFrame() {
    // limpar framebuffer
    // XGClear(...)
}

void Renderer::EndFrame() {
    // swap buffers
}

void Renderer::DrawFromPica(const PICA::State& pica_state) {
    // traduz PICA -> XENOS
    state.depth_test   = pica_state.depth_test;
    state.blending     = pica_state.blending;
    state.vertex_buffer = pica_state.vb.address;
    state.index_buffer  = pica_state.ib.address;
    state.texture0      = pica_state.tex0.address;

    ApplyState();
    Draw();
}

void Renderer::ApplyState() {
    // Depth
    if (state.depth_test) {
        // XGEnableDepthTest(true);
    } else {
        // XGEnableDepthTest(false);
    }

    // Blending
    if (state.blending) {
        // XGEnableAlphaBlend(true);
    } else {
        // XGEnableAlphaBlend(false);
    }

    // Buffers e textura serão usados no Draw()
}

}