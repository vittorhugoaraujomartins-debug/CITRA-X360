#include <xtl.h>
extern "C" void __cdecl main(){ while(true){ Sleep(16); } }


// Expanded implementation
#include <cstdint>
static uint32_t _dummy_state = 0;
void Tick() { _dummy_state++; }
