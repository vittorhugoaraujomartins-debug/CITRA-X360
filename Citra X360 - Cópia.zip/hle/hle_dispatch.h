#pragma once
#include <xtl.h>
bool HLE_HandleSVC(unsigned int svc_id);
