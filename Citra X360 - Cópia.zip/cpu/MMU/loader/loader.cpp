
#include <cstdio>
void Loader_Run(){ printf("ARM Loader OK\n"); }


// Expanded implementation
#include <cstdint>
static uint32_t _dummy_state = 0;
void Tick() { _dummy_state++; }
