
#pragma once
#include <cstdint>
#include <vector>

class MMU {
public:
    void Init(uint8_t* ram, uint32_t ramSize, uint8_t* rom, uint32_t romSize);
    uint8_t Read8(uint32_t addr);
    uint32_t Read32(uint32_t addr);
    void Write8(uint32_t addr, uint8_t v);
    void Write32(uint32_t addr, uint32_t v);
private:
    uint8_t* ram;
    uint8_t* rom;
    uint32_t ramSize;
    uint32_t romSize;
};
