
#include <cstdint>

static uint8_t g_ram[64 * 1024 * 1024]; // 64MB RAM

extern "C" {
uint8_t* MMU_GetRAM() { return g_ram; }
void MMU_Write32(uint32_t addr, uint32_t value) {
    *(uint32_t*)&g_ram[addr] = value;
}
uint32_t MMU_Read32(uint32_t addr) {
    return *(uint32_t*)&g_ram[addr];
}
}
