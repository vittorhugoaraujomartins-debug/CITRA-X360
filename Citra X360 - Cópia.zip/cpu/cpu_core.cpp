#include <cstdint>
#include <vector>
namespace CPU {
  static uint64_t cycles=0;
  void Step(uint32_t n){ cycles+=n; }
}
