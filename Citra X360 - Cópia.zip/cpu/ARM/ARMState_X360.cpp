#include "ARMState_X360.h"

// ========================================
// Construtor
// ========================================

ARMState_X360::ARMState_X360()
{
    Reset();
}

// ========================================
// Reset CPU
// ========================================

void ARMState_X360::Reset()
{
    Reg.fill(0);
    Reg_FIQ.fill(0);
    Reg_IRQ.fill(0);
    Reg_SVC.fill(0);
    Reg_ABORT.fill(0);
    Reg_UNDEF.fill(0);

    for (auto& s : Spsr)
        s = 0;

    VFP_Registers.fill(0);

    Cpsr.value = 0xD3; // Supervisor mode inicial
    current_mode = ARMMode::Supervisor;

    exclusive_state = false;
    exclusive_address = 0;
}

// ========================================
// Troca de modo ARM
// ========================================

void ARMState_X360::ChangeMode(ARMMode new_mode)
{
    if (new_mode == current_mode)
        return;

    SaveBankedRegisters();

    current_mode = new_mode;
    Cpsr.SetMode(new_mode);

    LoadBankedRegisters();
}

// ========================================
// Save banked registers
// ========================================

void ARMState_X360::SaveBankedRegisters()
{
    switch (current_mode)
    {
    case ARMMode::FIQ:
        for (int i = 0; i < 7; i++)
            Reg_FIQ[i] = Reg[8 + i];
        break;

    case ARMMode::IRQ:
        Reg_IRQ[0] = SP();
        Reg_IRQ[1] = LR();
        break;

    case ARMMode::Supervisor:
        Reg_SVC[0] = SP();
        Reg_SVC[1] = LR();
        break;

    case ARMMode::Abort:
        Reg_ABORT[0] = SP();
        Reg_ABORT[1] = LR();
        break;

    case ARMMode::Undefined:
        Reg_UNDEF[0] = SP();
        Reg_UNDEF[1] = LR();
        break;

    default:
        break;
    }
}

// ========================================
// Load banked registers
// ========================================

void ARMState_X360::LoadBankedRegisters()
{
    switch (current_mode)
    {
    case ARMMode::FIQ:
        for (int i = 0; i < 7; i++)
            Reg[8 + i] = Reg_FIQ[i];
        break;

    case ARMMode::IRQ:
        SP() = Reg_IRQ[0];
        LR() = Reg_IRQ[1];
        break;

    case ARMMode::Supervisor:
        SP() = Reg_SVC[0];
        LR() = Reg_SVC[1];
        break;

    case ARMMode::Abort:
        SP() = Reg_ABORT[0];
        LR() = Reg_ABORT[1];
        break;

    case ARMMode::Undefined:
        SP() = Reg_UNDEF[0];
        LR() = Reg_UNDEF[1];
        break;

    default:
        break;
    }
}

// ========================================
// Memory Interface (Stub inicial)
// ========================================

uint32_t ARMState_X360::Read32(uint32_t address)
{
    // TODO: Integrar com MMU do Citra X360
    return 0;
}

void ARMState_X360::Write32(uint32_t address, uint32_t value)
{
    // TODO: Integrar com MMU do Citra X360
}